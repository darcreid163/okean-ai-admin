<?php
/**
 * AI ability handler — read and update WoodMart theme settings.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Theme_Settings;

use WP_Error;
use XTS\AI_Abilities\Permission;
use XTS\Admin\Modules\Options;
use XTS\Admin\Modules\Options\Presets;
use XTS\Modules\Styles_Storage;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and handles the woodmart/*-theme-setting abilities.
 */
class Abilities {
	/**
	 * Field types the AI is allowed to write.
	 *
	 * 'responsive_range' and 'dimensions' are persisted as a
	 * woodmart_compress( wp_json_encode() ) per-device blob that Options\Sanitize
	 * has no case for, so they never go through $field->sanitize() — Devices_Value
	 * encodes and decodes them instead (see ability_update / build_descriptor).
	 *
	 * @var array<int, string>
	 */
	private const WRITABLE_TYPES = array(
		'color',
		'switcher',
		'select',
		'buttons',
		'range',
		'responsive_range',
		'dimensions',
		'typography',
		'text_input',
		'textarea',
		'editor',
		'background',
	);

	/**
	 * Register all three theme-settings abilities.
	 *
	 * @return void
	 */
	public function register() {
		$this->register_list_ability();
		$this->register_get_ability();
		$this->register_update_ability();
	}

	/**
	 * Execute callback for woodmart/list-theme-settings.
	 *
	 * @param array<string, mixed> $input Ability input.
	 * @return array<int, array<string, mixed>>
	 */
	public function ability_list( $input ) {
		$input    = (array) $input;
		$search   = isset( $input['search'] ) ? strtolower( trim( (string) $input['search'] ) ) : '';
		$section  = isset( $input['section'] ) ? (string) $input['section'] : '';
		$per_page = isset( $input['per_page'] ) && (int) $input['per_page'] > 0 ? (int) $input['per_page'] : 20;
		$page     = isset( $input['page'] ) && (int) $input['page'] > 0 ? (int) $input['page'] : 1;

		$current_values = Options::get_options();
		$raw_options    = get_option( 'xts-woodmart-options', array() );
		$preset_ids     = array_keys( Presets::get_all() );
		$writable_types = $this->writable_types();
		$descriptors    = array();

		foreach ( Options::get_fields() as $field ) {
			$id    = $field->get_id();
			$label = isset( $field->args['name'] ) ? $field->args['name'] : $id;

			if ( $search
				&& false === strpos( strtolower( $id ), $search )
				&& false === strpos( strtolower( (string) $label ), $search ) ) {
				continue;
			}

			$field_section = isset( $field->args['section'] ) ? $field->args['section'] : '';

			if ( $section && $field_section !== $section ) {
				continue;
			}

			$descriptors[] = $this->build_descriptor( $field, $current_values, $raw_options, $preset_ids, $writable_types, false );
		}

		$offset = ( $page - 1 ) * $per_page;

		return array_values( array_slice( $descriptors, $offset, $per_page ) );
	}

	/**
	 * Execute callback for woodmart/get-theme-setting.
	 *
	 * @param array<string, mixed> $input Ability input.
	 * @return array<string, mixed>|WP_Error
	 */
	public function ability_get( $input ) {
		$id    = sanitize_key( isset( $input['id'] ) ? $input['id'] : '' );
		$field = $this->find_field( $id );

		if ( null === $field ) {
			/* translators: %s: setting id. */
			return new WP_Error( 'field_not_found', sprintf( __( 'Theme setting "%s" not found.', 'woodmart' ), $id ) );
		}

		$current_values = Options::get_options();
		$raw_options    = get_option( 'xts-woodmart-options', array() );
		$preset_ids     = array_keys( Presets::get_all() );

		return $this->build_descriptor( $field, $current_values, $raw_options, $preset_ids, $this->writable_types(), true );
	}

	/**
	 * Execute callback for woodmart/update-theme-setting.
	 *
	 * @param array<string, mixed> $input Ability input.
	 * @return array<string, mixed>|WP_Error
	 */
	public function ability_update( $input ) {
		$id    = sanitize_key( isset( $input['id'] ) ? $input['id'] : '' );
		$field = $this->find_field( $id );

		if ( null === $field ) {
			/* translators: %s: setting id. */
			return new WP_Error( 'field_not_found', sprintf( __( 'Theme setting "%s" not found.', 'woodmart' ), $id ) );
		}

		$type = isset( $field->args['type'] ) ? $field->args['type'] : '';

		if ( ! in_array( $type, $this->writable_types(), true ) ) {
			/* translators: %s: setting id. */
			return new WP_Error( 'field_not_writable', sprintf( __( 'Theme setting "%s" cannot be modified by AI.', 'woodmart' ), $id ) );
		}

		// old_value is the raw base-layer value written here; it may differ from the
		// current_value reported by list/get if a preset override resolves as active
		// for the request context (see has_preset_overrides in the descriptor).
		$raw_options = get_option( 'xts-woodmart-options', array() );
		$old_value   = isset( $raw_options[ $id ] ) ? $raw_options[ $id ] : null;
		$value       = isset( $input['value'] ) ? $input['value'] : null;

		if ( Devices_Value::is_devices_type( $type ) ) {
			// Per-device blob: merge over the stored value so devices the caller did
			// not mention keep theirs, and encode it the way the control stores it.
			$new_value = Devices_Value::encode( $value, $field->args, $old_value );

			if ( is_wp_error( $new_value ) ) {
				return $new_value;
			}
		} else {
			$new_value = $field->sanitize( $value );
		}

		$raw_options[ $id ] = $new_value;

		Options::get_instance()->update_options( $raw_options );
		$this->invalidate_css_cache();

		return array(
			'id'        => $id,
			'old_value' => $this->readable_value( $old_value, $field->args ),
			'new_value' => $this->readable_value( $new_value, $field->args ),
		);
	}

	/**
	 * Build a field descriptor array for the AI.
	 *
	 * @param object               $field           Field object.
	 * @param array<string, mixed> $current_values  Resolved option values.
	 * @param array<string, mixed> $raw_options     Raw xts-woodmart-options value (base + preset subarrays).
	 * @param array<int, int>      $preset_ids      Preset ids to check for overrides.
	 * @param array<int, string>   $writable_types  Types the AI may write.
	 * @param bool                 $include_default Whether to include default_value.
	 * @return array<string, mixed>
	 */
	private function build_descriptor( $field, $current_values, $raw_options, $preset_ids, $writable_types, $include_default ) {
		$id      = $field->get_id();
		$type    = isset( $field->args['type'] ) ? $field->args['type'] : '';
		$options = null;

		if ( in_array( $type, array( 'select', 'buttons' ), true ) && ! empty( $field->args['options'] ) ) {
			$options = array();

			foreach ( $field->args['options'] as $key => $option ) {
				if ( is_array( $option ) ) {
					$options[ $key ] = isset( $option['name'] ) ? $option['name'] : $key;
				} else {
					$options[ $key ] = $option;
				}
			}
		}

		$has_preset_overrides = false;

		foreach ( $preset_ids as $preset_id ) {
			if ( isset( $raw_options[ $preset_id ] ) && is_array( $raw_options[ $preset_id ] ) && array_key_exists( $id, $raw_options[ $preset_id ] ) ) {
				$has_preset_overrides = true;
				break;
			}
		}

		$descriptor = array(
			'id'                   => $id,
			'label'                => isset( $field->args['name'] ) ? $field->args['name'] : $id,
			'type'                 => $type,
			'section'              => isset( $field->args['section'] ) ? $field->args['section'] : '',
			'current_value'        => $this->readable_value( isset( $current_values[ $id ] ) ? $current_values[ $id ] : null, $field->args ),
			'options'              => $options,
			'writable'             => in_array( $type, $writable_types, true ),
			'has_preset_overrides' => $has_preset_overrides,
			'value_format'         => Value_Format::for_field( $field ),
		);

		if ( $include_default ) {
			$descriptor['default_value'] = Devices_Value::is_devices_type( $type )
				? Devices_Value::decode( Options::get_default( $field->args ), $field->args )
				: Options::get_default( $field->args );
		}

		return $descriptor;
	}

	/**
	 * Present a stored value in the shape the AI reads and writes.
	 *
	 * Per-device types are stored compressed, which is opaque to the caller — and
	 * an opaque current_value is what makes an AI resend a scalar and wipe the
	 * other devices. Everything else is already stored readable.
	 *
	 * @param mixed                $value Stored value.
	 * @param array<string, mixed> $args  Field args.
	 * @return mixed
	 */
	private function readable_value( $value, $args ) {
		$type = isset( $args['type'] ) ? $args['type'] : '';

		return Devices_Value::is_devices_type( $type ) ? Devices_Value::decode( $value, $args ) : $value;
	}

	/**
	 * Find a field object by its slug.
	 *
	 * @param string $id Field slug.
	 * @return object|null
	 */
	private function find_field( $id ) {
		foreach ( Options::get_fields() as $field ) {
			if ( $field->get_id() === $id ) {
				return $field;
			}
		}

		return null;
	}

	/**
	 * Return the writable field types, filterable by developers.
	 *
	 * @return array<int, string>
	 */
	private function writable_types() {
		return apply_filters( 'woodmart_ai_writable_field_types', self::WRITABLE_TYPES );
	}

	/**
	 * Invalidate the theme-settings CSS cache so it regenerates on the next request.
	 *
	 * Mirrors Themesettingscss::reset_data() without the $_GET guard, making it
	 * safe to call from a REST / Ability API context.
	 *
	 * @return void
	 */
	private function invalidate_css_cache() {
		$presets = array_keys( Presets::get_all() );
		array_unshift( $presets, 'default' );

		foreach ( $presets as $preset ) {
			$storage = new Styles_Storage( 'theme_settings_' . $preset );
			$storage->reset_data();
			$storage->delete_css();
		}

		$icons_storage = new Styles_Storage( 'icons_fonts', 'option', '', false );
		$icons_storage->reset_data();
		$icons_storage->delete_css();
	}

	/**
	 * Register the woodmart/list-theme-settings ability.
	 *
	 * @return void
	 */
	private function register_list_ability() {
		wp_register_ability(
			'woodmart/list-theme-settings',
			array(
				'label'               => __( 'List Theme Settings', 'woodmart' ),
				'description'         => __( 'Search and browse WoodMart theme settings.', 'woodmart' ),
				'category'            => 'woodmart-theme',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'search'   => array(
							'type'        => 'string',
							'description' => __( 'Filter by setting id or label (case-insensitive substring).', 'woodmart' ),
						),
						'section'  => array(
							'type'        => 'string',
							'description' => __( 'Filter by section id.', 'woodmart' ),
						),
						'per_page' => array(
							'type'        => 'integer',
							'description' => __( 'Results per page (default 20).', 'woodmart' ),
						),
						'page'     => array(
							'type'        => 'integer',
							'description' => __( 'Page number (default 1).', 'woodmart' ),
						),
					),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'  => 'array',
					'items' => array( 'type' => 'object' ),
				),
				'execute_callback'    => array( $this, 'ability_list' ),
				'permission_callback' => array( Permission::class, 'manage_theme' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);
	}

	/**
	 * Register the woodmart/get-theme-setting ability.
	 *
	 * @return void
	 */
	private function register_get_ability() {
		wp_register_ability(
			'woodmart/get-theme-setting',
			array(
				'label'               => __( 'Get Theme Setting', 'woodmart' ),
				'description'         => __( 'Read full metadata and current value for a single WoodMart theme setting.', 'woodmart' ),
				'category'            => 'woodmart-theme',
				'input_schema'        => array(
					'type'                 => 'object',
					'required'             => array( 'id' ),
					'properties'           => array(
						'id' => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_key',
							'description'       => __( 'Setting slug (e.g. primary-color).', 'woodmart' ),
						),
					),
					'additionalProperties' => false,
				),
				'output_schema'       => array( 'type' => 'object' ),
				'execute_callback'    => array( $this, 'ability_get' ),
				'permission_callback' => array( Permission::class, 'manage_theme' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);
	}

	/**
	 * Register the woodmart/update-theme-setting ability.
	 *
	 * @return void
	 */
	private function register_update_ability() {
		wp_register_ability(
			'woodmart/update-theme-setting',
			array(
				'label'               => __( 'Update Theme Setting', 'woodmart' ),
				'description'         => __( 'Change the value of a single WoodMart theme setting. Writes the base option layer; preset-scoped values are not affected.', 'woodmart' ),
				'category'            => 'woodmart-theme',
				'input_schema'        => array(
					'type'                 => 'object',
					'required'             => array( 'id', 'value' ),
					'properties'           => array(
						'id'    => array(
							'type'              => 'string',
							'sanitize_callback' => 'sanitize_key',
							'description'       => __( 'Setting slug to update.', 'woodmart' ),
						),
						'value' => array(
							'description' => __( 'New value for the setting. Follow the value_format reported by get-theme-setting: per-device settings (responsive_range, dimensions) take an object keyed by device and only the devices you send are changed.', 'woodmart' ),
							'type'        => array( 'string', 'number', 'integer', 'boolean', 'array', 'object', 'null' ),
						),
					),
					'additionalProperties' => false,
				),
				'output_schema'       => array( 'type' => 'object' ),
				'execute_callback'    => array( $this, 'ability_update' ),
				'permission_callback' => array( Permission::class, 'manage_theme' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => false,
					),
				),
			)
		);
	}
}
