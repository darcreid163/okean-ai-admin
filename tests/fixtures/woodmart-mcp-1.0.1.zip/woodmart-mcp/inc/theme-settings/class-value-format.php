<?php
/**
 * AI abilities — value-format hints for theme-setting fields.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Theme_Settings;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Builds a per-field "how to specify the value" hint for the AI descriptor.
 */
class Value_Format {
	/**
	 * Build the value_format hint for a single field.
	 *
	 * @param object $field Field object exposing ->args (type + type-specific keys).
	 * @return array{description: string, example: mixed}
	 */
	public static function for_field( $field ) {
		$args = is_object( $field ) && isset( $field->args ) ? $field->args : array();
		$type = isset( $args['type'] ) ? $args['type'] : '';

		switch ( $type ) {
			case 'color':
				return self::color( $args );
			case 'switcher':
				return array(
					'description' => '"1" to enable, "0" to disable. "yes" is also accepted (stored as "1").',
					'example'     => '1',
				);
			case 'select':
			case 'buttons':
				return self::select( $args );
			case 'range':
				return self::range( $args );
			case 'responsive_range':
			case 'dimensions':
				return self::devices( $args );
			case 'typography':
				return array(
					'description' => 'Object with keys such as font-family, font-size, font-weight, font-style, font-variant, line-height, text-transform, color, background. See current_value/default_value for the exact shape.',
					'example'     => null,
				);
			case 'background':
				return array(
					'description' => 'Object with keys: color, url (image URL), repeat, size, position, attachment.',
					'example'     => null,
				);
			case 'text_input':
				return self::text_input( $args );
			case 'textarea':
				return array(
					'description' => 'String. HTML is allowed and sanitized with wp_kses_post.',
					'example'     => '',
				);
			case 'editor':
				return array(
					'description' => 'String. HTML is allowed.',
					'example'     => '',
				);
			default:
				return array(
					'description' => 'See current_value and default_value for the expected shape.',
					'example'     => null,
				);
		}
	}

	/**
	 * Per-device hint (responsive_range / dimensions) — which devices and keys the
	 * field takes, and that only the devices sent are touched.
	 *
	 * @param array<string, mixed> $args Field args.
	 * @return array{description: string, example: mixed}
	 */
	private static function devices( $args ) {
		$declared = ! empty( $args['devices'] ) && is_array( $args['devices'] ) ? $args['devices'] : array();
		$devices  = $declared ? array_keys( $declared ) : array( 'desktop' );
		$keys     = Devices_Value::keys_description( $args );
		$example  = $declared ? array_slice( $declared, 0, 1, true ) : array();

		return array(
			'description' => sprintf(
				'Object keyed by device (%1$s). Each device entry takes: %2$s. Only the devices you send are changed; the others keep their current value. See current_value for the live per-device shape.',
				implode( '/', $devices ),
				$keys
			),
			'example'     => $example ? array( 'devices' => $example ) : null,
		);
	}

	/**
	 * Color hint — plain hex when data_type is "hex", otherwise an idle/hover object.
	 *
	 * @param array<string, mixed> $args Field args.
	 * @return array{description: string, example: mixed}
	 */
	private static function color( $args ) {
		if ( isset( $args['data_type'] ) && 'hex' === $args['data_type'] ) {
			return array(
				'description' => 'Hex color string.',
				'example'     => '#ff0000',
			);
		}

		return array(
			'description' => 'Object of state to hex color; a bare hex string is also accepted and applied to "idle".',
			'example'     => array(
				'idle'  => '#ff0000',
				'hover' => '#cc0000',
			),
		);
	}

	/**
	 * Select/buttons hint — value is one of the option keys.
	 *
	 * @param array<string, mixed> $args Field args.
	 * @return array{description: string, example: mixed}
	 */
	private static function select( $args ) {
		$example = null;

		if ( ! empty( $args['options'] ) && is_array( $args['options'] ) ) {
			$keys    = array_keys( $args['options'] );
			$example = isset( $keys[0] ) ? $keys[0] : null;
		}

		return array(
			'description' => 'One of the keys listed in the "options" field of this descriptor.',
			'example'     => $example,
		);
	}

	/**
	 * Range hint — a bounded number, with optional unit.
	 *
	 * @param array<string, mixed> $args Field args.
	 * @return array{description: string, example: mixed}
	 */
	private static function range( $args ) {
		$description = 'Number';

		$has_min = isset( $args['min'] ) && '' !== $args['min'];
		$has_max = isset( $args['max'] ) && '' !== $args['max'];

		if ( $has_min && $has_max ) {
			$description .= sprintf( ', between %s and %s', $args['min'], $args['max'] );
		}

		if ( isset( $args['step'] ) && '' !== $args['step'] ) {
			$description .= sprintf( ', step %s', $args['step'] );
		}

		if ( ! empty( $args['unit'] ) ) {
			$description .= sprintf( ', unit "%s"', $args['unit'] );
		}

		$description .= '.';

		if ( isset( $args['default'] ) && '' !== $args['default'] ) {
			$example = $args['default'];
		} elseif ( $has_min ) {
			$example = $args['min'];
		} else {
			$example = null;
		}

		return array(
			'description' => $description,
			'example'     => $example,
		);
	}

	/**
	 * Text input hint — string, with sub-format notes from args.
	 *
	 * @param array<string, mixed> $args Field args.
	 * @return array{description: string, example: mixed}
	 */
	private static function text_input( $args ) {
		$description = 'String.';

		if ( isset( $args['sanitize'] ) && 'slug' === $args['sanitize'] ) {
			$description .= ' Slug format: lowercased; runs of characters other than letters, digits, and hyphens become "_".';
		} elseif ( isset( $args['sanitize'] ) && 'social_links' === $args['sanitize'] ) {
			$description .= ' Expected to be a social link URL.';
		} elseif ( isset( $args['attributes']['type'] ) && 'url' === $args['attributes']['type'] ) {
			$description .= ' Expected to be a URL.';
		}

		return array(
			'description' => $description,
			'example'     => '',
		);
	}
}
