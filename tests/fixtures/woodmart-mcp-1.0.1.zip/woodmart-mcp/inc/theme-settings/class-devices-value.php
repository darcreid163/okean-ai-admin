<?php
/**
 * AI abilities — encode/decode helper for per-device theme-setting values.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Theme_Settings;

use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Reads and writes the per-device field types ('responsive_range', 'dimensions').
 *
 * Both controls persist their value as woodmart_compress( wp_json_encode( array ) )
 * with the shape { devices: { desktop: {...}, tablet: {...} }, is_lock?: bool }, and
 * neither has a case in Options\Sanitize — so a plain array written through
 * $field->sanitize() is silently blanked, and a plain scalar is read back as a
 * desktop-only legacy value that drops whatever tablet/mobile had. This helper is
 * the only place that speaks that format for abilities: it decodes stored values
 * for the descriptor and merges partial per-device input over the current value
 * on write, leaving untouched devices intact.
 */
class Devices_Value {
	/**
	 * Field types persisted as a compressed per-device blob.
	 *
	 * @var array<int,string>
	 */
	public const TYPES = array( 'responsive_range', 'dimensions' );

	/**
	 * Devices assumed when a field declares none.
	 *
	 * @var array<int,string>
	 */
	private const FALLBACK_DEVICES = array( 'desktop', 'tablet', 'mobile' );

	/**
	 * Whether a field type is stored as a per-device blob.
	 *
	 * @param string $type Field type.
	 * @return bool
	 */
	public static function is_devices_type( $type ) {
		return in_array( $type, self::TYPES, true );
	}

	/**
	 * Decode a stored value into its readable { devices: ... } array.
	 *
	 * @param mixed                $value Stored option value (compressed string, legacy scalar, or empty).
	 * @param array<string, mixed> $args  Field args.
	 * @return array<string, mixed>
	 */
	public static function decode( $value, $args ) {
		$defaults = self::default_devices( $args );

		if ( is_array( $value ) ) {
			$decoded = $value;
		} elseif ( is_string( $value ) && '' !== $value && function_exists( 'woodmart_decompress' ) && woodmart_is_compressed_data( $value ) ) {
			$decoded = json_decode( woodmart_decompress( $value ), true );
		} elseif ( '' !== $value && null !== $value ) {
			// Legacy scalar: the controls read it as the desktop value.
			$decoded = array( 'devices' => array( 'desktop' => array( 'value' => $value ) ) );
		} else {
			$decoded = array();
		}

		if ( ! is_array( $decoded ) ) {
			$decoded = array();
		}

		$devices = isset( $decoded['devices'] ) && is_array( $decoded['devices'] ) ? $decoded['devices'] : array();
		$result  = array( 'devices' => array_merge( $defaults, $devices ) );

		if ( isset( $decoded['is_lock'] ) ) {
			$result['is_lock'] = $decoded['is_lock'];
		}

		return $result;
	}

	/**
	 * Merge per-device input over the current value and encode it for storage.
	 *
	 * Accepts both { devices: { desktop: {...} } } and the bare { desktop: {...} }
	 * shorthand, and only the devices actually present in the input are changed.
	 *
	 * @param mixed                $input   Ability input value.
	 * @param array<string, mixed> $args    Field args.
	 * @param mixed                $current Currently stored option value.
	 * @return string|WP_Error Storable compressed string, or WP_Error when the input is unusable.
	 */
	public static function encode( $input, $args, $current ) {
		if ( ! is_array( $input ) ) {
			return new WP_Error(
				'invalid_devices_value',
				__( 'Value must be an object keyed by device (desktop/tablet/mobile).', 'woodmart' )
			);
		}

		$type    = isset( $args['type'] ) ? $args['type'] : '';
		$allowed = array_keys( self::default_devices( $args ) );
		$input   = isset( $input['devices'] ) && is_array( $input['devices'] ) ? $input['devices'] : $input;
		$data    = self::decode( $current, $args );

		if ( isset( $input['is_lock'] ) ) {
			$data['is_lock'] = (bool) $input['is_lock'];
			unset( $input['is_lock'] );
		}

		foreach ( $input as $device => $device_value ) {
			if ( ! in_array( $device, $allowed, true ) ) {
				return new WP_Error(
					'invalid_device',
					sprintf(
						/* translators: 1: device key, 2: comma-separated list of supported devices. */
						__( 'Unknown device "%1$s". This setting supports: %2$s.', 'woodmart' ),
						$device,
						implode( ', ', $allowed )
					)
				);
			}

			if ( ! is_array( $device_value ) ) {
				return new WP_Error(
					'invalid_device_value',
					sprintf(
						/* translators: %s: device key. */
						__( 'The value for device "%s" must be an object.', 'woodmart' ),
						$device
					)
				);
			}

			$sanitized = self::sanitize_device_value( $device_value, $type, $args, $device );

			if ( is_wp_error( $sanitized ) ) {
				return $sanitized;
			}

			$data['devices'][ $device ] = array_merge(
				isset( $data['devices'][ $device ] ) && is_array( $data['devices'][ $device ] ) ? $data['devices'][ $device ] : array(),
				$sanitized
			);
		}

		if ( ! function_exists( 'woodmart_compress' ) ) {
			return new WP_Error( 'compress_unavailable', __( 'This value cannot be saved: woodmart_compress() is unavailable.', 'woodmart' ) );
		}

		return woodmart_compress( wp_json_encode( $data ) );
	}

	/**
	 * Human-readable description of the keys one device entry accepts.
	 *
	 * @param array<string, mixed> $args Field args.
	 * @return string
	 */
	public static function keys_description( $args ) {
		$type = isset( $args['type'] ) ? $args['type'] : '';
		$keys = 'dimensions' === $type ? self::dimension_keys( $args ) : array( 'value' );

		if ( ! empty( $args['range'] ) ) {
			$units = array_values( array_diff( array_keys( $args['range'] ), array( '-' ) ) );

			if ( $units ) {
				return sprintf( '%s, plus "unit" (one of: %s)', implode( ', ', $keys ), implode( ', ', $units ) );
			}
		}

		return implode( ', ', $keys );
	}

	/**
	 * Devices the field declares, with their default entries.
	 *
	 * @param array<string, mixed> $args Field args.
	 * @return array<string, array<string, mixed>>
	 */
	private static function default_devices( $args ) {
		if ( ! empty( $args['devices'] ) && is_array( $args['devices'] ) ) {
			return $args['devices'];
		}

		return array_fill_keys( self::FALLBACK_DEVICES, array() );
	}

	/**
	 * Value keys a dimensions field accepts (top/right/bottom/left, per field).
	 *
	 * @param array<string, mixed> $args Field args.
	 * @return array<int,string>
	 */
	private static function dimension_keys( $args ) {
		if ( ! empty( $args['dimensions'] ) && is_array( $args['dimensions'] ) ) {
			return array_keys( $args['dimensions'] );
		}

		return array( 'top', 'right', 'bottom', 'left' );
	}

	/**
	 * Validate and sanitize one device entry.
	 *
	 * @param array<string, mixed> $device_value Raw device entry from the input.
	 * @param string               $type         Field type.
	 * @param array<string, mixed> $args         Field args.
	 * @param string               $device       Device key, for error messages.
	 * @return array<string, mixed>|WP_Error
	 */
	private static function sanitize_device_value( $device_value, $type, $args, $device ) {
		$value_keys = 'dimensions' === $type ? self::dimension_keys( $args ) : array( 'value' );
		$sanitized  = array();

		foreach ( $device_value as $key => $value ) {
			if ( 'unit' === $key ) {
				$unit = self::sanitize_unit( $value, $args, $device );

				if ( is_wp_error( $unit ) ) {
					return $unit;
				}

				$sanitized['unit'] = $unit;
				continue;
			}

			if ( ! in_array( $key, $value_keys, true ) ) {
				return new WP_Error(
					'invalid_device_key',
					sprintf(
						/* translators: 1: key sent for the device, 2: device key, 3: comma-separated list of supported keys. */
						__( 'Unknown key "%1$s" for device "%2$s". Supported keys: %3$s (plus "unit").', 'woodmart' ),
						$key,
						$device,
						implode( ', ', $value_keys )
					)
				);
			}

			if ( '' === $value || null === $value ) {
				$sanitized[ $key ] = '';
				continue;
			}

			if ( ! is_numeric( $value ) ) {
				return new WP_Error(
					'invalid_device_number',
					sprintf(
						/* translators: 1: key sent for the device, 2: device key. */
						__( '"%1$s" for device "%2$s" must be a number or an empty string.', 'woodmart' ),
						$key,
						$device
					)
				);
			}

			// "+ 0" keeps an integer an integer and a decimal a float.
			$sanitized[ $key ] = $value + 0;
		}

		return $sanitized;
	}

	/**
	 * Validate a unit against the field's declared range units.
	 *
	 * @param mixed                $unit   Requested unit.
	 * @param array<string, mixed> $args   Field args.
	 * @param string               $device Device key, for error messages.
	 * @return string|WP_Error
	 */
	private static function sanitize_unit( $unit, $args, $device ) {
		$unit = is_scalar( $unit ) ? (string) $unit : '';

		if ( empty( $args['range'] ) || ! is_array( $args['range'] ) ) {
			return $unit;
		}

		$units = array_keys( $args['range'] );

		if ( ! in_array( $unit, $units, true ) ) {
			return new WP_Error(
				'invalid_device_unit',
				sprintf(
					/* translators: 1: unit sent for the device, 2: device key, 3: comma-separated list of supported units. */
					__( 'Unknown unit "%1$s" for device "%2$s". Supported units: %3$s.', 'woodmart' ),
					$unit,
					$device,
					implode( ', ', $units )
				)
			);
		}

		return $unit;
	}
}
