<?php
/**
 * AI abilities — shared permission callback.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities;

use WP_Error;
use WP_Post;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Public abilities require the edit_posts capability.
 *
 * That is a registration-time gate only: it says the user may edit *something*,
 * not that they may edit the post an ability was pointed at. Every handler that
 * writes must additionally run the object-level check for its target through
 * check_can_edit() / check_can_create() / check_can_set_status(), because
 * edit_posts is held by roles as low as Contributor.
 */
class Permission {
	/**
	 * Shared permission callback.
	 *
	 * @return bool
	 */
	public static function callback() {
		return current_user_can( 'edit_posts' );
	}

	/**
	 * Object-level check: may the current user edit this specific post?
	 *
	 * @param WP_Post|int $post Post object or ID.
	 * @return WP_Error|null WP_Error when the write must be refused, null when allowed.
	 */
	public static function check_can_edit( $post ) {
		$post = get_post( $post );

		if ( ! $post instanceof WP_Post ) {
			return new WP_Error( 'wd_ai_target_not_found', 'Target post was not found.', array( 'status' => 404 ) );
		}

		if ( ! current_user_can( 'edit_post', $post->ID ) ) {
			return new WP_Error(
				'wd_ai_cannot_edit_post',
				sprintf( 'You are not allowed to edit post %d.', $post->ID ),
				array( 'status' => 403 )
			);
		}

		return null;
	}

	/**
	 * Object-level check: may the current user create a post of this type?
	 *
	 * @param string $post_type Post type slug.
	 * @return WP_Error|null WP_Error when the write must be refused, null when allowed.
	 */
	public static function check_can_create( $post_type ) {
		$post_type_object = get_post_type_object( $post_type );

		if ( ! $post_type_object ) {
			return new WP_Error(
				'wd_ai_post_type_not_registered',
				sprintf( 'post_type "%s" is not registered on this site.', $post_type ),
				array( 'status' => 400 )
			);
		}

		if ( ! current_user_can( $post_type_object->cap->create_posts ) ) {
			return new WP_Error(
				'wd_ai_cannot_create_post',
				sprintf( 'You are not allowed to create content of type "%s".', $post_type ),
				array( 'status' => 403 )
			);
		}

		return null;
	}

	/**
	 * Object-level check: may the current user put a post of this type into this status?
	 *
	 * Only publish/private are gated — they make content publicly (or privately)
	 * live, which is exactly what publish_posts controls and what a Contributor
	 * must not be able to do through an ability.
	 *
	 * @param string $post_type Post type slug.
	 * @param string $status    Requested post status.
	 * @return WP_Error|null WP_Error when the write must be refused, null when allowed.
	 */
	public static function check_can_set_status( $post_type, $status ) {
		if ( ! in_array( $status, array( 'publish', 'private' ), true ) ) {
			return null;
		}

		$post_type_object = get_post_type_object( $post_type );

		if ( ! $post_type_object ) {
			return new WP_Error(
				'wd_ai_post_type_not_registered',
				sprintf( 'post_type "%s" is not registered on this site.', $post_type ),
				array( 'status' => 400 )
			);
		}

		if ( ! current_user_can( $post_type_object->cap->publish_posts ) ) {
			return new WP_Error(
				'wd_ai_cannot_publish_post',
				sprintf( 'You are not allowed to set status "%1$s" on content of type "%2$s".', $status, $post_type ),
				array( 'status' => 403 )
			);
		}

		return null;
	}

	/**
	 * Permission callback for theme-settings abilities.
	 *
	 * Theme settings are a site-wide surface, so they require the stronger
	 * manage_options capability rather than edit_posts.
	 *
	 * @return bool
	 */
	public static function manage_theme() {
		return current_user_can( 'manage_options' );
	}
}
