<?php
/**
 * AI abilities — shared support helpers.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shared helpers used across AI abilities.
 */
class Support {
	/**
	 * Resolve a target post ID from ability input.
	 *
	 * @param array $input Ability input.
	 * @return int
	 */
	public static function resolve_target_id( $input ) {
		return isset( $input['target_id'] ) ? (int) $input['target_id'] : 0;
	}

	/**
	 * Shared target_id input schema property.
	 *
	 * @return array
	 */
	public static function target_id_properties() {
		return array(
			'target_id' => array(
				'type'        => 'integer',
				'description' => 'Target post/page ID.',
			),
		);
	}

	/**
	 * Narrow a supported post-type whitelist down to the types this site actually
	 * registers.
	 *
	 * Two of the types the abilities support are conditional: 'product' exists only
	 * with WooCommerce active, and 'portfolio' only when the Portfolio theme option
	 * is on (see Post_Types::register_portfolio()). Call this at execute time, never
	 * at ability-registration time — post types register on `init`, so the answer is
	 * only reliable once the request is fully booted.
	 *
	 * @param array<int,string> $types Supported post types.
	 * @return array<int,string>
	 */
	public static function available_post_types( $types ) {
		return array_values( array_filter( $types, 'post_type_exists' ) );
	}

	/**
	 * Explain why a supported post type is missing from this site.
	 *
	 * @param array<int,string> $types Post types that are supported but not registered.
	 * @return string
	 */
	public static function unavailable_post_types_reason( $types ) {
		$reasons = array(
			'product'   => 'product requires WooCommerce to be active',
			'portfolio' => 'portfolio requires the Portfolio theme option to be enabled',
		);

		$hints = array();
		foreach ( $types as $type ) {
			if ( isset( $reasons[ $type ] ) ) {
				$hints[] = $reasons[ $type ];
			}
		}

		return $hints ? ' (' . implode( '; ', $hints ) . ')' : '';
	}
}
