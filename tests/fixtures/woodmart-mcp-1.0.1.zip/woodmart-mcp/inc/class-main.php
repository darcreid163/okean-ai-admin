<?php
/**
 * AI Abilities module bootstrap.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Bootstraps the AI Abilities module: loads its classes, builds the module's
 * object graph (composition root), and registers WordPress/abilities hooks.
 */
class Main {
	/**
	 * Load module classes, build the object graph, and register hooks.
	 *
	 * @return void
	 */
	public static function init() {
		self::require_files();

		$storage         = new Gutenberg\Storage();
		$block_catalog   = new Gutenberg\Block_Catalog();
		$client          = new Gutenberg\Template_Library\Client( WOODMART_BASE_URL );
		$image_localizer = new Gutenberg\Template_Library\Image_Localizer();

		$pending_changes = new Gutenberg\Pending_Changes( $storage );
		$finalization    = new Gutenberg\Finalization( $storage, $image_localizer, $pending_changes );
		$finalizer_page  = new Gutenberg\Finalizer_Page();
		$rest_controller = new Gutenberg\Rest_Controller( $storage, $finalization );

		$layout_conditions = new Layouts\Conditions( $storage );

		$handlers = array(
			new Gutenberg\Reader(),
			$pending_changes,
			$finalization,
			new Gutenberg\Create_Content( $pending_changes, $finalization ),
			new Gutenberg\Block_Docs( $block_catalog ),
			new Gutenberg\Templates( $client ),
			new Content\Search_Content(),
			new Content\Update_Content(),
			new Theme_Settings\Abilities(),
			new Headers\Header_Logo(),
			new Layouts\Layout_Reader( $storage, $layout_conditions ),
			new Layouts\Layout_Writer( $storage, $layout_conditions, $pending_changes, $finalization ),
		);

		add_action( 'init', array( $storage, 'register_post_type' ) );
		add_action( 'rest_api_init', array( $rest_controller, 'register_routes' ) );

		$finalizer_page->boot();

		if ( function_exists( 'wp_register_ability' ) ) {
			add_filter( 'wp_register_ability_args', array( self::class, 'ensure_object_input_default' ), 10, 2 );
			add_filter( 'wp_register_ability_args', array( self::class, 'fix_mcp_execute_output_schema' ), 10, 2 );
			add_action( 'wp_abilities_api_categories_init', array( self::class, 'register_categories' ) );
			add_action(
				'wp_abilities_api_init',
				function () use ( $handlers ) {
					foreach ( $handlers as $handler ) {
						$handler->register();
					}
				}
			);
		}
	}

	/**
	 * Require this module's files relative to the plugin's /inc directory.
	 *
	 * @return void
	 */
	private static function require_files() {
		$files = array(
			'class-permission',
			'class-support',
			'gutenberg/queue/class-storage',
			'gutenberg/class-block-normalizer',
			'gutenberg/class-block-editor',
			'gutenberg/catalog/class-block-catalog',
			'gutenberg/template-library/class-client',
			'gutenberg/template-library/class-markup-converter',
			'gutenberg/template-library/class-image-localizer',
			'gutenberg/queue/class-finalizer-page',
			'gutenberg/queue/class-finalization',
			'gutenberg/class-pending-changes',
			'gutenberg/class-reader',
			'gutenberg/class-create-content',
			'gutenberg/class-block-docs',
			'gutenberg/class-templates',
			'gutenberg/queue/class-rest-controller',
			'content/class-search-content',
			'content/class-update-content',
			'headers/class-header-logo',
			'theme-settings/class-devices-value',
			'theme-settings/class-value-format',
			'theme-settings/class-abilities',
			'layouts/class-layout-types',
			'layouts/class-conditions',
			'layouts/class-layout-reader',
			'layouts/class-layout-writer',
		);

		foreach ( $files as $file ) {
			require_once __DIR__ . '/' . $file . '.php';
		}
	}

	/**
	 * Give every all-optional woodmart/* object input schema an empty-object default.
	 *
	 * The MCP adapter forwards no input (null) when a tool is called with empty
	 * arguments, and WP_Ability::validate_input() then rejects null against a
	 * `type: object` schema ("input is not of type object"), which makes an
	 * all-optional ability uncallable with no arguments. WP_Ability::normalize_input()
	 * substitutes the schema's `default` when the input is null, so declaring a
	 * `{}` default lets a no-argument call resolve to an empty object and pass
	 * validation. Required-input abilities do not need a default and omitting it
	 * keeps their live JSON schemas unambiguous.
	 *
	 * @param array<string,mixed> $args Ability registration arguments.
	 * @param string              $name Ability name.
	 * @return array<string,mixed>
	 */
	public static function ensure_object_input_default( $args, $name ) {
		if ( 0 !== strpos( (string) $name, 'woodmart/' ) ) {
			return $args;
		}

		if ( empty( $args['input_schema'] ) || ! is_array( $args['input_schema'] ) ) {
			return $args;
		}

		if ( array_key_exists( 'default', $args['input_schema'] ) ) {
			return $args;
		}
		if ( ! empty( $args['input_schema']['required'] ) ) {
			return $args;
		}

		$type      = isset( $args['input_schema']['type'] ) ? $args['input_schema']['type'] : null;
		$is_object = 'object' === $type || ( is_array( $type ) && in_array( 'object', $type, true ) );

		if ( $is_object ) {
			$args['input_schema']['default'] = new \stdClass();
		}

		return $args;
	}

	/**
	 * Add the missing type to the execute-ability data output schema.
	 *
	 * Older MCP Adapter copies bundled by WooCommerce register the `data`
	 * property with a description but no required JSON Schema `type`. WordPress
	 * then emits undefined-array-key warnings whenever the dispatcher validates
	 * a successful ability result. Keep this compatibility shim narrowly scoped
	 * and leave already-correct adapter versions unchanged.
	 *
	 * @param array<string,mixed> $args Ability registration arguments.
	 * @param string              $name Ability name.
	 * @return array<string,mixed>
	 */
	public static function fix_mcp_execute_output_schema( $args, $name ) {
		if ( 'mcp-adapter/execute-ability' !== $name ) {
			return $args;
		}

		if ( ! isset( $args['output_schema']['properties']['data'] ) || ! is_array( $args['output_schema']['properties']['data'] ) ) {
			return $args;
		}

		if ( ! isset( $args['output_schema']['properties']['data']['type'] ) ) {
			$args['output_schema']['properties']['data']['type'] = array(
				'object',
				'array',
				'string',
				'number',
				'integer',
				'boolean',
				'null',
			);
		}

		return $args;
	}

	/**
	 * Register the ability categories used by this module's abilities.
	 *
	 * @return void
	 */
	public static function register_categories() {
		wp_register_ability_category(
			'woodmart-gutenberg',
			array(
				'label'       => 'WoodMart Gutenberg',
				'description' => 'Edit WoodMart-block pages. Keep the WoodMart -> Tools -> AI Block Queue admin page open while static blocks are queued and finalized.',
			)
		);
		wp_register_ability_category(
			'woodmart-content',
			array(
				'label'       => 'WoodMart Content',
				'description' => 'Find and create WordPress posts, pages, and HTML blocks.',
			)
		);
		wp_register_ability_category(
			'woodmart-theme',
			array(
				'label'       => 'WoodMart Theme',
				'description' => 'Read and update WoodMart theme settings.',
			)
		);
		wp_register_ability_category(
			'woodmart-layouts',
			array(
				'label'       => 'WoodMart Layouts',
				'description' => 'Discover, create, and target WoodMart template layouts (single product, shop archive, cart, checkout, etc.). Edit a layout\'s blocks with the woodmart-gutenberg abilities against its target_id; keep the AI Block Queue page open to finalize.',
			)
		);
	}
}
