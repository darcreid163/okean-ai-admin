<?php
/**
 * Agents Renderer class for the MCP server config.
 *
 * @package woodmart-mcp
 */

namespace XTS\AI_Abilities\Admin;

use XTS\Singleton;

/**
 * Agents Renderer class for the MCP server config.
 *
 * @package woodmart-mcp
 */
class Agents_Renderer extends Singleton {
	/**
	 * The singleton instance of the Agents class.
	 *
	 * @var Agents $agents The singleton instance of the Agents class.
	 */
	private $agents;

	/**
	 * The singleton instance of the Skills class.
	 *
	 * @var Skills $skills The singleton instance of the Skills class.
	 */
	private $skills;

	/**
	 * Sets up the sub-class instances and hooks the asset enqueue.
	 *
	 * @return void
	 */
	public function init() {
		$this->agents = Agents::get_instance();
		$this->skills = Skills::get_instance();

		add_action( 'xts_dashboard_before_page', array( $this, 'enqueue_scripts' ) );
	}

	/**
	 * Enqueues the MCP dashboard page CSS/JS.
	 *
	 * @return void
	 */
	public function enqueue_scripts() {
		$current_page = isset( $_GET['page'] ) ? wp_unslash( $_GET['page'] ) : ''; // phpcs:ignore

		if ( ! is_admin() || 'xts_mcp' !== $current_page ) {
			return;
		}

		wp_enqueue_style( 'wd-mcp', WOODMART_ASSETS . '/css/parts/page-mcp.css', array(), WOODMART_VERSION );

		wp_enqueue_script( 'wd-mcp', WOODMART_MCP_URL . '/assets/js/mcp.js', array( 'jquery' ), WOODMART_MCP_VERSION, true );

		$this->add_localize_settings();
	}

	/**
	 * Localizes the MCP dashboard script settings.
	 *
	 * @return void
	 */
	public function add_localize_settings() {
		wp_localize_script(
			'wd-mcp',
			'xtsMcpSettigns',
			array(
				'ajaxUrl'               => esc_url_raw( admin_url( 'admin-ajax.php' ) ),
				'restUrl'               => esc_url_raw( rest_url() ),
				'restNonce'             => wp_create_nonce( 'wp_rest' ),
				'enableMcpPluginsNonce' => wp_create_nonce( 'woodmart_enable_mcp_plugins_nonce' ),
				'skillSourceRepo'       => $this->skills->get_skill_source_repo(),
				'appPasswordRegistered' => $this->agents->get_list_of_registered_app_passwords(),
				'copiedText'            => __( 'Copied!', 'woodmart' ),
				'clickToCopyText'       => __( 'Click to copy', 'woodmart' ),
				'requestFailedText'     => __( 'Request failed.', 'woodmart' ),
				'pluginsEnabledText'    => __( 'Plugins enabled', 'woodmart' ),
				'pluginActiveText'      => __( 'Active', 'woodmart' ),
				'passwordCreatedText'   => __( 'Application password created:', 'woodmart' ),
			)
		);
	}

	/**
	 * Outputs the agent switcher markup.
	 *
	 * @return void
	 */
	public function render_agent_select_html() {
		?>
		<div class="xts-buttons-control">
			<div class="xts-btns-set xts-mcp-agent-switcher" role="group" aria-label="<?php esc_attr_e( 'AI agent', 'woodmart' ); ?>">
				<?php foreach ( $this->agents->get_agents() as $agent ) : ?>
					<button type="button" class="xts-set-item xts-set-btn xts-mcp-agent-btn<?php echo ! empty( $agent['default'] ) ? ' xts-active' : ''; ?>" data-agent="<?php echo esc_attr( $agent['slug'] ); ?>">
						<?php echo esc_html( $agent['label'] ); ?>
					</button>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Outputs all agent config variants.
	 *
	 * @return void
	 */
	public function render_agent_config_outputs_html() {
		?>
			<div class="xts-mcp-config-output-wrapper">
				<?php
				foreach ( $this->agents->get_agents() as $agent ) {
					if ( isset( $agent['output'] ) && 'fields' === $agent['output'] ) {
						$this->render_config_fields_output_html( $agent );
					} else {
						$this->render_config_code_output_html( $agent );
					}
				}
				?>
			</div>
		<?php
	}

	/**
	 * Outputs config values as fields for manual entry in an agent UI.
	 *
	 * @param array $agent Agent definition.
	 * @return void
	 */
	public function render_config_fields_output_html( $agent ) {
		$settings = $this->agents->get_server_settings();
		$fields   = array(
			array(
				'label'      => __( 'Name', 'woodmart' ),
				'value'      => $settings['name'],
				'copy_value' => true,
			),
			array(
				'label'      => __( 'Type', 'woodmart' ),
				'value'      => strtoupper( $settings['type'] ),
				'copy_value' => false,
			),
			array(
				'label'      => __( 'Command to launch', 'woodmart' ),
				'value'      => $settings['command'],
				'copy_value' => true,
			),
		);
		?>
		<div class="xts-mcp-config-output xts-hidden" data-agent="<?php echo esc_attr( $agent['slug'] ); ?>">
			<div class="xts-mcp-config-fields">
				<?php foreach ( $fields as $field ) : ?>
					<?php $this->render_config_field_html( $field ); ?>
				<?php endforeach; ?>
				<?php foreach ( $settings['args'] as $index => $argument ) : ?>
					<?php
					$this->render_config_field_html(
						array(
							'label'      => sprintf(
								/* translators: %d: Argument position. */
								esc_html__( 'Argument %d', 'woodmart' ),
								$index + 1
							),
							'value'      => $argument,
							'copy_value' => true,
						)
					);
					?>
				<?php endforeach; ?>
			</div>

			<div class="xts-mcp-config-fields-heading">
				<?php esc_html_e( 'Environment variables', 'woodmart' ); ?>
				<div class="xts-hint">
					<div class="xts-tooltip xts-top"><img data-src="<?php echo esc_url( WOODMART_MCP_URL . '/assets/images/environment-variables.png' ); ?>" src="<?php echo esc_url( WOODMART_MCP_URL . '/assets/images/environment-variables.png' ); ?>" alt="<?php esc_attr_e( 'Environment variables tooltip', 'woodmart' ); ?>"></div>
				</div>
			</div>

			<div class="xts-mcp-config-fields">
				<?php foreach ( $settings['env'] as $key => $value ) : ?>
					<?php
					$this->render_config_field_html(
						array(
							'label'      => $key,
							'value'      => $value,
							'copy_label' => true,
							'copy_value' => true,
						)
					);
					?>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Outputs one manual config field.
	 *
	 * @param array $field Field data and copy behavior.
	 * @return void
	 */
	private function render_config_field_html( $field ) {
		$field             = array_merge(
			array(
				'label'      => '',
				'value'      => '',
				'copy_label' => false,
				'copy_value' => false,
			),
			$field
		);
		$is_password       = 'WP_API_PASSWORD' === $field['label'];
		$is_empty_password = $is_password && ! $field['value'];
		?>
		<div class="xts-mcp-config-field">
			<?php if ( $field['copy_label'] ) : ?>
				<button type="button" class="xts-mcp-config-field-label xts-mcp-copy" data-mcp-copy-value title="<?php esc_attr_e( 'Click to copy', 'woodmart' ); ?>"><?php echo esc_html( $field['label'] ); ?></button>
			<?php else : ?>
				<span class="xts-mcp-config-field-label"><?php echo esc_html( $field['label'] ); ?></span>
			<?php endif; ?>
			<div class="xts-mcp-config-field-value">
				<?php if ( $field['copy_value'] ) : ?>
					<button
						type="button"
						class="xts-mcp-code-inline xts-mcp-config-copy-value xts-mcp-copy<?php echo $is_empty_password ? ' xts-mcp-highlight-line xts-mcp-config-value-empty' : ''; ?>"
						data-mcp-copy-value
						<?php if ( $is_empty_password ) : ?>
							data-empty-label="<?php esc_attr_e( 'Not generated yet', 'woodmart' ); ?>"
						<?php else : ?>
							title="<?php esc_attr_e( 'Click to copy', 'woodmart' ); ?>"
						<?php endif; ?>
					><?php echo esc_html( $field['value'] ); ?></button>
				<?php else : ?>
					<span class="xts-mcp-code-inline xts-mcp-config-copy-value"><?php echo esc_html( $field['value'] ); ?></span>
				<?php endif; ?>
			</div>
		</div>
		<?php
	}

	/**
	 * Outputs one formatted config block.
	 *
	 * @param array $agent Agent definition.
	 * @return void
	 */
	public function render_config_code_output_html( $agent ) {
		?>
		<div class="xts-mcp-config-output<?php echo empty( $agent['default'] ) ? ' xts-hidden' : ''; ?>" data-agent="<?php echo esc_attr( $agent['slug'] ); ?>">
			<div class="xts-mcp-copy-item">
				<pre class="xts-mcp-code-block" data-mcp-copy-value><?php echo wp_kses_post( $this->get_config_highlight_html( $agent['slug'] ) ); ?></pre>
				<button type="button" class="xts-btn xts-mcp-copy">
					<?php esc_html_e( 'Copy config', 'woodmart' ); ?>
				</button>
			</div>
		</div>
		<?php
	}

	/**
	 * Builds the escaped, highlighted config HTML for the given agent.
	 *
	 * @param string $agent Agent slug.
	 * @return string
	 */
	public function get_config_highlight_html( $agent = 'claude' ) {
		$lines = explode( "\n", $this->agents->get_config( $agent ) );

		foreach ( $lines as $i => $line ) {
			if ( false !== strpos( $line, 'WP_API_PASSWORD' ) && false !== strpos( $line, '""' ) ) {
				$lines[ $i ] = '<span class="xts-mcp-highlight-line" title="' . esc_attr__( 'Empty until you generate an application password above.', 'woodmart' ) . '">' . esc_html( $line ) . '</span>';
			} else {
				$lines[ $i ] = esc_html( $line );
			}
		}

		return implode( "\n", $lines );
	}
}
