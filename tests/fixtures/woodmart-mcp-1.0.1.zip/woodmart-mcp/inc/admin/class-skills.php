<?php
/**
 * Skills class for the MCP server config.
 *
 * @package woodmart-mcp
 */

namespace XTS\AI_Abilities\Admin;

use XTS\Singleton;
use ZipArchive;

/**
 * Skills class for the MCP server config.
 *
 * @package woodmart-mcp
 */
class Skills extends Singleton {
	/**
	 * Hooks the skill download AJAX action.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'wp_ajax_woodmart_download_mcp_skill', array( $this, 'download_mcp_skill' ) );
	}

	/**
	 * AJAX handler: builds and streams the skill zip archive for download.
	 *
	 * @return void
	 */
	public function download_mcp_skill() {
		if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'woodmart_download_mcp_skill_nonce', '_wpnonce', false ) ) {
			wp_die( esc_html__( 'You are not allowed to do this.', 'woodmart' ), '', array( 'response' => 403 ) );
		}

		$content = wp_remote_retrieve_body( wp_remote_get( $this->get_skill_source_url() ) );

		if ( ! $content || ! class_exists( 'ZipArchive' ) ) {
			wp_die( esc_html__( 'The skill archive could not be built. Please try again later.', 'woodmart' ) );
		}

		$tmp_file = wp_tempnam( 'woodmart-mcp.zip' );
		$zip      = new ZipArchive();

		$zip->open( $tmp_file, ZipArchive::OVERWRITE );
		$zip->addFromString( 'woodmart-mcp/SKILL.md', $content );
		$zip->close();

		global $wp_filesystem;

		if ( ! function_exists( 'WP_Filesystem' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		WP_Filesystem();

		nocache_headers();
		header( 'Content-Type: application/zip' );
		header( 'Content-Disposition: attachment; filename="woodmart-mcp.zip"' );
		header( 'Content-Length: ' . $wp_filesystem->size( $tmp_file ) );

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- binary zip content, streamed via WP_Filesystem.
		echo $wp_filesystem->get_contents( $tmp_file );

		wp_delete_file( $tmp_file );

		wp_die();
	}

	/**
	 * Gets the GitHub repo slug that hosts the skill source.
	 *
	 * @return string
	 */
	public function get_skill_source_repo() {
		return 'xtemos/woodmart-skill';
	}

	/**
	 * Gets the raw URL to the skill's SKILL.md source file.
	 *
	 * @return string
	 */
	public function get_skill_source_url() {
		$repo = $this->get_skill_source_repo();

		return 'https://raw.githubusercontent.com/' . $repo . '/master/SKILL.md';
	}

	/**
	 * Builds the nonced AJAX URL for downloading the skill archive.
	 *
	 * @return string
	 */
	public function get_skill_download_url() {
		return wp_nonce_url(
			add_query_arg(
				array(
					'action' => 'woodmart_download_mcp_skill',
				),
				admin_url( 'admin-ajax.php' )
			),
			'woodmart_download_mcp_skill_nonce'
		);
	}
}
