<?php
/**
 * Agents class for the MCP server config.
 *
 * @package woodmart-mcp
 */

namespace XTS\AI_Abilities\Admin;

use XTS\Singleton;
use WP_Application_Passwords;

/**
 * Class Agents.
 * Registers and manages the supported agents for the MCP server config.
 *
 * @package woodmart-mcp
 */
class Agents extends Singleton {
	/**
	 * The singleton instance of the Agents class.
	 *
	 * @var array $agents List of registered agent definitions.
	 */
	private $agents = array();

	/**
	 * Registers the supported agents.
	 *
	 * @return void
	 */
	public function init() {
		add_action( 'init', array( $this, 'register_agents' ) );
	}

	/**
	 * Builds the agent definitions list and stores it in $agents.
	 *
	 * @return void
	 */
	public function register_agents() {
		$definitions = array(
			array(
				'slug'    => 'claude',
				'label'   => __( 'Claude (Desktop)', 'woodmart' ),
				'default' => true,
				'format'  => 'json',
			),
			array(
				'slug'   => 'claude-code',
				'label'  => __( 'Claude Code (CLI)', 'woodmart' ),
				'format' => 'json',
			),
			array(
				'slug'   => 'codex-app',
				'label'  => __( 'Codex (Desktop)', 'woodmart' ),
				'format' => 'json',
				'output' => 'fields',
			),
			array(
				'slug'   => 'codex',
				'label'  => __( 'Codex (CLI)', 'woodmart' ),
				'format' => 'toml',
			),
			array(
				'slug'   => 'cursor',
				'label'  => __( 'Cursor', 'woodmart' ),
				'format' => 'json',
			),
		);

		foreach ( $definitions as $agent ) {
			$this->agents[ $agent['slug'] ] = $agent;
		}
	}

	/**
	 * Gets all registered agent definitions.
	 *
	 * @return array
	 */
	public function get_agents() {
		return $this->agents;
	}

	/**
	 * Gets the default agent slug.
	 *
	 * @return string|null The slug of the default agent, or null if none is set.
	 */
	public function get_default_agent_slug() {
		foreach ( $this->agents as $agent ) {
			if ( ! empty( $agent['default'] ) ) {
				return $agent['slug'];
			}
		}

		return null;
	}

	/**
	 * Gets the application password registration state for each agent.
	 *
	 * @return array{string: bool} Associative array of agent slugs to registration state.
	 */
	public function get_list_of_registered_app_passwords() {
		$registered_app = array_fill_keys( array_keys( $this->agents ), false );
		$current_user   = wp_get_current_user();

		if ( ! $current_user->exists() || ! class_exists( 'WP_Application_Passwords' ) ) {
			return $registered_app;
		}

		$passwords        = WP_Application_Passwords::get_user_application_passwords( $current_user->ID );
		$registered_names = array_fill_keys(
			array_filter( wp_list_pluck( $passwords, 'name' ), 'is_string' ),
			true
		);

		foreach ( array_keys( $registered_app ) as $agent_slug ) {
			$registered_app[ $agent_slug ] = isset( $registered_names[ 'WoodMart MCP - ' . $agent_slug ] );
		}

		return $registered_app;
	}

	/**
	 * Checks if the default agent has a registered application password.
	 *
	 * @return bool True if the default agent has a registered application password, false otherwise.
	 */
	public function check_default_agent_registered() {
		$default_agent_slug       = $this->get_default_agent_slug();
		$registered_app_passwords = $this->get_list_of_registered_app_passwords();

		return isset( $registered_app_passwords[ $default_agent_slug ] ) && $registered_app_passwords[ $default_agent_slug ];
	}

	/**
	 * Builds the MCP config snippet for the given agent.
	 *
	 * @param string $agent Agent slug.
	 * @return string
	 */
	public function get_config( $agent = 'claude' ) {
		if ( ! isset( $this->agents[ $agent ] ) ) {
			return '';
		}

		$settings = $this->get_server_settings();

		if ( 'toml' === $this->get_agent_format( $agent ) ) {
			return $this->get_toml_config( $settings );
		}

		return $this->get_json_config( $settings );
	}

	/**
	 * Gets the config format for the given agent.
	 *
	 * @param string $agent Agent slug.
	 * @return string
	 */
	private function get_agent_format( $agent ) {
		return isset( $this->agents[ $agent ]['format'] ) ? $this->agents[ $agent ]['format'] : 'json';
	}

	/**
	 * Gets the shared MCP server settings used by every agent output.
	 *
	 * @return array MCP server settings.
	 */
	public function get_server_settings() {
		return array(
			'name'    => 'woodmart',
			'type'    => 'stdio',
			'command' => 'npx',
			'args'    => array( '-y', '@automattic/mcp-wordpress-remote@latest' ),
			'env'     => $this->build_env(),
		);
	}

	/**
	 * Builds the env vars for the MCP server config.
	 *
	 * @return array
	 */
	private function build_env() {
		$env = array(
			'WP_API_URL'      => home_url() . '/wp-json/mcp/mcp-adapter-default-server',
			'WP_API_USERNAME' => wp_get_current_user()->user_login,
			'WP_API_PASSWORD' => '',
		);

		if ( $this->is_local_guess() ) {
			$env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';
		}

		return $env;
	}

	/**
	 * Guesses whether the current site is running on a local environment.
	 *
	 * @return bool
	 */
	public function is_local_guess() {
		$xts_mcp_host           = wp_parse_url( home_url(), PHP_URL_HOST );
		$xts_mcp_is_local_guess = 'local' === wp_get_environment_type()
			|| preg_match( '/(^|\.)(local|test|localhost)$/i', (string) $xts_mcp_host )
			|| in_array( $xts_mcp_host, array( 'localhost', '127.0.0.1', '::1' ), true );

		return $xts_mcp_is_local_guess;
	}

	/**
	 * Builds the Codex TOML config snippet.
	 *
	 * @param array $settings MCP server settings.
	 * @return string
	 */
	private function get_toml_config( $settings ) {
		$lines = array(
			'[mcp_servers.' . $settings['name'] . ']',
			'command = "' . addslashes( $settings['command'] ) . '"',
			'args = ["' . implode( '", "', array_map( 'addslashes', $settings['args'] ) ) . '"]',
			'',
			'[mcp_servers.' . $settings['name'] . '.env]',
		);

		foreach ( $settings['env'] as $key => $value ) {
			$lines[] = $key . ' = "' . addslashes( $value ) . '"';
		}

		return implode( "\n", $lines );
	}

	/**
	 * Builds the JSON MCP server config snippet.
	 *
	 * @param array $settings MCP server settings.
	 * @return string|false
	 */
	private function get_json_config( $settings ) {
		return wp_json_encode(
			array(
				'mcpServers' => array(
					$settings['name'] => array(
						'command' => $settings['command'],
						'args'    => $settings['args'],
						'env'     => $settings['env'],
					),
				),
			),
			JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES
		);
	}
}
