<?php
/**
 * MCP class.
 * Admin page for managing the WoodMart MCP integration.
 *
 * @package woodmart-mcp
 */

namespace XTS\AI_Abilities\Admin;

use XTS\Singleton;
use XTS\Admin\Modules\Dashboard;
use wfConfig;

/**
 * Facade over the MCP sub-classes so consumers (e.g. the dashboard template)
 * only ever deal with a single Main::get_instance().
 */
class Main extends Singleton {
	/**
	 * The singleton instance of the Plugins class.
	 *
	 * @var Plugins $plugins The singleton instance of the Plugins class.
	 */
	private $plugins;

	/**
	 * The singleton instance of the Skills class.
	 *
	 * @var Skills $skills The singleton instance of the Skills class.
	 */
	private $skills;

	/**
	 * The singleton instance of the Agents class.
	 *
	 * @var Agents $agents The singleton instance of the Agents class.
	 */
	private $agents;

	/**
	 * The singleton instance of the Agents_Renderer class.
	 *
	 * @var Agents_Renderer $agents_renderer The singleton instance of the Agents_Renderer class.
	 */
	private $agents_renderer;

	/**
	 * Loads the MCP sub-classes and instantiates their singletons.
	 *
	 * @return void
	 */
	public function init() {
		$this->include_files();

		$this->plugins         = Plugins::get_instance();
		$this->skills          = Skills::get_instance();
		$this->agents          = Agents::get_instance();
		$this->agents_renderer = Agents_Renderer::get_instance();

		add_action( 'admin_menu', array( $this, 'register_menu' ) );
	}

	/**
	 * Requires the MCP sub-class files.
	 *
	 * @return void
	 */
	public function include_files() {
		$files = array(
			'class-plugins',
			'class-skills',
			'class-agents',
			'class-agents-renderer',
		);

		foreach ( $files as $file ) {
			require_once __DIR__ . '/' . $file . '.php';
		}
	}

	/**
	 * Register the MCP page under the WoodMart dashboard menu.
	 *
	 * @return void
	 */
	public function register_menu() {
		add_submenu_page(
			'xts_dashboard',
			esc_html__( 'MCP', 'woodmart' ),
			esc_html__( 'MCP', 'woodmart' ),
			apply_filters( 'woodmart_capability_menu_page', 'manage_options', 'xts_mcp' ),
			'xts_mcp',
			array( $this, 'render_page' ),
			10
		);
	}

	/**
	 * Render the MCP page inside the WoodMart dashboard chrome.
	 *
	 * @return void
	 */
	public function render_page() {
		$capability = apply_filters( 'woodmart_capability_menu_page', 'manage_options', 'xts_mcp' );

		if ( ! current_user_can( $capability ) ) {
			return;
		}

		$dashboard = Dashboard::get_instance();

		do_action( 'xts_dashboard_before_page' );

		$dashboard->print_header();
		include WOODMART_MCP_PATH . '/templates/mcp.php';
		$dashboard->print_footer();
	}

	/**
	 * Checks whether the required MCP plugins are active.
	 *
	 * @return bool
	 */
	public function check_mcp_plugins_is_active() {
		return $this->plugins->check_mcp_plugins_is_active();
	}

	/**
	 * Gets the MCP plugins with their current activation status.
	 *
	 * @return array
	 */
	public function get_mcp_plugins() {
		return $this->plugins->get_mcp_plugins();
	}

	/**
	 * Gets the URL for downloading the MCP skill archive.
	 *
	 * @return string
	 */
	public function get_skill_download_url() {
		return $this->skills->get_skill_download_url();
	}

	/**
	 * Checks whether the default agent has an application password registered.
	 *
	 * @return bool
	 */
	public function check_default_agent_registered() {
		return $this->agents->check_default_agent_registered();
	}

	/**
	 * Gets the application passwords status.
	 *
	 * @return string
	 */
	public function get_app_pass_status() {
		if ( wp_is_application_passwords_available() ) {
			return 'available';
		}

		if ( ! wp_is_application_passwords_supported() ) {
			return 'unsupported_environment';
		}

		if ( class_exists( wfConfig::class ) && (bool) wfConfig::get( 'loginSec_disableApplicationPasswords' ) ) {
			return 'wordfence';
		}

		return 'filtered';
	}

	/**
	 * Outputs the agent select HTML markup.
	 *
	 * @return void
	 */
	public function render_agent_select_html() {
		$this->agents_renderer->render_agent_select_html();
	}

	/**
	 * Outputs the per-agent config output HTML markup.
	 *
	 * @return void
	 */
	public function render_agent_config_outputs_html() {
		$this->agents_renderer->render_agent_config_outputs_html();
	}
}

Main::get_instance();
