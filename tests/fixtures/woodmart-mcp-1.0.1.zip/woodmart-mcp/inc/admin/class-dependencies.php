<?php
/**
 * WoodMart MCP plugin dependencies.
 *
 * @package woodmart-mcp
 */

namespace XTS\AI_Abilities;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Installs and activates the plugins required by WoodMart MCP.
 */
class Dependencies {
	const ERRORS_TRANSIENT = 'woodmart_mcp_dependency_errors';

	/**
	 * Register dependency-related admin hooks.
	 *
	 * @return void
	 */
	public static function boot() {
		add_action( 'admin_notices', array( self::class, 'render_errors_notice' ) );
	}

	/**
	 * Get the dependency definitions used by activation and the MCP admin page.
	 *
	 * @return array<int,array<string,string>>
	 */
	public static function definitions() {
		return array(
			array(
				'name' => 'AI',
				'slug' => 'ai',
				'file' => 'ai/ai.php',
			),
			array(
				'name'   => 'MCP Adapter',
				'slug'   => 'mcp-adapter',
				'file'   => 'mcp-adapter/mcp-adapter.php',
				'source' => 'https://github.com/WordPress/mcp-adapter/releases/latest/download/mcp-adapter.zip',
			),
		);
	}

	/**
	 * Activation-hook callback.
	 *
	 * @param bool $network_wide Whether the plugin is being network-activated.
	 * @return void
	 */
	public static function activate( $network_wide ) {
		self::ensure( $network_wide );
	}

	/**
	 * Ensure every dependency is installed and active.
	 *
	 * @param bool $network_wide Whether dependencies should be network-activated.
	 * @return array<int,string> Installation or activation error messages.
	 */
	public static function ensure( $network_wide = false ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';

		$errors = array();

		foreach ( self::definitions() as $dependency ) {
			if ( ! file_exists( WP_PLUGIN_DIR . '/' . $dependency['file'] ) ) {
				$installed = self::install( $dependency );

				if ( is_wp_error( $installed ) ) {
					$errors[] = $dependency['name'] . ': ' . $installed->get_error_message();
					continue;
				}
			}

			$is_active = $network_wide ? is_plugin_active_for_network( $dependency['file'] ) : is_plugin_active( $dependency['file'] );

			if ( ! $is_active ) {
				$activated = activate_plugin( $dependency['file'], '', $network_wide, true );

				if ( is_wp_error( $activated ) ) {
					$errors[] = $dependency['name'] . ': ' . $activated->get_error_message();
				}
			}
		}

		if ( $errors ) {
			set_transient( self::ERRORS_TRANSIENT, $errors, HOUR_IN_SECONDS );
		} else {
			delete_transient( self::ERRORS_TRANSIENT );
		}

		return $errors;
	}

	/**
	 * Install one missing dependency.
	 *
	 * @param array<string,string> $dependency Dependency definition.
	 * @return true|\WP_Error
	 */
	private static function install( $dependency ) {
		$download_url = isset( $dependency['source'] ) ? $dependency['source'] : '';

		if ( ! $download_url ) {
			require_once ABSPATH . 'wp-admin/includes/plugin-install.php';

			$api = plugins_api(
				'plugin_information',
				array(
					'slug'   => $dependency['slug'],
					'fields' => array( 'sections' => false ),
				)
			);

			if ( is_wp_error( $api ) ) {
				return $api;
			}

			$download_url = isset( $api->download_link ) ? $api->download_link : '';
		}

		if ( ! $download_url ) {
			return new \WP_Error( 'woodmart_mcp_missing_download_url', 'The dependency download URL is unavailable.' );
		}

		require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';

		$upgrader = new \Plugin_Upgrader( new \Automatic_Upgrader_Skin() );
		$result   = $upgrader->install( $download_url );

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		if ( ! $result ) {
			return new \WP_Error( 'woodmart_mcp_dependency_install_failed', 'WordPress could not install the dependency.' );
		}

		wp_clean_plugins_cache( true );

		return true;
	}

	/**
	 * Show dependency errors captured by activation or the MCP page.
	 *
	 * @return void
	 */
	public static function render_errors_notice() {
		$errors = get_transient( self::ERRORS_TRANSIENT );

		if ( ! $errors || ! current_user_can( 'install_plugins' ) ) {
			return;
		}

		delete_transient( self::ERRORS_TRANSIENT );

		?>
		<div class="notice notice-error">
			<p>
				<strong><?php esc_html_e( 'WoodMart MCP could not install or activate all required plugins:', 'woodmart' ); ?></strong>
			</p>
			<ul>
				<?php foreach ( $errors as $error ) : ?>
					<li><?php echo esc_html( $error ); ?></li>
				<?php endforeach; ?>
			</ul>
		</div>
		<?php
	}
}
