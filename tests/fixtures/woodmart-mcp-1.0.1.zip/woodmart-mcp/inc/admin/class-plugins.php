<?php
/**
 * Plugins class for the MCP server config.
 *
 * @package woodmart-mcp
 */

namespace XTS\AI_Abilities\Admin;

use XTS\Singleton;
use XTS\AI_Abilities\Dependencies;

/**
 * Plugins class for the MCP server config.
 *
 * @package woodmart-mcp
 */
class Plugins extends Singleton {
	/**
	 * Hooks the MCP plugins into TGMPA and the enable AJAX action.
	 *
	 * @return void
	 */
	public function init() {
		add_filter( 'woodmart_tgmpa_plugins', array( $this, 'register_mcp_plugins' ) );
		add_filter( 'woodmart_setup_wizard_plugins_list', array( $this, 'exclude_mcp_plugins_from_list' ) );

		add_action( 'wp_ajax_woodmart_enable_mcp_plugins', array( $this, 'enable_mcp_plugins' ) );
	}

	/**
	 * Appends the MCP plugins to the TGMPA required plugins list.
	 *
	 * @param array $plugins TGMPA plugins list.
	 * @return array
	 */
	public function register_mcp_plugins( $plugins ) {
		foreach ( $this->get_mcp_plugins_for_registration() as $plugin ) {
			$plugins[] = $plugin;
		}

		return $plugins;
	}

	/**
	 * Removes the MCP plugins from the xts_plugins / setup wizard plugins list.
	 *
	 * @param array $plugins Setup wizard plugins list, keyed by slug.
	 * @return array
	 */
	public function exclude_mcp_plugins_from_list( $plugins ) {
		foreach ( $this->get_mcp_plugins_for_registration() as $plugin ) {
			unset( $plugins[ $plugin['slug'] ] );
		}

		return $plugins;
	}

	/**
	 * Gets the list of plugins required for MCP.
	 *
	 * @return array
	 */
	public function get_mcp_plugins() {
		$tgmpa   = call_user_func( array( get_class( $GLOBALS['tgmpa'] ), 'get_instance' ) );
		$plugins = $this->get_mcp_plugins_for_registration();

		foreach ( $plugins as $key => $plugin ) {
			$plugins[ $key ]['is_active'] = $tgmpa->is_plugin_active( $plugin['slug'] );
		}

		return $plugins;
	}

	/**
	 * Gets MCP plugin definitions used during TGMPA registration.
	 *
	 * This method must not query TGMPA because it runs while the TGMPA plugin
	 * list is still being registered.
	 *
	 * @return array
	 */
	private function get_mcp_plugins_for_registration() {
		$plugins = array();

		foreach ( Dependencies::definitions() as $dependency ) {
			$plugin = array(
				'name'        => $dependency['name'],
				'slug'        => $dependency['slug'],
				'required'    => false,
				'hide_notice' => true,
			);

			if ( ! empty( $dependency['source'] ) ) {
				$plugin['source'] = $dependency['source'];
			}

			if ( 'ai' === $dependency['slug'] ) {
				$plugin['description'] = esc_html__( 'exposes theme actions via the WordPress Abilities API.', 'woodmart' );
			} elseif ( 'mcp-adapter' === $dependency['slug'] ) {
				$plugin['description'] = esc_html__( 'turns those actions into an MCP server your agent can connect to.', 'woodmart' );
			}

			$plugins[] = $plugin;
		}

		return $plugins;
	}

	/**
	 * AJAX handler: installs and activates the MCP plugins.
	 *
	 * @return void
	 */
	public function enable_mcp_plugins() {
		if ( ! current_user_can( 'manage_options' ) || ! check_ajax_referer( 'woodmart_enable_mcp_plugins_nonce', '_wpnonce', false ) ) {
			wp_send_json_error( array( 'message' => esc_html__( 'You are not allowed to do this.', 'woodmart' ) ) );
		}

		$failed = Dependencies::ensure();

		if ( $failed ) {
			wp_send_json_error(
				array(
					'message' => sprintf(
						/* translators: %s: comma-separated dependency error messages. */
						esc_html__( 'Could not install/activate: %s. Please install them manually from Plugins → Add New.', 'woodmart' ),
						implode( ', ', $failed )
					),
				)
			);
		}

		wp_send_json_success( array( 'message' => esc_html__( 'Plugins are installed and active.', 'woodmart' ) ) );
	}

	/**
	 * Checks whether all MCP plugins are active.
	 *
	 * @return bool
	 */
	public function check_mcp_plugins_is_active() {
		return ! in_array( false, array_column( $this->get_mcp_plugins(), 'is_active' ), true );
	}
}
