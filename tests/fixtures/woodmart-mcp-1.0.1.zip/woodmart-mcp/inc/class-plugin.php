<?php
/**
 * WoodMart MCP plugin bootstrap.
 *
 * @package woodmart-mcp
 */

namespace XTS\AI_Abilities;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Loads the plugin dependencies and initializes its functionality.
 */
class Plugin {
	/**
	 * Register the plugin hooks.
	 *
	 * @param string $plugin_file Absolute path to the main plugin file.
	 * @return void
	 */
	public static function boot( $plugin_file ) {
		require_once WOODMART_MCP_PATH . '/inc/admin/class-dependencies.php';

		Dependencies::boot();

		register_activation_hook( $plugin_file, array( Dependencies::class, 'activate' ) );
		add_action( 'after_setup_theme', array( self::class, 'init' ), 20 );
	}

	/**
	 * Initialize the integration after the active theme has defined its API.
	 *
	 * @return void
	 */
	public static function init() {
		if ( ! defined( 'WOODMART_VERSION' ) || ! defined( 'WOODMART_BASE_URL' ) ) {
			return;
		}

		require_once WOODMART_MCP_PATH . '/inc/class-main.php';

		if ( is_admin() ) {
			require_once WOODMART_MCP_PATH . '/inc/admin/class-main.php';
		}

		Main::init();
	}
}
