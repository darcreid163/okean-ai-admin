<?php
/**
 * AI ability — rename/re-slug/re-status/re-parent an existing post.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Content;

use WP_Error;
use XTS\AI_Abilities\Permission;
use XTS\AI_Abilities\Support;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ability handler that updates a post's title, slug, status, or parent.
 *
 * Deliberately does not touch post_content: block content is queued and serialized
 * by the AI Block Queue page (see Pending_Changes / Finalization), because only the
 * browser can run the blocks' save(). These fields need none of that, so they are
 * written straight through and are live immediately.
 */
class Update_Content {

	/**
	 * Post types whose fields the AI may edit.
	 *
	 * The queue's own posts (Storage::POST_TYPE) are intentionally absent: gutenberg-*
	 * abilities accept any target_id, so without a whitelist here a caller could rename
	 * a pending-change batch and corrupt the queue.
	 *
	 * @var array<int,string>
	 */
	const EDITABLE_POST_TYPES = array( 'page', 'post', 'portfolio', 'product', 'cms_block', 'woodmart_layout' );

	/**
	 * Statuses the AI may set.
	 *
	 * @var array<int,string>
	 */
	const EDITABLE_STATUSES = array( 'draft', 'publish', 'pending', 'private' );

	/**
	 * Update a post's title, slug, status, and/or parent.
	 *
	 * @param array<string,mixed> $input Ability input.
	 * @return array<string,mixed>|WP_Error
	 */
	public function ability_update_content( $input ) {
		$target_id = Support::resolve_target_id( $input );
		$target    = $target_id ? get_post( $target_id ) : null;

		if ( ! $target ) {
			return new WP_Error( 'wd_ai_target_not_found', sprintf( 'Target post %d was not found.', $target_id ) );
		}

		if ( ! in_array( $target->post_type, self::EDITABLE_POST_TYPES, true ) ) {
			return new WP_Error(
				'wd_ai_post_type_not_editable',
				sprintf(
					'Post %1$d is a "%2$s"; only these post types can be updated: %3$s.',
					$target_id,
					$target->post_type,
					implode( ', ', self::EDITABLE_POST_TYPES )
				)
			);
		}

		$denied = Permission::check_can_edit( $target );
		if ( $denied ) {
			return $denied;
		}

		$postarr = array( 'ID' => $target->ID );
		$before  = array();

		if ( isset( $input['title'] ) ) {
			$title = trim( (string) $input['title'] );
			if ( '' === $title ) {
				return new WP_Error( 'wd_ai_empty_title', 'title cannot be empty.' );
			}
			$before['title']       = $target->post_title;
			$postarr['post_title'] = sanitize_text_field( $title );
		}

		if ( isset( $input['slug'] ) ) {
			$slug = sanitize_title( (string) $input['slug'] );
			if ( '' === $slug ) {
				return new WP_Error( 'wd_ai_empty_slug', 'slug sanitizes to an empty string; pass a slug with at least one alphanumeric character.' );
			}
			$before['slug']       = $target->post_name;
			$postarr['post_name'] = $slug;
		}

		if ( isset( $input['status'] ) ) {
			$status = sanitize_key( (string) $input['status'] );
			if ( ! in_array( $status, self::EDITABLE_STATUSES, true ) ) {
				return new WP_Error( 'wd_ai_invalid_status', sprintf( 'status must be one of: %s.', implode( ', ', self::EDITABLE_STATUSES ) ) );
			}

			$denied = Permission::check_can_set_status( $target->post_type, $status );
			if ( $denied ) {
				return $denied;
			}

			$before['status']       = $target->post_status;
			$postarr['post_status'] = $status;
		}

		if ( isset( $input['parent_id'] ) ) {
			$parent = $this->validate_parent( (int) $input['parent_id'], $target );
			if ( is_wp_error( $parent ) ) {
				return $parent;
			}
			$before['parent_id']    = (int) $target->post_parent;
			$postarr['post_parent'] = $parent;
		}

		if ( 1 === count( $postarr ) ) {
			return new WP_Error( 'wd_ai_nothing_to_update', 'Pass at least one of: title, slug, status, parent_id.' );
		}

		// Capture the live URL before the write: once the slug or parent changes there
		// is no way to reconstruct what the old permalink was.
		$old_url = get_permalink( $target );

		$updated = wp_update_post( $postarr, true );
		if ( is_wp_error( $updated ) ) {
			return $updated;
		}

		// Re-read: WordPress rewrites post_name when the slug collides, so the value
		// that landed is not always the value that was sent.
		$fresh = get_post( $target->ID );

		return array(
			'id'        => (int) $fresh->ID,
			'post_type' => $fresh->post_type,
			'before'    => $before,
			'after'     => array(
				'title'     => $fresh->post_title,
				'slug'      => $fresh->post_name,
				'status'    => $fresh->post_status,
				'parent_id' => (int) $fresh->post_parent,
			),
			'url'       => get_permalink( $fresh->ID ),
			'edit_url'  => get_edit_post_link( $fresh->ID, 'raw' ),
			'warnings'  => $this->url_warnings( $target, $fresh, $old_url ),
		);
	}

	/**
	 * Warn when the write moved a live URL.
	 *
	 * WordPress stores _wp_old_slug so the old URL keeps redirecting, but only for
	 * published, non-hierarchical post types (see wp_check_for_changed_slugs()).
	 * A published page is therefore the dangerous case: its old URL starts 404ing
	 * with no redirect, and nothing in the response would otherwise say so.
	 *
	 * @param \WP_Post $before  Post as it was before the update.
	 * @param \WP_Post $after   Post as it is now.
	 * @param string   $old_url Permalink captured before the update.
	 * @return array<int,string>
	 */
	private function url_warnings( $before, $after, $old_url ) {
		$warnings = array();

		$url_moved = $before->post_name !== $after->post_name || (int) $before->post_parent !== (int) $after->post_parent;

		if ( ! $url_moved || 'publish' !== $before->post_status ) {
			return $warnings;
		}

		$redirected = ! is_post_type_hierarchical( $after->post_type ) && 'publish' === $after->post_status;

		if ( $redirected ) {
			$warnings[] = sprintf(
				'The public URL changed from %1$s to %2$s. WordPress saved the old slug, so the old URL redirects to the new one.',
				$old_url,
				get_permalink( $after->ID )
			);
		} else {
			$warnings[] = sprintf(
				'The public URL changed from %1$s to %2$s. WordPress does NOT create an old-slug redirect for the "%3$s" post type, so the old URL now returns 404. Any existing links or bookmarks to it are broken until a redirect is added manually.',
				$old_url,
				get_permalink( $after->ID ),
				$after->post_type
			);
		}

		return $warnings;
	}

	/**
	 * Validate a new post_parent for the target.
	 *
	 * @param int      $parent_id Requested parent id (0 removes the parent).
	 * @param \WP_Post $target    Post being updated.
	 * @return int|WP_Error Sanitized parent id.
	 */
	private function validate_parent( $parent_id, $target ) {
		if ( $parent_id <= 0 ) {
			return 0;
		}

		if ( $parent_id === (int) $target->ID ) {
			return new WP_Error( 'wd_ai_invalid_parent', 'parent_id cannot be the post itself.' );
		}

		$parent = get_post( $parent_id );
		if ( ! $parent ) {
			return new WP_Error( 'wd_ai_invalid_parent', sprintf( 'parent_id %d was not found.', $parent_id ) );
		}

		if ( $parent->post_type !== $target->post_type ) {
			return new WP_Error(
				'wd_ai_invalid_parent',
				sprintf( 'parent_id %1$d is a "%2$s"; the parent must be the same post type as the target ("%3$s").', $parent_id, $parent->post_type, $target->post_type )
			);
		}

		if ( ! is_post_type_hierarchical( $target->post_type ) ) {
			return new WP_Error(
				'wd_ai_invalid_parent',
				sprintf( 'Post type "%s" is not hierarchical, so it cannot have a parent.', $target->post_type )
			);
		}

		// Walk up from the requested parent: if the target is one of its ancestors,
		// setting it would detach the branch into an unreachable loop.
		$ancestor = $parent;
		while ( $ancestor && (int) $ancestor->post_parent > 0 ) {
			if ( (int) $ancestor->post_parent === (int) $target->ID ) {
				return new WP_Error( 'wd_ai_invalid_parent', sprintf( 'parent_id %d is a descendant of the post; that would create a loop.', $parent_id ) );
			}
			$ancestor = get_post( (int) $ancestor->post_parent );
		}

		return $parent_id;
	}

	/**
	 * Register the woodmart/update-content ability (woodmart-content category).
	 *
	 * @return void
	 */
	public function register() {
		wp_register_ability(
			'woodmart/update-content',
			array(
				'label'               => 'Update WoodMart Content',
				'description'         => 'Rename an existing post/page/portfolio project/product/HTML block/layout, or change its slug, status, or parent. Applies immediately — this is not queued and does not need the AI Block Queue page (it never touches block content; use gutenberg-edit-blocks for that). Two inputs are outward-facing and need the user\'s confirmation first: status "publish" makes the content publicly visible, and changing slug (or parent_id) on already-published content moves its public URL — for pages that breaks the old URL with a 404, since WordPress only auto-redirects old slugs for non-hierarchical types. The response\'s "warnings" array reports it whenever a live URL moved.',
				'category'            => 'woodmart-content',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'target_id' => array(
							'type'        => 'integer',
							'description' => 'Post id to update (from search-content or list-layouts).',
						),
						'title'     => array(
							'type'        => 'string',
							'description' => 'New title.',
						),
						'slug'      => array(
							'type'        => 'string',
							'description' => 'New URL slug. Changing it on published content moves the public URL — confirm with the user first. WordPress appends a suffix if the slug collides; the response reports the slug that actually landed.',
						),
						'status'    => array(
							'type'        => 'string',
							'enum'        => self::EDITABLE_STATUSES,
							'description' => 'New post status. "publish" makes the content public.',
						),
						'parent_id' => array(
							'type'        => 'integer',
							'description' => 'New parent post id, or 0 to remove the parent. Only for hierarchical types (e.g. page); the parent must be the same post type.',
						),
					),
					'required'             => array( 'target_id' ),
					'additionalProperties' => false,
				),
				'execute_callback'    => array( $this, 'ability_update_content' ),
				'permission_callback' => array( Permission::class, 'callback' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => true,
					),
				),
			)
		);
	}
}
