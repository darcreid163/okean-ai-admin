<?php
/**
 * AI ability — search posts/pages/products/HTML blocks by title.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Content;

use WP_Error;
use XTS\AI_Abilities\Permission;
use XTS\AI_Abilities\Support;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ability handler that searches posts/pages/products/portfolio projects/HTML blocks by title.
 */
class Search_Content {

	const SUPPORTED_POST_TYPES = array( 'page', 'post', 'product', 'portfolio', 'cms_block' );
	const DEFAULT_STATUSES     = array( 'publish', 'draft', 'pending', 'private' );
	const DEFAULT_LIMIT        = 20;
	const MAX_LIMIT            = 50;

	/**
	 * Search posts/pages/products/portfolio projects/HTML blocks by title.
	 *
	 * @param array<string,mixed> $input Ability input.
	 * @return array<string,mixed>|WP_Error
	 */
	public function ability_search_content( $input ) {
		global $wpdb;

		$query      = isset( $input['query'] ) ? trim( (string) $input['query'] ) : '';
		$post_types = $this->resolve_post_types( isset( $input['post_types'] ) ? $input['post_types'] : null );
		if ( is_wp_error( $post_types ) ) {
			return $post_types;
		}

		$statuses = $this->resolve_statuses( isset( $input['status'] ) ? $input['status'] : null );
		if ( is_wp_error( $statuses ) ) {
			return $statuses;
		}

		$limit = $this->sanitize_limit( isset( $input['limit'] ) ? $input['limit'] : null );

		if ( '' === $query ) {
			return array( 'results' => array() );
		}

		$post_type_placeholders = implode( ', ', array_fill( 0, count( $post_types ), '%s' ) );
		$status_placeholders    = implode( ', ', array_fill( 0, count( $statuses ), '%s' ) );

		$sql = "SELECT ID, post_title, post_type, post_status, post_modified
			FROM {$wpdb->posts}
			WHERE post_type IN ($post_type_placeholders)
			AND post_status IN ($status_placeholders)
			AND post_title LIKE %s
			ORDER BY post_title ASC
			LIMIT %d";

		$params = array_merge( $post_types, $statuses, array( '%' . $wpdb->esc_like( $query ) . '%', $limit ) );
		$rows   = $wpdb->get_results( $wpdb->prepare( $sql, $params ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery, WordPress.DB.PreparedSQL.NotPrepared

		$results = array();
		foreach ( (array) $rows as $row ) {
			$results[] = array(
				'id'        => (int) $row->ID,
				'title'     => $row->post_title,
				'post_type' => $row->post_type,
				'status'    => $row->post_status,
				'url'       => get_permalink( (int) $row->ID ),
				'edit_url'  => get_edit_post_link( (int) $row->ID, 'raw' ),
				'modified'  => $row->post_modified,
			);
		}

		return array( 'results' => $results );
	}

	/**
	 * Resolve the post types to search.
	 *
	 * Omitted input searches every supported type this site registers. An explicit
	 * value is rejected outright when it names an unsupported or unregistered type:
	 * silently falling back to the defaults would run the search over types the
	 * caller did not ask for and return plausible-looking results with no signal
	 * that the filter was dropped.
	 *
	 * @param mixed $value Raw post_types input.
	 * @return string[]|WP_Error
	 */
	private function resolve_post_types( $value ) {
		$available = Support::available_post_types( self::SUPPORTED_POST_TYPES );

		if ( ! is_array( $value ) || array() === $value ) {
			return $available;
		}

		$requested = array_values( array_unique( array_map( 'sanitize_key', array_filter( $value, 'is_scalar' ) ) ) );

		$unsupported = array_diff( $requested, self::SUPPORTED_POST_TYPES );
		if ( $unsupported ) {
			return new WP_Error(
				'wd_ai_unsupported_post_type',
				sprintf(
					'post_types contains unsupported values: %1$s. Supported: %2$s.',
					implode( ', ', $unsupported ),
					implode( ', ', self::SUPPORTED_POST_TYPES )
				)
			);
		}

		$unavailable = array_diff( $requested, $available );
		if ( $unavailable ) {
			return new WP_Error(
				'wd_ai_post_type_not_registered',
				sprintf(
					'post_types names types that are not registered on this site: %1$s%2$s.',
					implode( ', ', $unavailable ),
					Support::unavailable_post_types_reason( $unavailable )
				)
			);
		}

		return $requested;
	}

	/**
	 * Resolve the statuses to search. Rejects unknown statuses for the same reason
	 * resolve_post_types() rejects unknown post types.
	 *
	 * @param mixed $value Raw status input.
	 * @return string[]|WP_Error
	 */
	private function resolve_statuses( $value ) {
		if ( ! is_array( $value ) || array() === $value ) {
			return self::DEFAULT_STATUSES;
		}

		$requested = array_values( array_unique( array_map( 'sanitize_key', array_filter( $value, 'is_scalar' ) ) ) );

		$unsupported = array_diff( $requested, self::DEFAULT_STATUSES );
		if ( $unsupported ) {
			return new WP_Error(
				'wd_ai_unsupported_status',
				sprintf(
					'status contains unsupported values: %1$s. Supported: %2$s.',
					implode( ', ', $unsupported ),
					implode( ', ', self::DEFAULT_STATUSES )
				)
			);
		}

		return $requested;
	}

	/**
	 * Clamp limit input to [1, MAX_LIMIT], defaulting to DEFAULT_LIMIT.
	 *
	 * @param mixed $value Raw limit input.
	 * @return int
	 */
	private function sanitize_limit( $value ) {
		$limit = is_scalar( $value ) ? (int) $value : 0;
		if ( $limit <= 0 ) {
			return self::DEFAULT_LIMIT;
		}
		return min( $limit, self::MAX_LIMIT );
	}

	/**
	 * Register the woodmart/search-content ability (woodmart-content category).
	 */
	public function register() {
		wp_register_ability(
			'woodmart/search-content',
			array(
				'label'               => 'Search WoodMart Content',
				'description'         => 'Find existing posts/pages/products/portfolio projects/HTML blocks by title (partial, case-insensitive match). Returns each match\'s id, which is the target_id accepted by the woodmart/gutenberg-* abilities.',
				'category'            => 'woodmart-content',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'query'      => array(
							'type'        => 'string',
							'description' => 'Substring to match against the title.',
						),
						'post_types' => array(
							'type'        => 'array',
							'description' => 'Restrict to these post types. Defaults to every supported type this site registers. "product" needs WooCommerce and "portfolio" needs the Portfolio theme option; asking for one that is not registered is an error, not a silent fallback.',
							'items'       => array(
								'type' => 'string',
								'enum' => self::SUPPORTED_POST_TYPES,
							),
						),
						'status'     => array(
							'type'        => 'array',
							'description' => 'Restrict to these statuses. Defaults to all of: publish, draft, pending, private.',
							'items'       => array(
								'type' => 'string',
								'enum' => self::DEFAULT_STATUSES,
							),
						),
						'limit'      => array(
							'type'        => 'integer',
							'description' => 'Max results. Defaults to 20, capped at 50.',
						),
					),
					'required'             => array( 'query' ),
					'additionalProperties' => false,
				),
				'execute_callback'    => array( $this, 'ability_search_content' ),
				'permission_callback' => array( Permission::class, 'callback' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);
	}
}
