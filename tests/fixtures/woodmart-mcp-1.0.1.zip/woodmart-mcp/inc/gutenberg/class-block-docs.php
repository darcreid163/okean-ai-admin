<?php
/**
 * AI abilities — block documentation (list, describe block, describe attribute group).
 *
 * Cheap discovery entry point: returns names + titles + one-line descriptions so
 * an agent can pick blocks, then drill into one with gutenberg-describe-block.
 * Detailed schema for one or more blocks: attributes (type/default/source),
 * curated descriptions and value options, nesting, the content attribute, and a
 * minimal valid usage example so an agent can author the block from scratch
 * without an existing page. Also expands shared attribute groups (advanced,
 * color, typography, ...) that blocks reference by name (styleGroups /
 * composites) instead of inlining hundreds of identical styling attributes.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Gutenberg;

use WP_Error;
use XTS\AI_Abilities\Permission;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ability handlers for block discovery: listing blocks, describing a block's
 * attributes/usage, and expanding shared attribute groups.
 */
class Block_Docs {

	/**
	 * Block catalog loader.
	 *
	 * @var Block_Catalog
	 */
	private $catalog;

	/**
	 * Constructor.
	 *
	 * @param Block_Catalog $catalog Block catalog loader.
	 */
	public function __construct( Block_Catalog $catalog ) {
		$this->catalog = $catalog;
	}

	/**
	 * Compact index of available blocks, optionally filtered by category/search.
	 *
	 * @param array<string,mixed> $input Ability input.
	 * @return array<string,mixed>
	 */
	public function ability_list_blocks( $input ) {
		$input   = (array) $input;
		$catalog = $this->catalog->load();
		$search  = isset( $input['search'] ) ? strtolower( trim( (string) $input['search'] ) ) : '';

		// Comma-separated so list-layout-types can hand its whole block_categories
		// list straight back (a layout type has a category of its own plus the
		// cross-layout xtemos_site_elements one).
		$categories = array();
		if ( isset( $input['category'] ) && '' !== trim( (string) $input['category'] ) ) {
			$categories = array_filter( array_map( 'trim', explode( ',', strtolower( (string) $input['category'] ) ) ) );
		}

		$blocks = array();
		foreach ( $catalog as $block ) {
			if ( $categories && ! in_array( strtolower( (string) ( $block['category'] ?? '' ) ), $categories, true ) ) {
				continue;
			}
			if ( '' !== $search ) {
				$haystack = strtolower( (string) ( $block['name'] ?? '' ) . ' ' . (string) ( $block['title'] ?? '' ) );
				if ( false === strpos( $haystack, $search ) ) {
					continue;
				}
			}
			$blocks[] = Block_Catalog::index_entry( $block );
		}

		return array(
			'count'  => count( $blocks ),
			'blocks' => $blocks,
			'hint'   => 'Use gutenberg-describe-block with block_names to get attributes and a usage example. Blocks marked requiresInnerBlocks:true must be created with innerBlocks; describe them to get composition.template.',
		);
	}

	/**
	 * Detailed schema (attributes, nesting, usage example) for one or more blocks.
	 *
	 * @param array<string,mixed> $input Ability input.
	 * @return array<string,mixed>|WP_Error
	 */
	public function ability_describe_block( $input ) {
		$names = isset( $input['block_names'] ) ? $input['block_names'] : null;
		if ( is_string( $names ) ) {
			$names = array( $names );
		}
		if ( ! is_array( $names ) || array() === $names ) {
			return new WP_Error( 'wd_ai_invalid_input', 'block_names must be a non-empty array of block names (e.g. ["wd/paragraph"]).' );
		}

		$catalog   = $this->catalog->load();
		$blocks    = array();
		$not_found = array();

		foreach ( $names as $raw ) {
			$name = trim( (string) $raw );
			if ( '' === $name ) {
				continue;
			}
			if ( ! isset( $catalog[ $name ] ) ) {
				$not_found[] = $name;
				continue;
			}
			$blocks[] = $this->shape_block( $catalog[ $name ] );
		}

		$response = array( 'blocks' => $blocks );
		if ( array() !== $not_found ) {
			$response['not_found'] = $not_found;
			$response['hint']      = 'Unknown block names. Call gutenberg-list-blocks to see valid names.';
		}
		return $response;
	}

	/**
	 * Shape one catalog block entry into the response returned by ability_describe_block().
	 *
	 * @param array<string,mixed> $block Catalog block entry.
	 * @return array<string,mixed>
	 */
	private function shape_block( $block ) {
		$content_attr = isset( $block['contentAttribute'] ) ? $block['contentAttribute'] : null;

		$style_groups = isset( $block['styleGroups'] ) && is_array( $block['styleGroups'] ) ? $block['styleGroups'] : array();
		$composites   = isset( $block['composites'] ) && is_array( $block['composites'] ) ? $block['composites'] : array();
		$raw_attrs    = isset( $block['attributes'] ) && is_array( $block['attributes'] ) ? $block['attributes'] : array();
		$has_units    = false;
		foreach ( $raw_attrs as $def ) {
			if ( is_array( $def ) && isset( $def['xtsUnits'] ) ) {
				$has_units = true;
				break;
			}
		}

		$shaped = array(
			'name'             => $block['name'] ?? '',
			'title'            => $block['title'] ?? '',
			'category'         => $block['category'] ?? '',
			'description'      => $block['description'] ?? '',
			'whenToUse'        => $block['whenToUse'] ?? '',
			'nesting'          => array(
				'parent'   => $block['parent'] ?? null,
				'ancestor' => $block['ancestor'] ?? null,
			),
			'contentAttribute' => $content_attr,
			'attributes'       => Block_Catalog::attributes_to_list( $raw_attrs ),
			'conventions'      => $this->conventions( $style_groups, $composites, $has_units ),
		);

		if ( ! empty( $block['productSelectionAttributes'] ) ) {
			$shaped['productSelectionAttributes'] = $block['productSelectionAttributes'];
			$shaped['dataResolverHint']           = 'Explicit product/category IDs are site-specific. Resolve real IDs with the product data-resolver ability before setting include/categoriesIds.';
		}
		if ( array() !== $style_groups ) {
			$shaped['styleGroups'] = $style_groups;
		}
		if ( array() !== $composites ) {
			$shaped['composites'] = $composites;
		}
		if ( ! empty( $block['constraints'] ) && is_array( $block['constraints'] ) ) {
			$shaped['constraints'] = $block['constraints'];
		}
		if ( ! empty( $block['composition'] ) && is_array( $block['composition'] ) ) {
			$shaped['composition'] = $block['composition'];
		}

		if ( isset( $block['example'] ) && is_array( $block['example'] ) ) {
			$shaped['example'] = $block['example'];
		} elseif ( ! empty( $block['composition']['template'] ) && is_array( $block['composition']['template'] ) ) {
			$shaped['example'] = array(
				'name'        => $block['name'] ?? '',
				'attributes'  => array(),
				'innerBlocks' => $block['composition']['template'],
				'_note'       => 'Generated from composition.template; replace placeholder content and site-specific values.',
			);
		} else {
			$shaped['example'] = $this->synth_example( $block['name'] ?? '', $content_attr );
		}

		return $shaped;
	}

	/**
	 * Convention notes so an agent can interpret responsive/styleGroups/composites
	 * without the (large) expanded attribute lists. Only the relevant notes appear.
	 *
	 * @param array<int,array<string,mixed>> $style_groups Block's styleGroups entries.
	 * @param array<int,string>              $composites   Block's composites list.
	 * @param bool                           $has_units    Whether any attribute carries a units default.
	 * @return array<string,string>
	 */
	private function conventions( $style_groups, $composites, $has_units = false ) {
		$notes = array(
			'responsive' => 'Attributes marked responsive:true also accept <name>Tablet and <name>Mobile variants (e.g. columns, columnsTablet, columnsMobile).',
		);
		if ( $has_units ) {
			$notes['units'] = 'Attributes with a "units" value are a number plus a companion "<name>Units" attribute holding the CSS unit (default = the units value, e.g. "px"). Set both, e.g. spacing + spacingUnits. Combined with responsive, the companion also gets Tablet/Mobile (e.g. spacingUnitsTablet).';
		}
		if ( array() !== $style_groups ) {
			$notes['styleGroups'] = 'Each styleGroups entry applies a shared group with a prefix: attribute name = prefix + Capitalized(key), e.g. prefix "tp" + "fontSize" => "tpFontSize". Fetch a group\'s keys with gutenberg-describe-attribute-group.';
		}
		if ( array() !== $composites ) {
			$notes['composites'] = 'composites lists shared attribute sets available on this block (e.g. "advanced" styling). Fetch their attributes with gutenberg-describe-attribute-group.';
		}
		return $notes;
	}

	/**
	 * Synthesize a minimal valid one-block block_spec example.
	 *
	 * @param string      $name         Block name.
	 * @param string|null $content_attr Name of the block's content attribute, if any.
	 * @return array<string,mixed>
	 */
	private function synth_example( $name, $content_attr ) {
		$attributes = array();
		if ( is_string( $content_attr ) && '' !== $content_attr ) {
			$attributes[ $content_attr ] = 'Example text';
		}
		return array(
			'name'       => $name,
			'attributes' => $attributes,
			'_note'      => is_string( $content_attr ) && '' !== $content_attr
				? sprintf( 'Author text in the "%s" attribute; do not hand-write innerHTML.', $content_attr )
				: 'Configure via attributes; the editor serializes the markup.',
		);
	}

	/**
	 * Expand one or more shared attribute groups by id.
	 *
	 * @param array<string,mixed> $input Ability input.
	 * @return array<string,mixed>|WP_Error
	 */
	public function ability_describe_attribute_group( $input ) {
		$ids = isset( $input['groups'] ) ? $input['groups'] : null;
		if ( is_string( $ids ) ) {
			$ids = array( $ids );
		}
		if ( ! is_array( $ids ) || array() === $ids ) {
			return new WP_Error( 'wd_ai_invalid_input', 'groups must be a non-empty array of group ids (e.g. ["advanced","typography"]). See styleGroups/composites in gutenberg-describe-block.' );
		}

		$all       = $this->catalog->load_groups();
		$groups    = array();
		$not_found = array();

		foreach ( $ids as $raw ) {
			$id = trim( (string) $raw );
			if ( '' === $id ) {
				continue;
			}
			if ( ! isset( $all[ $id ] ) ) {
				$not_found[] = $id;
				continue;
			}
			$groups[] = $this->shape_group( $id, $all[ $id ] );
		}

		$response = array( 'groups' => $groups );
		if ( array() !== $not_found ) {
			$response['not_found'] = $not_found;
			$response['available'] = array_keys( $all );
		}
		return $response;
	}

	/**
	 * Shape one attribute group into the response returned by ability_describe_attribute_group().
	 *
	 * @param string              $id    Group id.
	 * @param array<string,mixed> $group Group definition.
	 * @return array<string,mixed>
	 */
	private function shape_group( $id, $group ) {
		return array(
			'id'         => $id,
			'kind'       => $group['kind'] ?? '',
			'note'       => $group['note'] ?? '',
			'attributes' => Block_Catalog::attributes_to_list( isset( $group['attributes'] ) && is_array( $group['attributes'] ) ? $group['attributes'] : array() ),
		);
	}

	/**
	 * Register the woodmart/gutenberg-list-blocks, woodmart/gutenberg-describe-block
	 * and woodmart/gutenberg-describe-attribute-group abilities.
	 *
	 * @return void
	 */
	public function register() {
		wp_register_ability(
			'woodmart/gutenberg-list-blocks',
			array(
				'label'               => 'List WoodMart Blocks',
				'description'         => 'Compact index of available WoodMart Gutenberg blocks (name, title, category, one-line description, and requiresInnerBlocks for blocks that need a child template). Cheap discovery entry point for composing pages from scratch — then call gutenberg-describe-block for attribute details and composition.template. Optional category/search filters.',
				'category'            => 'woodmart-gutenberg',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'category' => array(
							'type'        => 'string',
							'description' => 'Filter by block category (e.g. "xtemos"). Accepts a comma-separated list, so the block_categories of a layout type can be passed as-is.',
						),
						'search'   => array(
							'type'        => 'string',
							'description' => 'Substring match on block name/title.',
						),
					),
					'additionalProperties' => false,
				),
				'execute_callback'    => array( $this, 'ability_list_blocks' ),
				'permission_callback' => array( Permission::class, 'callback' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);

		wp_register_ability(
			'woodmart/gutenberg-describe-block',
			array(
				'label'               => 'Describe WoodMart Block',
				'description'         => 'Detailed schema for one or more blocks: attributes (type/default/source), curated descriptions and value options, nesting, required composition/template, the content attribute, and a valid usage example. Use this to author a block from scratch. Authoring rule: put text/content in the block attributes (e.g. content), not in innerHTML.',
				'category'            => 'woodmart-gutenberg',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'block_names' => array(
							'type'        => 'array',
							'minItems'    => 1,
							'description' => 'Block names to describe, e.g. ["wd/paragraph","wd/products"].',
							'items'       => array( 'type' => 'string' ),
						),
					),
					'required'             => array( 'block_names' ),
					'additionalProperties' => false,
				),
				'execute_callback'    => array( $this, 'ability_describe_block' ),
				'permission_callback' => array( Permission::class, 'callback' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);

		wp_register_ability(
			'woodmart/gutenberg-describe-attribute-group',
			array(
				'label'               => 'Describe WoodMart Attribute Group',
				'description'         => 'Expand shared attribute groups by id (e.g. "advanced", "typography", "color"). Blocks reference these via styleGroups/composites instead of inlining hundreds of identical styling attributes; fetch a group here when you need to style precisely. For styleGroups, the real attribute name is the block\'s prefix + Capitalized(key).',
				'category'            => 'woodmart-gutenberg',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'groups' => array(
							'type'        => 'array',
							'minItems'    => 1,
							'description' => 'Group ids to expand, e.g. ["advanced","typography"].',
							'items'       => array( 'type' => 'string' ),
						),
					),
					'required'             => array( 'groups' ),
					'additionalProperties' => false,
				),
				'execute_callback'    => array( $this, 'ability_describe_attribute_group' ),
				'permission_callback' => array( Permission::class, 'callback' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);
	}
}
