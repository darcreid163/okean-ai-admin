<?php
/**
 * AI ability — create a new post/page/HTML block, optionally with content.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Gutenberg;

use WP_Error;
use XTS\AI_Abilities\Permission;
use XTS\AI_Abilities\Support;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ability handler that creates a new post/page/portfolio project/HTML block,
 * optionally with content.
 */
class Create_Content {

	const CREATABLE_POST_TYPES = array( 'page', 'post', 'portfolio', 'cms_block' );
	const CREATABLE_STATUSES   = array( 'draft', 'publish', 'pending', 'private' );

	/**
	 * Pending-changes handler used to queue the created post's content.
	 *
	 * @var Pending_Changes
	 */
	private $pending_changes;

	/**
	 * Finalization runtime used to auto-enable the queued batch.
	 *
	 * @var Finalization
	 */
	private $finalization;

	/**
	 * Constructor.
	 *
	 * @param Pending_Changes $pending_changes Pending-changes handler.
	 * @param Finalization    $finalization    Finalization runtime.
	 */
	public function __construct( Pending_Changes $pending_changes, Finalization $finalization ) {
		$this->pending_changes = $pending_changes;
		$this->finalization    = $finalization;
	}

	/**
	 * Create a new post/page/HTML block, optionally with content.
	 *
	 * @param array<string,mixed> $input Ability input.
	 * @return array<string,mixed>|WP_Error
	 */
	public function ability_create_content( $input ) {
		$title = isset( $input['title'] ) ? trim( (string) $input['title'] ) : '';
		if ( '' === $title ) {
			return new WP_Error( 'wd_ai_missing_title', 'title is required.' );
		}

		$post_type = isset( $input['post_type'] ) ? sanitize_key( $input['post_type'] ) : 'page';
		if ( ! in_array( $post_type, self::CREATABLE_POST_TYPES, true ) ) {
			return new WP_Error( 'wd_ai_invalid_post_type', sprintf( 'post_type must be one of: %s.', implode( ', ', self::CREATABLE_POST_TYPES ) ) );
		}

		// 'portfolio' is registered only when the Portfolio theme option is on, so a
		// supported type is not necessarily an available one.
		if ( ! post_type_exists( $post_type ) ) {
			return new WP_Error(
				'wd_ai_post_type_not_registered',
				sprintf(
					'post_type "%1$s" is not registered on this site%2$s.',
					$post_type,
					Support::unavailable_post_types_reason( array( $post_type ) )
				)
			);
		}

		$denied = Permission::check_can_create( $post_type );
		if ( $denied ) {
			return $denied;
		}

		$status = isset( $input['status'] ) ? sanitize_key( $input['status'] ) : 'draft';
		if ( ! in_array( $status, self::CREATABLE_STATUSES, true ) ) {
			return new WP_Error( 'wd_ai_invalid_status', sprintf( 'status must be one of: %s.', implode( ', ', self::CREATABLE_STATUSES ) ) );
		}

		$denied = Permission::check_can_set_status( $post_type, $status );
		if ( $denied ) {
			return $denied;
		}

		// Validate the block spec before the post exists: an invalid spec must not
		// leave an empty (possibly published) post behind.
		$blocks = null;
		if ( isset( $input['block_spec'] ) ) {
			$blocks = Block_Normalizer::normalize_blocks( $input['block_spec'] );
			if ( is_wp_error( $blocks ) ) {
				return $blocks;
			}

			if ( empty( $input['allow_raw_html'] ) && Block_Normalizer::blocks_are_raw_html_only( $blocks ) ) {
				return new WP_Error( 'wd_ai_raw_html_only', Pending_Changes::RAW_HTML_GUIDANCE );
			}
		}

		$postarr = array(
			'post_title'  => sanitize_text_field( $title ),
			'post_type'   => $post_type,
			'post_status' => $status,
		);
		if ( ! empty( $input['slug'] ) ) {
			$postarr['post_name'] = sanitize_title( (string) $input['slug'] );
		}
		if ( ! empty( $input['parent_id'] ) ) {
			$postarr['post_parent'] = (int) $input['parent_id'];
		}

		$post_id = wp_insert_post( $postarr, true );
		if ( is_wp_error( $post_id ) ) {
			return $post_id;
		}

		$response = array(
			'id'          => $post_id,
			'post_type'   => $post_type,
			'post_status' => $status,
			'edit_url'    => get_edit_post_link( $post_id, 'raw' ),
		);

		if ( null === $blocks ) {
			return $response;
		}

		$target = get_post( $post_id );
		$queued = $this->pending_changes->queue_replace_content( $target, $blocks, 0, $title, ! empty( $input['allow_raw_html'] ) );
		if ( is_wp_error( $queued ) ) {
			return $this->rollback( $post_id, $queued );
		}

		$enabled = $this->finalization->enable_finalization( $queued['batch_id'] );
		if ( is_wp_error( $enabled ) ) {
			return $this->rollback( $post_id, $enabled, (int) $queued['batch_id'] );
		}

		$queued['batch_status']          = $enabled['batch_status'];
		$queued['finalization_required'] = $enabled['finalization_required'];
		$queued['user_instruction']      = sprintf(
			'Content queued and marked ready in batch #%d. Ask the user to open the WoodMart -> Tools -> AI Block Queue page in wp-admin (%s) and keep it open; it will finalize automatically. Poll woodmart/gutenberg-get-pending-batch with batch_id %d until status is "finalized" (or "failed"/"conflicted"). The new %s is not live with this content until status is "finalized".',
			$queued['batch_id'],
			Finalizer_Page::url(),
			$queued['batch_id'],
			$post_type
		);

		return array_merge( $response, $queued );
	}

	/**
	 * Undo a partially-completed creation and return the error that caused it.
	 *
	 * The post is inserted before its content can be queued, so a queueing failure
	 * would otherwise leave an empty — possibly already published — post behind.
	 *
	 * @param int      $post_id  Post that was just created.
	 * @param WP_Error $error    Error to return to the caller.
	 * @param int      $batch_id Batch queued for the post, or 0 if none was created.
	 * @return WP_Error
	 */
	private function rollback( $post_id, WP_Error $error, $batch_id = 0 ) {
		if ( $batch_id > 0 ) {
			$this->finalization->cancel_batch( $batch_id );
		}

		wp_delete_post( $post_id, true );

		return $error;
	}

	/**
	 * Register the woodmart/create-content ability. Called from Main::init().
	 */
	public function register() {
		wp_register_ability(
			'woodmart/create-content',
			array(
				'label'               => 'Create WoodMart Content',
				'description'         => 'Create a new page/post/portfolio project/HTML block. Omit block_spec to create it empty (fill later with gutenberg-add-pending-change); pass block_spec to queue WoodMart block content immediately (queued the same way as gutenberg-add-pending-change, then auto-marked ready — finalize via the AI Block Queue page as usual). post_type "portfolio" requires the Portfolio theme option to be enabled.',
				'category'            => 'woodmart-gutenberg',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'title'          => array(
							'type'        => 'string',
							'description' => 'Post title.',
						),
						'post_type'      => array(
							'type'        => 'string',
							'enum'        => self::CREATABLE_POST_TYPES,
							'default'     => 'page',
							'description' => 'What to create. Defaults to page. "portfolio" creates a portfolio project and requires the Portfolio theme option.',
						),
						'status'         => array(
							'type'        => 'string',
							'enum'        => self::CREATABLE_STATUSES,
							'default'     => 'draft',
							'description' => 'Post status. Defaults to draft.',
						),
						'slug'           => array(
							'type'        => 'string',
							'description' => 'Optional URL slug.',
						),
						'parent_id'      => array(
							'type'        => 'integer',
							'description' => 'Optional parent post id (e.g. for a hierarchical page).',
						),
						'block_spec'     => array(
							'type'        => 'array',
							'description' => 'Optional. Top-level blocks: [{name, attributes, innerBlocks}]. If provided, content is queued and marked ready for finalization immediately (same as calling gutenberg-add-pending-change then gutenberg-enable-finalization).',
							'items'       => array( 'type' => 'object' ),
						),
						'allow_raw_html' => array(
							'type'    => 'boolean',
							'default' => false,
						),
					),
					'required'             => array( 'title' ),
					'additionalProperties' => false,
				),
				'execute_callback'    => array( $this, 'ability_create_content' ),
				'permission_callback' => array( Permission::class, 'callback' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'destructive' => false,
						'idempotent'  => false,
					),
				),
			)
		);
	}
}
