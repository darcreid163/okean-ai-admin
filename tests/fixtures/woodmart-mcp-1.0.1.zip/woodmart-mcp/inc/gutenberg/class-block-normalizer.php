<?php
/**
 * AI abilities — Gutenberg block-spec normalization.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Gutenberg;

use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Static helpers for normalizing incoming Gutenberg block specs.
 */
class Block_Normalizer {
	/**
	 * Generate a unique blockId for a wd/* block (16 hex chars; CSS uses the first 8).
	 */
	public static function generate_block_id() {
		return bin2hex( random_bytes( 8 ) );
	}

	/**
	 * Normalize an incoming block_spec into a list of {name, attributes, innerBlocks}.
	 *
	 * @param mixed $value Raw block_spec (a single block object or a list of them).
	 * @return array<int,array<string,mixed>>|WP_Error
	 */
	public static function normalize_blocks( $value ) {
		if ( ! is_array( $value ) ) {
			return new WP_Error( 'wd_ai_invalid_spec', 'block_spec must be an array of Gutenberg block objects.' );
		}

		// Allow a single block object instead of a list.
		if ( isset( $value['name'] ) && is_string( $value['name'] ) ) {
			$value = array( $value );
		}

		$blocks = array();
		foreach ( array_values( $value ) as $index => $raw ) {
			$normalized = self::normalize_block( $raw, "block_spec[$index]" );
			if ( is_wp_error( $normalized ) ) {
				return $normalized;
			}
			$blocks[] = $normalized;
		}

		if ( array() === $blocks ) {
			return new WP_Error( 'wd_ai_empty_spec', 'block_spec must contain at least one block.' );
		}

		return $blocks;
	}

	/**
	 * Normalize one raw block object into {name, attributes, innerBlocks, innerHTML?}.
	 *
	 * @param mixed  $value Raw block.
	 * @param string $path  Diagnostic path.
	 * @return array<string,mixed>|WP_Error
	 */
	private static function normalize_block( $value, $path ) {
		if ( ! is_array( $value ) ) {
			return new WP_Error( 'wd_ai_invalid_spec', sprintf( '%s must be an object.', $path ) );
		}

		if ( empty( $value['name'] ) || ! is_string( $value['name'] ) ) {
			return new WP_Error( 'wd_ai_invalid_spec', sprintf( '%s.name must be a non-empty block name.', $path ) );
		}
		$name = trim( $value['name'] );

		$attributes = ( isset( $value['attributes'] ) && is_array( $value['attributes'] ) ) ? $value['attributes'] : array();

		$inner_raw    = ( isset( $value['innerBlocks'] ) && is_array( $value['innerBlocks'] ) ) ? array_values( $value['innerBlocks'] ) : array();
		$inner_blocks = array();
		foreach ( $inner_raw as $index => $raw_inner ) {
			$normalized = self::normalize_block( $raw_inner, "$path.innerBlocks[$index]" );
			if ( is_wp_error( $normalized ) ) {
				return $normalized;
			}
			$inner_blocks[] = $normalized;
		}

		// WoodMart blocks need a unique blockId for per-block CSS.
		if ( 0 === strpos( $name, 'wd/' ) && empty( $attributes['blockId'] ) ) {
			$attributes['blockId'] = self::generate_block_id();
		}

		$normalized = array(
			'name'        => $name,
			'attributes'  => $attributes,
			'innerBlocks' => $inner_blocks,
		);

		// Preserve raw innerHTML when an agent passes back a block read via
		// get-content. The finalizer rebuilds such blocks from this markup so
		// html-sourced RichText content (e.g. button/heading/paragraph text)
		// survives a replace-content round-trip.
		if ( isset( $value['innerHTML'] ) && is_string( $value['innerHTML'] ) && '' !== trim( $value['innerHTML'] ) ) {
			$normalized['innerHTML'] = $value['innerHTML'];
		}

		return $normalized;
	}

	/**
	 * A raw-HTML block carries hand-written markup the editor cannot edit visually.
	 *
	 * @param string $name Block name.
	 * @return bool
	 */
	public static function is_raw_html_block( $name ) {
		return 'core/html' === $name || 'core/freeform' === $name;
	}

	/**
	 * Whether every content-bearing (leaf) block is raw HTML, at any nesting depth.
	 *
	 * @param array<int,array<string,mixed>> $blocks Normalized block tree.
	 * @return bool
	 */
	public static function blocks_are_raw_html_only( $blocks ) {
		$leaves = self::leaf_block_names( $blocks );
		if ( array() === $leaves ) {
			return false;
		}
		foreach ( $leaves as $name ) {
			if ( ! self::is_raw_html_block( $name ) ) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Names of leaf (childless) blocks, collected depth-first.
	 *
	 * @param array<int,array<string,mixed>> $blocks Normalized block tree.
	 * @return string[]
	 */
	private static function leaf_block_names( $blocks ) {
		$names = array();
		foreach ( $blocks as $block ) {
			$inner = ( isset( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) ? $block['innerBlocks'] : array();
			if ( array() !== $inner ) {
				foreach ( self::leaf_block_names( $inner ) as $name ) {
					$names[] = $name;
				}
				continue;
			}
			$name = isset( $block['name'] ) && is_string( $block['name'] ) ? $block['name'] : '';
			if ( '' !== $name ) {
				$names[] = $name;
			}
		}
		return $names;
	}
}
