<?php
/**
 * AI abilities — convert raw Gutenberg block markup into a block_spec tree.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Gutenberg\Template_Library;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Converts raw Gutenberg block markup into the block_spec tree used by this module.
 */
class Markup_Converter {
	/**
	 * Parse serialized Gutenberg block markup (`<!-- wp:... -->`) into the
	 * {name, attributes, innerBlocks, innerHTML?} tree normalize_blocks() expects.
	 *
	 * @param string $markup Raw Gutenberg block markup.
	 * @return array<int,array<string,mixed>>
	 */
	public static function markup_to_block_spec( $markup ) {
		return self::parsed_blocks_to_block_spec( parse_blocks( (string) $markup ) );
	}

	/**
	 * Convert a list of parse_blocks() nodes into a list of block_spec nodes.
	 *
	 * @param array<int,array<string,mixed>> $parsed_blocks Output of parse_blocks().
	 * @return array<int,array<string,mixed>>
	 */
	private static function parsed_blocks_to_block_spec( $parsed_blocks ) {
		$blocks = array();
		foreach ( $parsed_blocks as $parsed ) {
			$block = self::one_parsed_block_to_block_spec( $parsed );
			if ( null !== $block ) {
				$blocks[] = $block;
			}
		}
		return $blocks;
	}

	/**
	 * Convert one parse_blocks() node into a block_spec node.
	 *
	 * @param array<string,mixed> $parsed One entry from parse_blocks().
	 * @return array<string,mixed>|null Null for whitespace-only entries (blockName === null).
	 */
	private static function one_parsed_block_to_block_spec( $parsed ) {
		$name = isset( $parsed['blockName'] ) ? $parsed['blockName'] : null;
		if ( ! is_string( $name ) || '' === $name ) {
			return null;
		}

		$attributes = isset( $parsed['attrs'] ) && is_array( $parsed['attrs'] ) ? $parsed['attrs'] : array();
		if ( 0 === strpos( $name, 'wd/' ) ) {
			unset( $attributes['blockId'] );
		}

		$inner_blocks = isset( $parsed['innerBlocks'] ) && is_array( $parsed['innerBlocks'] )
			? self::parsed_blocks_to_block_spec( $parsed['innerBlocks'] )
			: array();

		$block = array(
			'name'        => $name,
			'attributes'  => $attributes,
			'innerBlocks' => $inner_blocks,
		);

		// Leaf blocks (no children) carry their real content in innerHTML (e.g. paragraph
		// text); a block with children only has wrapper whitespace there, which is not useful.
		if ( array() === $inner_blocks ) {
			$inner_html = isset( $parsed['innerHTML'] ) ? trim( (string) $parsed['innerHTML'] ) : '';
			if ( '' !== $inner_html ) {
				$block['innerHTML'] = $parsed['innerHTML'];
			}
		}

		return $block;
	}
}
