<?php
/**
 * AI abilities — localize remote template-library images left in a block_spec.
 *
 * The woodmart/gutenberg-get-template ability returns block_spec fast, without
 * sideloading any images it references (see fetch_template_markup() on
 * XTS\Gutenberg\Template_Library). This module does that sideload later, at
 * finalize time (XTS\AI_Abilities\Gutenberg\Finalization::claim_batch(), driven by the
 * browser AI Block Queue page, not the MCP-facing abilities), where a slow,
 * multi-image synchronous import isn't at risk of a client-side timeout.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Gutenberg\Template_Library;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Sideloads remote template-library images referenced in a block_spec into the
 * local media library, rewriting their id/url in place.
 */
class Image_Localizer {
	/**
	 * Recursively localize every `{id, url}`-shaped attribute value whose `url`
	 * points at the template-library demo host, sideloading each into the media
	 * library and rewriting it to the new local id/url.
	 *
	 * @param array<int,array<string,mixed>> $blocks Normalized block tree.
	 * @return array{blocks:array<int,array<string,mixed>>, changed:bool}
	 */
	public function localize_remote_images( $blocks ) {
		$changed = false;
		$result  = array();
		foreach ( $blocks as $block ) {
			$result[] = $this->localize_block( $block, $changed );
		}
		return array(
			'blocks'  => $result,
			'changed' => $changed,
		);
	}

	/**
	 * Recursively localize one block's attributes and inner blocks.
	 *
	 * @param array<string,mixed> $block   Block node.
	 * @param bool                $changed Passed by reference; set true if anything was localized.
	 * @return array<string,mixed>
	 */
	private function localize_block( $block, &$changed ) {
		if ( isset( $block['attributes'] ) && is_array( $block['attributes'] ) ) {
			$block['attributes'] = $this->localize_attributes( $block['attributes'], $changed );
		}
		if ( isset( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
			$inner = array();
			foreach ( $block['innerBlocks'] as $child ) {
				$inner[] = $this->localize_block( $child, $changed );
			}
			$block['innerBlocks'] = $inner;
		}
		return $block;
	}

	/**
	 * Recursively localize any {id, url}-shaped values found in an attribute map.
	 *
	 * @param array<string,mixed> $attributes Block attributes.
	 * @param bool                $changed    Passed by reference.
	 * @return array<string,mixed>
	 */
	private function localize_attributes( $attributes, &$changed ) {
		foreach ( $attributes as $key => $value ) {
			if ( $this->is_image_ref( $value ) ) {
				$localized = $this->localize_image_ref( $value );
				if ( null !== $localized ) {
					$attributes[ $key ] = $localized;
					$changed            = true;
				}
			} elseif ( is_array( $value ) ) {
				$attributes[ $key ] = $this->localize_attributes( $value, $changed );
			}
		}
		return $attributes;
	}

	/**
	 * Whether $value is an {id, url}-shaped attribute value pointing at a remote host.
	 *
	 * @param mixed $value Candidate attribute value.
	 * @return bool
	 */
	private function is_image_ref( $value ) {
		return is_array( $value )
			&& isset( $value['id'], $value['url'] )
			&& is_numeric( $value['id'] )
			&& is_string( $value['url'] )
			&& $this->needs_localization( $value['url'] );
	}

	/**
	 * True only for URLs hosted on xtemos.com or one of its subdomains — demo
	 * templates reference images across several xtemos.com subdomains (e.g.
	 * woodmart.xtemos.com, dummy.xtemos.com), not just WOODMART_BASE_URL's own host.
	 * Scoped to this allowlist (rather than "any host but our own") so a
	 * block_spec crafted by an untrusted caller can't make the server sideload
	 * from an arbitrary attacker-controlled or internal URL.
	 *
	 * @param string $url URL to test.
	 * @return bool
	 */
	private function needs_localization( $url ) {
		$url_host = wp_parse_url( $url, PHP_URL_HOST );
		if ( ! is_string( $url_host ) || '' === $url_host ) {
			return false;
		}
		$url_host = strtolower( $url_host );
		return 'xtemos.com' === $url_host || 1 === preg_match( '/\.xtemos\.com$/', $url_host );
	}

	/**
	 * Sideload one image reference into the media library.
	 *
	 * @param array{id:int|string,url:string} $value Remote {id, url} reference.
	 * @return array{id:int,url:string}|null Null if the image could not be localized.
	 */
	private function localize_image_ref( $value ) {
		if ( ! class_exists( '\XTS\Gutenberg\Template_Library' ) ) {
			return null;
		}

		$new_id = \XTS\Gutenberg\Template_Library::get_instance()->get_image( $value['url'] );
		if ( is_wp_error( $new_id ) ) {
			return null;
		}

		$new_url = wp_get_attachment_url( $new_id );
		if ( ! is_string( $new_url ) ) {
			return null;
		}

		return array(
			'id'  => (int) $new_id,
			'url' => $new_url,
		);
	}
}
