<?php
/**
 * AI abilities — remote template-library catalog client.
 *
 * Fetches and caches WoodMart's demo-server Gutenberg template catalog, the same
 * one the "Template Library" Gutenberg block already consumes in the browser
 * (inc/integrations/gutenberg/src/blocks/design-library/edit.js).
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Gutenberg\Template_Library;

use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Fetches and caches WoodMart's demo-server Gutenberg template catalog.
 */
class Client {
	const CATALOG_TRANSIENT = 'woodmart_ai_template_library_catalog';
	const CATALOG_CACHE_TTL = 12 * HOUR_IN_SECONDS;

	/**
	 * Demo-server base URL the catalog is fetched from (with trailing slash).
	 *
	 * @var string
	 */
	private $base_url;

	/**
	 * Constructor.
	 *
	 * @param string $base_url Demo-server base URL (with trailing slash), e.g. WOODMART_BASE_URL.
	 */
	public function __construct( $base_url ) {
		$this->base_url = (string) $base_url;
	}

	/**
	 * Fetch the template catalog, using the cached copy unless a refresh is forced.
	 *
	 * @param bool $force_refresh Bypass the cached catalog and re-fetch from the server.
	 * @return array{elements:array<int,array<string,mixed>>,tags:array<int,array<string,mixed>>,count:int}|WP_Error
	 */
	public function fetch_catalog( $force_refresh = false ) {
		if ( ! $force_refresh ) {
			$cached = get_transient( self::CATALOG_TRANSIENT );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		$catalog = $this->fetch_catalog_from_remote();
		if ( is_wp_error( $catalog ) ) {
			return $catalog;
		}

		set_transient( self::CATALOG_TRANSIENT, $catalog, self::CATALOG_CACHE_TTL );
		return $catalog;
	}

	/**
	 * The cached catalog, if present. No remote call.
	 *
	 * @return array{elements:array<int,array<string,mixed>>,tags:array<int,array<string,mixed>>,count:int}|null
	 */
	public function cached_catalog() {
		$cached = get_transient( self::CATALOG_TRANSIENT );
		return is_array( $cached ) ? $cached : null;
	}

	/**
	 * Fetch the template catalog from the demo server (bypassing the cache).
	 *
	 * @return array{elements:array<int,array<string,mixed>>,tags:array<int,array<string,mixed>>,count:int}|WP_Error
	 */
	private function fetch_catalog_from_remote() {
		$url = $this->base_url . 'wp-admin/admin-ajax.php?action=woodmart_load_templates&builder=gutenberg';

		$response = wp_remote_get( $url );

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		if ( 200 !== (int) $code ) {
			return new WP_Error( 'wd_ai_template_library_unreachable', sprintf( 'Template library server returned HTTP %d.', $code ) );
		}

		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $data ) || ! isset( $data['elements'] ) || ! is_array( $data['elements'] ) ) {
			return new WP_Error( 'wd_ai_template_library_invalid_response', 'Template library server returned an unexpected response.' );
		}

		return array(
			'elements' => $data['elements'],
			'tags'     => isset( $data['tags'] ) && is_array( $data['tags'] ) ? $data['tags'] : array(),
			'count'    => isset( $data['count'] ) ? (int) $data['count'] : count( $data['elements'] ),
		);
	}
}
