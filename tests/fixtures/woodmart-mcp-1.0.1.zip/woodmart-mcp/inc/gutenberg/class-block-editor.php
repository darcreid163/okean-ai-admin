<?php
/**
 * AI ability — edit a target's Gutenberg block tree by blockId.
 *
 * Addresses individual wd/* blocks (which carry a stable blockId) and applies a
 * sequence of update/delete/insert/move operations server-side, then queues the
 * resulting full tree as an ordinary replace-content change. Token savings are on
 * the input side: the agent sends only the blocks/operations that change instead
 * of the whole page. Storage and finalization are shared with
 * gutenberg-add-pending-change and left unchanged.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Gutenberg;

use WP_Error;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Applies update/delete/insert/move operations to a Gutenberg block spec tree.
 */
class Block_Editor {
	const VALID_POSITIONS = array( 'before', 'after', 'first-child', 'last-child' );

	/**
	 * Dispatch a single operation against the working tree.
	 *
	 * @param array<int,array<string,mixed>> $tree Working tree.
	 * @param mixed                          $op   Operation payload.
	 * @param string                         $path Diagnostic path.
	 * @return array<int,array<string,mixed>>|WP_Error
	 */
	public static function apply_operation( array $tree, $op, $path ) {
		if ( ! is_array( $op ) || empty( $op['op'] ) || ! is_string( $op['op'] ) ) {
			return new WP_Error( 'wd_ai_invalid_operation', sprintf( '%s must be an object with an "op" of update|delete|insert|move.', $path ) );
		}

		switch ( $op['op'] ) {
			case 'update':
				return self::op_update( $tree, $op, $path );
			case 'delete':
				return self::op_delete( $tree, $op, $path );
			case 'insert':
				return self::op_insert( $tree, $op, $path );
			case 'move':
				return self::op_move( $tree, $op, $path );
			default:
				return new WP_Error( 'wd_ai_invalid_operation', sprintf( '%s.op "%s" is not one of update|delete|insert|move.', $path, $op['op'] ) );
		}
	}

	/**
	 * Apply an op="update" operation: merge fields into an existing block by blockId.
	 *
	 * @param array<int,array<string,mixed>> $tree Working tree.
	 * @param mixed                          $op   Operation payload.
	 * @param string                         $path Diagnostic path.
	 * @return array<int,array<string,mixed>>|WP_Error
	 */
	private static function op_update( array $tree, $op, $path ) {
		$block_id = isset( $op['blockId'] ) ? (string) $op['blockId'] : '';
		if ( '' === $block_id ) {
			return new WP_Error( 'wd_ai_invalid_operation', sprintf( '%s.blockId is required for op="update".', $path ) );
		}

		$fields = array();
		foreach ( array( 'name', 'attributes', 'removeAttributes', 'innerBlocks', 'innerHTML' ) as $field ) {
			if ( array_key_exists( $field, $op ) ) {
				$fields[ $field ] = $op[ $field ];
			}
		}
		if ( array() === $fields ) {
			return new WP_Error( 'wd_ai_invalid_operation', sprintf( '%s (op="update") needs at least one of attributes/removeAttributes/innerBlocks/innerHTML/name.', $path ) );
		}

		$applied = false;
		$tree    = self::apply_update( $tree, $block_id, $fields, $applied );
		if ( ! $applied ) {
			return self::block_not_found_error( $block_id, $tree );
		}
		return $tree;
	}

	/**
	 * Apply an op="delete" operation: remove a block and its subtree by blockId.
	 *
	 * @param array<int,array<string,mixed>> $tree Working tree.
	 * @param mixed                          $op   Operation payload.
	 * @param string                         $path Diagnostic path.
	 * @return array<int,array<string,mixed>>|WP_Error
	 */
	private static function op_delete( array $tree, $op, $path ) {
		$block_id = isset( $op['blockId'] ) ? (string) $op['blockId'] : '';
		if ( '' === $block_id ) {
			return new WP_Error( 'wd_ai_invalid_operation', sprintf( '%s.blockId is required for op="delete".', $path ) );
		}

		$removed = null;
		$tree    = self::detach_block( $tree, $block_id, $removed );
		if ( null === $removed ) {
			return self::block_not_found_error( $block_id, $tree );
		}
		return $tree;
	}

	/**
	 * Apply an op="insert" operation: place a new block relative to an anchor.
	 *
	 * @param array<int,array<string,mixed>> $tree Working tree.
	 * @param mixed                          $op   Operation payload.
	 * @param string                         $path Diagnostic path.
	 * @return array<int,array<string,mixed>>|WP_Error
	 */
	private static function op_insert( array $tree, $op, $path ) {
		$spec = isset( $op['block'] ) ? $op['block'] : null;
		if ( ! is_array( $spec ) || empty( $spec['name'] ) || ! is_string( $spec['name'] ) ) {
			return new WP_Error( 'wd_ai_invalid_operation', sprintf( '%s.block must be an object with a non-empty name for op="insert".', $path ) );
		}

		$position = isset( $op['position'] ) ? (string) $op['position'] : '';
		if ( ! in_array( $position, self::VALID_POSITIONS, true ) ) {
			return new WP_Error( 'wd_ai_invalid_position', sprintf( '%s.position must be one of before|after|first-child|last-child.', $path ) );
		}

		$anchor = isset( $op['anchor'] ) ? (string) $op['anchor'] : '';
		$node   = self::node_from_spec( $spec );

		return self::place_node( $tree, $node, $position, $anchor, $path );
	}

	/**
	 * Apply an op="move" operation: relocate an existing block by blockId.
	 *
	 * @param array<int,array<string,mixed>> $tree Working tree.
	 * @param mixed                          $op   Operation payload.
	 * @param string                         $path Diagnostic path.
	 * @return array<int,array<string,mixed>>|WP_Error
	 */
	private static function op_move( array $tree, $op, $path ) {
		$block_id = isset( $op['blockId'] ) ? (string) $op['blockId'] : '';
		if ( '' === $block_id ) {
			return new WP_Error( 'wd_ai_invalid_operation', sprintf( '%s.blockId is required for op="move".', $path ) );
		}

		$position = isset( $op['position'] ) ? (string) $op['position'] : '';
		if ( ! in_array( $position, self::VALID_POSITIONS, true ) ) {
			return new WP_Error( 'wd_ai_invalid_position', sprintf( '%s.position must be one of before|after|first-child|last-child.', $path ) );
		}

		$anchor = isset( $op['anchor'] ) ? (string) $op['anchor'] : '';

		$subtree = self::find_subtree( $tree, $block_id );
		if ( null === $subtree ) {
			return self::block_not_found_error( $block_id, $tree );
		}

		// Guard: cannot move a block into itself or its own descendants.
		if ( '' !== $anchor && in_array( $anchor, self::collect_block_ids( array( $subtree ) ), true ) ) {
			return new WP_Error( 'wd_ai_invalid_move', sprintf( '%s cannot move block "%s" into itself or its own subtree.', $path, $block_id ) );
		}

		$removed = null;
		$tree    = self::detach_block( $tree, $block_id, $removed );

		return self::place_node( $tree, $removed, $position, $anchor, $path );
	}

	/**
	 * Place a node into the tree per position/anchor. Shared by insert and move.
	 *
	 * @param array<int,array<string,mixed>> $tree     Working tree.
	 * @param array<string,mixed>            $node     Node to place.
	 * @param string                         $position One of before|after|first-child|last-child.
	 * @param string                         $anchor   Anchor blockId, or '' to target the tree root.
	 * @param string                         $path     Diagnostic path.
	 * @return array<int,array<string,mixed>>|WP_Error
	 */
	private static function place_node( array $tree, array $node, $position, $anchor, $path ) {
		if ( '' === $anchor ) {
			if ( 'first-child' === $position ) {
				array_unshift( $tree, $node );
				return $tree;
			}
			if ( 'last-child' === $position ) {
				$tree[] = $node;
				return $tree;
			}
			return new WP_Error( 'wd_ai_invalid_position', sprintf( '%s: position "%s" requires an anchor blockId.', $path, $position ) );
		}

		$applied = false;
		$tree    = self::insert_relative( $tree, $node, $position, $anchor, $applied );
		if ( ! $applied ) {
			return self::block_not_found_error( $anchor, $tree, 'anchor' );
		}
		return $tree;
	}

	// Tree primitives.

	/**
	 * The blockId of a spec node, or '' when it has none (e.g. core blocks).
	 *
	 * @param array<string,mixed> $block Block node.
	 * @return string
	 */
	private static function block_id_of( $block ) {
		return ( isset( $block['attributes']['blockId'] ) && is_string( $block['attributes']['blockId'] ) ) ? $block['attributes']['blockId'] : '';
	}

	/**
	 * Apply a field-level merge to the node with $block_id. Omitted fields are kept.
	 *
	 * @param array<int,array<string,mixed>> $blocks   Working tree.
	 * @param string                         $block_id blockId to update.
	 * @param array<string,mixed>            $fields   Fields to merge, as built by op_update().
	 * @param bool                           $applied  Set by reference to true if the block was found.
	 * @return array<int,array<string,mixed>>
	 */
	private static function apply_update( array $blocks, $block_id, $fields, &$applied ) {
		foreach ( $blocks as $i => $block ) {
			if ( self::block_id_of( $block ) === $block_id ) {
				$blocks[ $i ] = self::merge_fields( $block, $fields );
				$applied      = true;
				return $blocks;
			}
			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$blocks[ $i ]['innerBlocks'] = self::apply_update( $block['innerBlocks'], $block_id, $fields, $applied );
				if ( $applied ) {
					return $blocks;
				}
			}
		}
		return $blocks;
	}

	/**
	 * Merge {name, attributes, removeAttributes, innerBlocks, innerHTML} fields into a block node.
	 *
	 * @param array<string,mixed> $block  Existing block node.
	 * @param array<string,mixed> $fields Fields to apply, as built by op_update().
	 * @return array<string,mixed>
	 */
	private static function merge_fields( $block, $fields ) {
		if ( array_key_exists( 'name', $fields ) && is_string( $fields['name'] ) ) {
			$block['name'] = $fields['name'];
		}
		if ( array_key_exists( 'attributes', $fields ) || array_key_exists( 'removeAttributes', $fields ) ) {
			$existing = ( isset( $block['attributes'] ) && is_array( $block['attributes'] ) ) ? $block['attributes'] : array();
			$patch    = ( array_key_exists( 'attributes', $fields ) && is_array( $fields['attributes'] ) ) ? $fields['attributes'] : array();

			// Merge: provided keys override/add; existing keys (the block's current
			// attributes from the live content) are preserved. A null value, or a name
			// listed in removeAttributes, removes the attribute (resets it to default).
			$removals = array();
			if ( array_key_exists( 'removeAttributes', $fields ) && is_array( $fields['removeAttributes'] ) ) {
				foreach ( $fields['removeAttributes'] as $key ) {
					if ( is_string( $key ) ) {
						$removals[] = $key;
					}
				}
			}

			$merged = $existing;
			foreach ( $patch as $key => $value ) {
				if ( null === $value ) {
					$removals[] = (string) $key;
					continue;
				}
				$merged[ $key ] = $value;
			}
			foreach ( $removals as $key ) {
				unset( $merged[ $key ] );
			}

			// Preserve the addressed blockId so CSS keyed on it and the address stay stable.
			$existing_id = self::block_id_of( $block );
			if ( '' !== $existing_id ) {
				$merged['blockId'] = $existing_id;
			}
			$block['attributes'] = $merged;
		}
		if ( array_key_exists( 'innerBlocks', $fields ) ) {
			$block['innerBlocks'] = is_array( $fields['innerBlocks'] ) ? array_values( $fields['innerBlocks'] ) : array();
		}
		if ( array_key_exists( 'innerHTML', $fields ) && is_string( $fields['innerHTML'] ) ) {
			$block['innerHTML'] = $fields['innerHTML'];
		}
		return $block;
	}

	/**
	 * Remove the node with $block_id (and its subtree); set $removed to it.
	 *
	 * @param array<int,array<string,mixed>> $blocks   Working tree.
	 * @param string                         $block_id blockId to remove.
	 * @param array<string,mixed>|null       $removed  Set by reference to the removed node, or left null if not found.
	 * @return array<int,array<string,mixed>>
	 */
	private static function detach_block( array $blocks, $block_id, &$removed ) {
		foreach ( $blocks as $i => $block ) {
			if ( self::block_id_of( $block ) === $block_id ) {
				$removed = $block;
				array_splice( $blocks, $i, 1 );
				return $blocks;
			}
			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$blocks[ $i ]['innerBlocks'] = self::detach_block( $block['innerBlocks'], $block_id, $removed );
				if ( null !== $removed ) {
					return $blocks;
				}
			}
		}
		return $blocks;
	}

	/**
	 * Insert $node relative to the node with $anchor_id.
	 *
	 * @param array<int,array<string,mixed>> $blocks    Working tree.
	 * @param array<string,mixed>            $node      Node to insert.
	 * @param string                         $position  One of before|after|first-child|last-child.
	 * @param string                         $anchor_id blockId to insert relative to.
	 * @param bool                           $applied   Set by reference to true if the anchor was found.
	 * @return array<int,array<string,mixed>>
	 */
	private static function insert_relative( array $blocks, array $node, $position, $anchor_id, &$applied ) {
		foreach ( $blocks as $i => $block ) {
			if ( self::block_id_of( $block ) === $anchor_id ) {
				if ( 'before' === $position ) {
					array_splice( $blocks, $i, 0, array( $node ) );
				} elseif ( 'after' === $position ) {
					array_splice( $blocks, $i + 1, 0, array( $node ) );
				} elseif ( 'first-child' === $position ) {
					$children = ( isset( $blocks[ $i ]['innerBlocks'] ) && is_array( $blocks[ $i ]['innerBlocks'] ) ) ? $blocks[ $i ]['innerBlocks'] : array();
					array_unshift( $children, $node );
					$blocks[ $i ]['innerBlocks'] = $children;
				} else { // last-child
					$children                    = ( isset( $blocks[ $i ]['innerBlocks'] ) && is_array( $blocks[ $i ]['innerBlocks'] ) ) ? $blocks[ $i ]['innerBlocks'] : array();
					$children[]                  = $node;
					$blocks[ $i ]['innerBlocks'] = $children;
				}
				$applied = true;
				return $blocks;
			}
			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$blocks[ $i ]['innerBlocks'] = self::insert_relative( $block['innerBlocks'], $node, $position, $anchor_id, $applied );
				if ( $applied ) {
					return $blocks;
				}
			}
		}
		return $blocks;
	}

	/**
	 * Return the subtree (node) with $block_id, or null.
	 *
	 * @param array<int,array<string,mixed>> $blocks   Working tree.
	 * @param string                         $block_id blockId to find.
	 * @return array<string,mixed>|null
	 */
	private static function find_subtree( array $blocks, $block_id ) {
		foreach ( $blocks as $block ) {
			if ( self::block_id_of( $block ) === $block_id ) {
				return $block;
			}
			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				$found = self::find_subtree( $block['innerBlocks'], $block_id );
				if ( null !== $found ) {
					return $found;
				}
			}
		}
		return null;
	}

	/**
	 * All blockIds present in the tree (depth-first).
	 *
	 * @param array<int,array<string,mixed>> $blocks Working tree.
	 * @return string[]
	 */
	private static function collect_block_ids( array $blocks ) {
		$ids = array();
		foreach ( $blocks as $block ) {
			$id = self::block_id_of( $block );
			if ( '' !== $id ) {
				$ids[] = $id;
			}
			if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
				foreach ( self::collect_block_ids( $block['innerBlocks'] ) as $child_id ) {
					$ids[] = $child_id;
				}
			}
		}
		return $ids;
	}

	/**
	 * Find the first blockId that appears more than once in the tree.
	 *
	 * @param array<int,array<string,mixed>> $blocks Working tree.
	 * @return string|null First blockId seen twice, or null when all are unique.
	 */
	public static function first_duplicate_block_id( array $blocks ) {
		$duplicates = self::duplicate_block_ids( $blocks );

		return $duplicates ? $duplicates[0] : null;
	}

	/**
	 * Every blockId that appears more than once in the tree.
	 *
	 * A duplicate is not always an error. Some WoodMart blocks deliberately share a
	 * blockId with a companion block — wd/products-tabs-products carries the blockId
	 * of the wd/products-tabs-tab it renders — so a page holding a products-tabs block
	 * contains duplicates before an agent touches anything. Callers must therefore
	 * compare the duplicates a page already had against the ones an edit produced,
	 * and only reject the new ones. Rejecting every duplicate made gutenberg-edit-blocks
	 * fail on any page with a products-tabs block, even for edits nowhere near it.
	 *
	 * @param array<int,array<string,mixed>> $blocks Working tree.
	 * @return array<int,string> Duplicated blockIds, in first-seen order.
	 */
	public static function duplicate_block_ids( array $blocks ) {
		$counts = array();
		foreach ( self::collect_block_ids( $blocks ) as $id ) {
			$counts[ $id ] = isset( $counts[ $id ] ) ? $counts[ $id ] + 1 : 1;
		}

		$duplicates = array();
		foreach ( $counts as $id => $count ) {
			if ( $count > 1 ) {
				$duplicates[] = (string) $id;
			}
		}

		return $duplicates;
	}

	/**
	 * Normalize a raw inserted block spec into the working node shape.
	 *
	 * @param array<string,mixed> $spec Raw {name, attributes?, innerBlocks?, innerHTML?} spec.
	 * @return array<string,mixed>
	 */
	private static function node_from_spec( $spec ) {
		$node = array(
			'name'        => (string) $spec['name'],
			'attributes'  => ( isset( $spec['attributes'] ) && is_array( $spec['attributes'] ) ) ? $spec['attributes'] : array(),
			'innerBlocks' => ( isset( $spec['innerBlocks'] ) && is_array( $spec['innerBlocks'] ) ) ? array_values( $spec['innerBlocks'] ) : array(),
		);
		if ( isset( $spec['innerHTML'] ) && is_string( $spec['innerHTML'] ) ) {
			$node['innerHTML'] = $spec['innerHTML'];
		}
		return $node;
	}

	/**
	 * Build the "no block with this id" error, listing the ids that do exist.
	 *
	 * @param string                         $block_id Missing blockId (or anchor).
	 * @param array<int,array<string,mixed>> $tree     Working tree, for the available_block_ids hint.
	 * @param string                         $kind     Label for the missing id ("blockId" or "anchor").
	 * @return WP_Error
	 */
	private static function block_not_found_error( $block_id, array $tree, $kind = 'blockId' ) {
		return new WP_Error(
			'wd_ai_block_not_found',
			sprintf( 'No block with %s "%s" was found. Only wd/* blocks (which carry a blockId) are addressable; read current ids with gutenberg-get-content.', $kind, $block_id ),
			array(
				'status'              => 404,
				'available_block_ids' => array_values( array_unique( self::collect_block_ids( $tree ) ) ),
			)
		);
	}

	/**
	 * Convert a parse_blocks() node into a {name, attributes, innerHTML, innerBlocks} spec.
	 *
	 * The innerHTML is preserved because RichText/html-sourced content (e.g. wd/button,
	 * core/paragraph, core/heading text) lives in the saved markup, NOT in the
	 * delimiter JSON attributes. Returning it lets an agent preserve existing text
	 * on a replace-content round-trip; the finalizer rebuilds such leaf blocks from
	 * this innerHTML so the html-sourced attributes survive.
	 *
	 * @param array<string,mixed> $block One entry from parse_blocks().
	 * @return array<string,mixed>
	 */
	public static function parsed_block_to_spec( $block ) {
		$inner = array();
		if ( ! empty( $block['innerBlocks'] ) && is_array( $block['innerBlocks'] ) ) {
			foreach ( $block['innerBlocks'] as $child ) {
				if ( empty( $child['blockName'] ) ) {
					continue;
				}
				$inner[] = self::parsed_block_to_spec( $child );
			}
		}

		return array(
			'name'        => $block['blockName'],
			'attributes'  => isset( $block['attrs'] ) && is_array( $block['attrs'] ) ? $block['attrs'] : array(),
			'innerHTML'   => isset( $block['innerHTML'] ) && is_string( $block['innerHTML'] ) ? $block['innerHTML'] : '',
			'innerBlocks' => $inner,
		);
	}
}
