<?php
/**
 * AI abilities — queue a replace-content change for a target.
 *
 * Covers gutenberg-add-pending-change (full-page replace) and gutenberg-edit-blocks
 * (token-efficient partial edit of a page by addressing wd/* blocks via their
 * blockId; the server merges the operations into the live block tree and queues
 * the resulting full tree the same way). Storage and finalization are shared
 * between both abilities.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Gutenberg;

use WP_Error;
use WP_Post;
use XTS\AI_Abilities\Permission;
use XTS\AI_Abilities\Support;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ability handlers that queue a replace-content change for a target post.
 */
class Pending_Changes {
	const RAW_HTML_GUIDANCE = 'All content in this change is raw HTML (core/html or classic). Compose with registered blocks instead — pass {name, attributes, innerBlocks} for core blocks or wd/* blocks. If the raw HTML is intentional, resend with allow_raw_html set to true.';

	/**
	 * Queue storage service.
	 *
	 * @var Storage
	 */
	private $storage;

	/**
	 * Constructor.
	 *
	 * @param Storage $storage Queue storage service.
	 */
	public function __construct( Storage $storage ) {
		$this->storage = $storage;
	}

	/**
	 * Queue a full-page replace-content change for one target.
	 *
	 * @param array<string,mixed> $input Ability input.
	 * @return array<string,mixed>|WP_Error
	 */
	public function ability_add_pending_change( $input ) {
		$target_id = Support::resolve_target_id( $input );
		$target    = get_post( $target_id );
		if ( ! $target instanceof WP_Post ) {
			return new WP_Error( 'wd_ai_target_not_found', sprintf( 'Target post %d was not found.', $target_id ) );
		}

		$operation = isset( $input['operation'] ) ? (string) $input['operation'] : 'replace-content';
		if ( 'replace-content' !== $operation ) {
			return new WP_Error( 'wd_ai_unsupported_operation', 'Only operation="replace-content" is supported.' );
		}

		$blocks = Block_Normalizer::normalize_blocks( isset( $input['block_spec'] ) ? $input['block_spec'] : null );
		if ( is_wp_error( $blocks ) ) {
			return $blocks;
		}

		$batch_id = isset( $input['batch_id'] ) ? (int) $input['batch_id'] : 0;
		$label    = isset( $input['label'] ) ? (string) $input['label'] : '';

		return $this->queue_replace_content( $target, $blocks, $batch_id, $label, ! empty( $input['allow_raw_html'] ) );
	}

	/**
	 * Queue a normalized full block tree as a replace-content item.
	 *
	 * Shared by gutenberg-add-pending-change (full-page replace) and
	 * gutenberg-edit-blocks (server-side merge of partial edits). Performs the
	 * raw-HTML guard, the one-active-item-per-target guard, batch resolution, and
	 * item creation. Returns the same response shape for both abilities.
	 *
	 * @param WP_Post                        $target         Target post.
	 * @param array<int,array<string,mixed>> $blocks         Normalized top-level block tree.
	 * @param int                            $batch_id       Existing draft batch id, or 0 to auto-create one.
	 * @param string                         $label          Label for an auto-created batch.
	 * @param bool                           $allow_raw_html Whether to bypass the raw-HTML-only guard.
	 * @return array<string,mixed>|WP_Error
	 */
	public function queue_replace_content( WP_Post $target, array $blocks, $batch_id, $label, $allow_raw_html ) {
		// Single choke point for every queueing path (add-pending-change, edit-blocks,
		// create-content, create-layout), so the object-level check cannot be bypassed
		// by adding another caller.
		$denied = Permission::check_can_edit( $target );
		if ( $denied ) {
			return $denied;
		}

		if ( ! $allow_raw_html && Block_Normalizer::blocks_are_raw_html_only( $blocks ) ) {
			return new WP_Error( 'wd_ai_raw_html_only', self::RAW_HTML_GUIDANCE );
		}

		$existing = $this->storage->active_item_for_target( $target->ID );
		if ( $existing instanceof WP_Post ) {
			return new WP_Error(
				'wd_ai_target_has_pending_change',
				sprintf( 'Post %d already has a non-terminal queued change in batch #%d.', $target->ID, $existing->post_parent ),
				array(
					'status'         => 409,
					'batch_id'       => $existing->post_parent,
					'cancel_ability' => 'woodmart/gutenberg-delete-pending-batch',
				)
			);
		}

		$batch_id = (int) $batch_id;
		if ( $batch_id <= 0 ) {
			$batch_id = $this->storage->create_batch( (string) $label );
		}
		$batch = $this->storage->find_batch( $batch_id );
		if ( ! $batch instanceof WP_Post ) {
			return new WP_Error( 'wd_ai_batch_not_found', sprintf( 'Batch %d was not found.', $batch_id ) );
		}
		if ( Storage::STATUS_DRAFT !== $this->storage->status( $batch->ID ) ) {
			return new WP_Error( 'wd_ai_batch_not_draft', sprintf( 'Batch %d is %s; only draft batches accept new changes.', $batch->ID, $this->storage->status( $batch->ID ) ) );
		}

		$item_id = $this->storage->create_item( $batch->ID, $target->ID, 'replace-content', $blocks, $target->post_content, Storage::content_hash( $target->post_content ) );
		if ( is_wp_error( $item_id ) ) {
			return $item_id;
		}

		return array(
			'batch_id'              => $batch->ID,
			'item_id'               => $item_id,
			'batch_status'          => $this->storage->status( $batch->ID ),
			'target'                => array(
				'target_id' => $target->ID,
				'title'     => $target->post_title,
			),
			'finalization_required' => true,
			'user_instruction'      => $this->user_instruction( $batch->ID ),
		);
	}

	/**
	 * Text telling the agent how to drive finalization (no MCP-specific assumptions).
	 *
	 * @param int $batch_id Batch post ID.
	 * @return string
	 */
	public function user_instruction( $batch_id ) {
		return sprintf(
			'Change queued in batch #%d. To make it live: ask the user to open the WoodMart -> Tools -> AI Block Queue page in wp-admin (%s) and keep it open, then call woodmart/gutenberg-enable-finalization with batch_id %d. Poll woodmart/gutenberg-get-pending-batch until status is "finalized" (or "failed"/"conflicted"). Queued changes are not live until status is "finalized".',
			$batch_id,
			Finalizer_Page::url(),
			$batch_id
		);
	}

	/**
	 * Apply a sequence of update/delete/insert/move operations to a target's block tree.
	 *
	 * @param array<string,mixed> $input Ability input.
	 * @return array<string,mixed>|WP_Error
	 */
	public function ability_edit_blocks( $input ) {
		$target_id = Support::resolve_target_id( $input );
		$target    = get_post( $target_id );
		if ( ! $target instanceof WP_Post ) {
			return new WP_Error( 'wd_ai_target_not_found', sprintf( 'Target post %d was not found.', $target_id ) );
		}

		$expected = isset( $input['expected_content_hash'] ) ? (string) $input['expected_content_hash'] : '';
		if ( '' !== $expected && ! hash_equals( $expected, Storage::content_hash( $target->post_content ) ) ) {
			return new WP_Error(
				'wd_ai_content_changed',
				'The target content changed since you read it (expected_content_hash mismatch). Re-read with gutenberg-get-content and retry.',
				array( 'status' => 409 )
			);
		}

		$operations = isset( $input['operations'] ) ? $input['operations'] : null;
		if ( ! is_array( $operations ) || array() === $operations ) {
			return new WP_Error( 'wd_ai_invalid_operations', 'operations must be a non-empty array of edit operations.' );
		}

		// Build the working spec tree from the live content.
		$tree = array();
		foreach ( parse_blocks( $target->post_content ) as $block ) {
			if ( empty( $block['blockName'] ) ) {
				continue; // Skip whitespace/null blocks.
			}
			$tree[] = Block_Editor::parsed_block_to_spec( $block );
		}

		// Duplicate blockIds the page already had. Some WoodMart blocks share an id by
		// design (wd/products-tabs-products mirrors its wd/products-tabs-tab), so these
		// must not be blamed on the edit — see Block_Editor::duplicate_block_ids().
		$existing_duplicates = Block_Editor::duplicate_block_ids( $tree );

		foreach ( array_values( $operations ) as $index => $op ) {
			$result = Block_Editor::apply_operation( $tree, $op, "operations[$index]" );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
			$tree = $result;
		}

		if ( array() === $tree ) {
			return new WP_Error( 'wd_ai_empty_spec', 'The operations would leave the page with no blocks.' );
		}

		$blocks = Block_Normalizer::normalize_blocks( $tree );
		if ( is_wp_error( $blocks ) ) {
			return $blocks;
		}

		// Only duplicates the edit introduced are errors; the ones the page already had
		// are left alone so an unrelated edit is not blocked by them.
		$new_duplicates = array_values( array_diff( Block_Editor::duplicate_block_ids( $blocks ), $existing_duplicates ) );
		if ( $new_duplicates ) {
			return new WP_Error(
				'wd_ai_duplicate_block_id',
				sprintf( 'blockId "%s" appears more than once after the edits. blockIds must be unique.', $new_duplicates[0] )
			);
		}

		$batch_id = isset( $input['batch_id'] ) ? (int) $input['batch_id'] : 0;
		$label    = isset( $input['label'] ) ? (string) $input['label'] : '';

		return $this->queue_replace_content( $target, $blocks, $batch_id, $label, ! empty( $input['allow_raw_html'] ) );
	}

	/**
	 * Register the woodmart/gutenberg-add-pending-change and woodmart/gutenberg-edit-blocks abilities.
	 *
	 * @return void
	 */
	public function register() {
		wp_register_ability(
			'woodmart/gutenberg-add-pending-change',
			array(
				'label'               => 'Add WoodMart Gutenberg Pending Change',
				'description'         => 'Queue a full replace-content change for an empty target or a deliberate full rebuild. Never use this for a partial edit of a target that already has blocks; use gutenberg-edit-blocks and send only the operations that change. Static blocks are serialized by the AI Block Queue admin page before they become live. Omit batch_id to auto-create a batch.',
				'category'            => 'woodmart-gutenberg',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array_merge(
						array(
							'batch_id' => array(
								'type'        => 'integer',
								'description' => 'Existing draft batch id. Omit to auto-create.',
							),
							'label'    => array( 'type' => 'string' ),
						),
						Support::target_id_properties(),
						array(
							'operation'      => array(
								'type'    => 'string',
								'enum'    => array( 'replace-content' ),
								'default' => 'replace-content',
							),
							'block_spec'     => array(
								'type'        => 'array',
								'description' => 'Top-level blocks: [{name, attributes, innerBlocks}].',
								'items'       => array( 'type' => 'object' ),
							),
							'allow_raw_html' => array(
								'type'    => 'boolean',
								'default' => false,
							),
						)
					),
					'required'             => array( 'block_spec', 'target_id' ),
					'additionalProperties' => false,
				),
				'execute_callback'    => array( $this, 'ability_add_pending_change' ),
				'permission_callback' => array( Permission::class, 'callback' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'destructive' => false,
						'idempotent'  => false,
					),
				),
			)
		);

		wp_register_ability(
			'woodmart/gutenberg-edit-blocks',
			array(
				'label'               => 'Edit WoodMart Gutenberg Blocks',
				'description'         => 'Token-efficient partial edit of a page by addressing wd/* blocks via their blockId. Send only the blocks/operations that change; the server merges them into the live page and queues a replace-content change. Use this instead of gutenberg-add-pending-change when a request touches specific blocks rather than the whole page. Only wd/* blocks (which carry a blockId) are addressable; core blocks pass through untouched. Finalize the same way (AI Block Queue page).',
				'category'            => 'woodmart-gutenberg',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array_merge(
						Support::target_id_properties(),
						array(
							'operations'            => array(
								'type'        => 'array',
								'minItems'    => 1,
								'description' => 'Ordered edits applied sequentially to the live block tree. Each item is an object keyed by "op": '
									. 'op="update" {op, blockId, attributes?, removeAttributes?, innerBlocks?, innerHTML?, name?} — at least one of attributes/removeAttributes/innerBlocks/innerHTML/name. attributes is MERGED into the block\'s current attributes: send only the keys to add or change; unspecified attributes are preserved (do not resend unchanged styling). Remove an attribute (reset to default) by listing its name in removeAttributes or setting it to null. blockId is always preserved. omitted innerBlocks/innerHTML/name keep their existing value. '
									. 'op="delete" {op, blockId} — removes the block and its subtree. '
									. 'op="insert" {op, block:{name, attributes?, innerBlocks?, innerHTML?}, position, anchor?}. '
									. 'op="move" {op, blockId, position, anchor?} — relocates an existing block. '
									. 'position is one of before|after|first-child|last-child. anchor is a blockId: required for before/after, and to target inside a block use first-child/last-child with that anchor; omit anchor with first-child/last-child to target the page root (start/end).',
								'items'       => array( 'type' => 'object' ),
							),
							'batch_id'              => array(
								'type'        => 'integer',
								'description' => 'Existing draft batch id. Omit to auto-create.',
							),
							'label'                 => array( 'type' => 'string' ),
							'expected_content_hash' => array(
								'type'        => 'string',
								'description' => 'Optional. The content_hash from your last get-content. If it no longer matches the live content the call is rejected so you can re-read before editing.',
							),
							'allow_raw_html'        => array(
								'type'    => 'boolean',
								'default' => false,
							),
						)
					),
					'required'             => array( 'operations', 'target_id' ),
					'additionalProperties' => false,
				),
				'execute_callback'    => array( $this, 'ability_edit_blocks' ),
				'permission_callback' => array( Permission::class, 'callback' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'destructive' => false,
						'idempotent'  => false,
					),
				),
			)
		);
	}
}
