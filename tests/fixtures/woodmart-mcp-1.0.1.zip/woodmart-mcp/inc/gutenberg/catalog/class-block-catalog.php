<?php
/**
 * AI abilities — block catalog loader.
 *
 * Reads the generated attribute schema (blocks-catalog.generated.json, produced by
 * build/generate-blocks-catalog.js) and the hand-curated enrichment
 * (blocks-catalog.overrides.json), deep-merges them, and caches the result for the
 * gutenberg-list-blocks / gutenberg-describe-block abilities. Generated values are
 * authoritative for structure (type/source/selector/default); overrides supply
 * prose, value options, and dependencies.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Gutenberg;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Block catalog loader.
 */
class Block_Catalog {

	const GENERATED_FILE        = __DIR__ . '/blocks-catalog.generated.json';
	const OVERRIDES_FILE        = __DIR__ . '/blocks-catalog.overrides.json';
	const GROUPS_GENERATED_FILE = __DIR__ . '/attribute-groups.generated.json';
	const GROUPS_OVERRIDES_FILE = __DIR__ . '/attribute-groups.overrides.json';

	/**
	 * The merged catalog keyed by block name. Cached per-request.
	 *
	 * @var array<string,array<string,mixed>>|null
	 */
	private $cache = null;

	/**
	 * Shared attribute groups cache. Cached per-request.
	 *
	 * @var array<string,array<string,mixed>>|null
	 */
	private $groups_cache = null;

	/**
	 * The merged catalog keyed by block name. Cached per-request.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	public function load() {
		if ( null !== $this->cache ) {
			return $this->cache;
		}

		$generated = $this->read_json( self::GENERATED_FILE );
		$overrides = $this->read_json( self::OVERRIDES_FILE );

		foreach ( $overrides as $block_name => $override ) {
			if ( '' === $block_name || '_' === $block_name[0] || ! is_array( $override ) ) {
				continue; // Skip _comment and malformed entries.
			}
			$generated[ $block_name ] = isset( $generated[ $block_name ] )
				? $this->merge_block( $generated[ $block_name ], $override )
				: $override;
		}

		ksort( $generated );
		$this->cache = $generated;
		return $this->cache;
	}

	/**
	 * Merge one block's curated override onto its generated entry.
	 *
	 * @param array<string,mixed> $base     Generated block entry.
	 * @param array<string,mixed> $override Curated entry.
	 * @return array<string,mixed>
	 */
	private function merge_block( $base, $override ) {
		$attr_override = isset( $override['attributes'] ) && is_array( $override['attributes'] ) ? $override['attributes'] : array();
		unset( $override['attributes'] );

		// Block-level prose/markers override generated values.
		$merged = array_merge( $base, $override );

		$attributes = isset( $merged['attributes'] ) && is_array( $merged['attributes'] ) ? $merged['attributes'] : array();
		foreach ( $attr_override as $attr_name => $attr_meta ) {
			if ( ! is_array( $attr_meta ) ) {
				continue;
			}
			$existing                 = isset( $attributes[ $attr_name ] ) && is_array( $attributes[ $attr_name ] ) ? $attributes[ $attr_name ] : array();
			$attributes[ $attr_name ] = array_merge( $existing, $attr_meta );
		}
		$merged['attributes'] = $attributes;

		return $merged;
	}

	/**
	 * Read and decode a JSON file, returning an empty array if it is missing or invalid.
	 *
	 * @param string $file Absolute file path.
	 * @return array<string,mixed>
	 */
	private function read_json( $file ) {
		if ( ! is_readable( $file ) ) {
			return array();
		}
		$decoded = wp_json_file_decode( $file, array( 'associative' => true ) );
		return is_array( $decoded ) ? $decoded : array();
	}

	/**
	 * Shared attribute groups (advanced, color, typography, ...) keyed by id.
	 * Generated values + optional curated overrides. Cached per-request.
	 *
	 * @return array<string,array<string,mixed>>
	 */
	public function load_groups() {
		if ( null !== $this->groups_cache ) {
			return $this->groups_cache;
		}

		$groups    = $this->read_json( self::GROUPS_GENERATED_FILE );
		$overrides = $this->read_json( self::GROUPS_OVERRIDES_FILE );

		foreach ( $overrides as $id => $override ) {
			if ( '' === $id || '_' === $id[0] || ! is_array( $override ) ) {
				continue;
			}
			$groups[ $id ] = isset( $groups[ $id ] ) ? array_merge( $groups[ $id ], $override ) : $override;
		}

		$this->groups_cache = $groups;
		return $this->groups_cache;
	}

	/**
	 * Normalize a raw attribute map (name => def) into a lean ordered list shared by
	 * gutenberg-describe-block and gutenberg-describe-attribute-group.
	 *
	 * @param array<string,mixed> $attrs Raw attribute map (name => def).
	 * @return array<int,array<string,mixed>>
	 */
	public static function attributes_to_list( $attrs ) {
		$out = array();
		foreach ( (array) $attrs as $name => $def ) {
			if ( ! is_array( $def ) ) {
				$def = array();
			}
			$entry = array( 'name' => (string) $name );
			foreach ( array( 'type', 'default', 'source', 'selector', 'description', 'unit', 'minimum', 'maximum', 'examples', 'resetValue', 'agentWritable', 'requiredWith' ) as $key ) {
				if ( array_key_exists( $key, $def ) ) {
					$entry[ $key ] = $def[ $key ];
				}
			}
			if ( ! empty( $def['xtsResponsive'] ) ) {
				$entry['responsive'] = true;
			}
			if ( isset( $def['xtsUnits'] ) ) {
				// Value is the default CSS unit; a companion "<name>Units" attribute holds it.
				$entry['units'] = $def['xtsUnits'];
			}
			if ( isset( $def['options'] ) ) {
				$entry['options'] = $def['options'];
			}
			if ( isset( $def['dependsOn'] ) ) {
				$entry['dependsOn'] = $def['dependsOn'];
			}
			$out[] = $entry;
		}
		return $out;
	}

	/**
	 * Compact index entry for one block (used by gutenberg-list-blocks).
	 *
	 * @param array<string,mixed> $block Catalog block entry.
	 * @return array<string,mixed>
	 */
	public static function index_entry( $block ) {
		$entry = array(
			'name'        => isset( $block['name'] ) ? $block['name'] : '',
			'title'       => isset( $block['title'] ) ? $block['title'] : '',
			'category'    => isset( $block['category'] ) ? $block['category'] : '',
			'description' => isset( $block['description'] ) ? $block['description'] : '',
		);

		if ( ! empty( $block['composition']['requiresInnerBlocks'] ) ) {
			$entry['requiresInnerBlocks'] = true;
		}

		return $entry;
	}
}
