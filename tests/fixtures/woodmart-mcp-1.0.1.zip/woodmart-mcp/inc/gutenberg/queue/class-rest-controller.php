<?php
/**
 * AI abilities — internal REST routes for the finalizer page.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Gutenberg;

use WP_Error;
use WP_Post;
use WP_REST_Request;
use WP_REST_Response;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Internal REST routes for the finalizer page.
 */
class Rest_Controller {

	/**
	 * Queue storage service.
	 *
	 * @var Storage
	 */
	private $storage;

	/**
	 * Finalization runtime.
	 *
	 * @var Finalization
	 */
	private $finalization;

	/**
	 * Constructor.
	 *
	 * @param Storage      $storage      Queue storage service.
	 * @param Finalization $finalization Finalization runtime.
	 */
	public function __construct( Storage $storage, Finalization $finalization ) {
		$this->storage      = $storage;
		$this->finalization = $finalization;
	}

	/**
	 * Register the internal REST routes consumed by the AI Block Queue page.
	 *
	 * @return void
	 */
	public function register_routes() {
		$can = array( $this, 'rest_permission' );

		register_rest_route(
			'wd/v1',
			'/gb-queue/batches',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'rest_list_batches' ),
				'permission_callback' => $can,
			)
		);
		register_rest_route(
			'wd/v1',
			'/gb-queue/batches/(?P<batch_id>\d+)/claim',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'rest_claim_batch' ),
				'permission_callback' => $can,
			)
		);
		register_rest_route(
			'wd/v1',
			'/gb-queue/items/(?P<item_id>\d+)/spec',
			array(
				'methods'             => 'GET',
				'callback'            => array( $this, 'rest_item_spec' ),
				'permission_callback' => $can,
			)
		);
		register_rest_route(
			'wd/v1',
			'/gb-queue/items/(?P<item_id>\d+)/complete',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'rest_complete_item' ),
				'permission_callback' => $can,
			)
		);
		register_rest_route(
			'wd/v1',
			'/gb-queue/items/(?P<item_id>\d+)/fail',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'rest_fail_item' ),
				'permission_callback' => $can,
			)
		);
	}

	/**
	 * Shared permission callback for the gb-queue REST routes.
	 *
	 * @return bool
	 */
	public function rest_permission() {
		return current_user_can( 'edit_posts' );
	}

	/**
	 * Wrap a plain array result as a REST response, passing WP_Error through.
	 *
	 * Fits handlers that just delegate to a Finalization call and return its
	 * array|WP_Error result as-is (rest_claim_batch, rest_complete_item,
	 * rest_fail_item). Not used by rest_list_batches (never errors) or
	 * rest_item_spec (has its own multi-step error checks and adds editor_url
	 * on top of the Storage result, so there is no single array to wrap).
	 *
	 * @param mixed $value Result of a Finalization call.
	 * @return WP_REST_Response|WP_Error
	 */
	private function rest_to_response( $value ) {
		if ( is_wp_error( $value ) ) {
			return $value;
		}
		return new WP_REST_Response( $value );
	}

	/**
	 * GET /gb-queue/batches — list batches, optionally filtered by status.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return WP_REST_Response
	 */
	public function rest_list_batches( WP_REST_Request $request ) {
		$status   = $request->get_param( 'status' );
		$statuses = $status ? array_map( 'trim', explode( ',', (string) $status ) ) : array( Storage::STATUS_READY );
		$batches  = array();

		foreach ( $this->storage->get_batches( $statuses ) as $batch ) {
			$batches[] = $this->finalization->shape_batch( $batch );
		}

		return new WP_REST_Response( array( 'batches' => $batches ) );
	}

	/**
	 * POST /gb-queue/batches/{batch_id}/claim — claim a batch for finalization.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function rest_claim_batch( WP_REST_Request $request ) {
		return $this->rest_to_response( $this->finalization->claim_batch( (int) $request['batch_id'] ) );
	}

	/**
	 * GET /gb-queue/items/{item_id}/spec — the item's block_spec for the frame-side serializer.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function rest_item_spec( WP_REST_Request $request ) {
		$item = $this->storage->find_item( (int) $request['item_id'] );
		if ( ! $item instanceof WP_Post ) {
			return new WP_Error( 'wd_ai_item_not_found', 'Item not found.', array( 'status' => 404 ) );
		}
		$blocks = $this->storage->item_blocks( $item );
		if ( is_wp_error( $blocks ) ) {
			return $blocks;
		}
		return new WP_REST_Response(
			array(
				'item_id'    => $item->ID,
				'blocks'     => $blocks,
				'editor_url' => $this->rest_item_editor_url( $item ),
			)
		);
	}

	/**
	 * Build the (hidden-iframe) editor URL used to serialize an item's target.
	 *
	 * @param WP_Post $item Item post.
	 * @return string
	 */
	private function rest_item_editor_url( WP_Post $item ) {
		$target_id = $this->storage->meta_int( $item->ID, Storage::META_TARGET_ID );
		$target    = get_post( $target_id );
		$host      = $target instanceof WP_Post ? $this->serializer_host_post( $target ) : null;
		$host_id   = $host instanceof WP_Post ? $host->ID : $target_id;
		$editor    = get_edit_post_link( $host_id, 'raw' );
		if ( ! is_string( $editor ) || '' === $editor ) {
			$editor = admin_url( sprintf( 'post.php?post=%d&action=edit', $host_id ) );
		}
		return add_query_arg(
			array(
				'wd_ai_finalizer' => '1',
				'wd_ai_item'      => $item->ID,
			),
			$editor
		);
	}

	/**
	 * Find a post whose editor registers the block APIs needed by the serializer.
	 *
	 * Classic-editor post types such as WooCommerce products can still contain
	 * Gutenberg markup, but their edit screens do not load registered wd/* blocks.
	 * The host is used only as a browser runtime; the serialized content is written
	 * to the original queue target by Finalization.
	 *
	 * @param WP_Post $target Queue target.
	 * @return WP_Post
	 */
	private function serializer_host_post( WP_Post $target ) {
		if ( ! function_exists( 'use_block_editor_for_post' ) ) {
			require_once ABSPATH . 'wp-admin/includes/post.php';
		}

		if ( use_block_editor_for_post( $target ) ) {
			return $target;
		}

		$candidates = get_posts(
			array(
				'post_type'      => array( 'page', 'post' ),
				'post_status'    => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page' => 20,
				'orderby'        => 'modified',
				'order'          => 'DESC',
			)
		);

		foreach ( $candidates as $candidate ) {
			if ( current_user_can( 'edit_post', $candidate->ID ) && use_block_editor_for_post( $candidate ) ) {
				return $candidate;
			}
		}

		return $target;
	}

	/**
	 * POST /gb-queue/items/{item_id}/complete — stage the browser-serialized content.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function rest_complete_item( WP_REST_Request $request ) {
		$params = $request->get_json_params();
		return $this->rest_to_response(
			$this->finalization->complete_item(
				(int) $request['item_id'],
				isset( $params['content'] ) ? (string) $params['content'] : '',
				isset( $params['validations'] ) ? $params['validations'] : null
			)
		);
	}

	/**
	 * POST /gb-queue/items/{item_id}/fail — record a browser-side serialization failure.
	 *
	 * @param WP_REST_Request $request REST request.
	 * @return WP_REST_Response|WP_Error
	 */
	public function rest_fail_item( WP_REST_Request $request ) {
		$params = $request->get_json_params();
		return $this->rest_to_response(
			$this->finalization->fail_item(
				(int) $request['item_id'],
				isset( $params['errors'] ) ? $params['errors'] : array(),
				isset( $params['message'] ) ? (string) $params['message'] : 'Finalizer reported a failure.'
			)
		);
	}
}
