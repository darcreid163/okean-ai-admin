<?php
/**
 * AI abilities — Gutenberg queue storage.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Gutenberg;

use WP_Error;
use WP_Post;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * CRUD and query helpers for the hidden AI Gutenberg queue post type.
 *
 * Batches and items are stored as `self::POST_TYPE` posts distinguished by the
 * `_wd_kind` meta value (KIND_BATCH / KIND_ITEM). Items are children of their
 * batch via post_parent.
 */
class Storage {
	const POST_TYPE = 'wd_ai_gb_change';

	const KIND_BATCH = 'batch';
	const KIND_ITEM  = 'item';

	const META_KIND              = '_wd_kind';
	const META_STATUS            = '_wd_status';
	const META_STATUS_UPDATED_AT = '_wd_status_updated_at';
	const META_TARGET_ID         = '_wd_target_id';
	const META_OPERATION         = '_wd_operation';
	const META_BLOCK_SPEC        = '_wd_block_spec';
	const META_BASE_HASH         = '_wd_base_content_hash';
	const META_BASE_CONTENT      = '_wd_base_content';
	const META_FINALIZED_CONTENT = '_wd_finalized_content';
	const META_VALIDATION_ERRORS = '_wd_validation_errors';
	const META_LAST_ERROR        = '_wd_last_error';
	const META_LABEL             = '_wd_label';

	const STATUS_DRAFT      = 'draft';
	const STATUS_READY      = 'ready';
	const STATUS_RUNNING    = 'running';
	const STATUS_PREPARED   = 'prepared';
	const STATUS_FINALIZED  = 'finalized';
	const STATUS_FAILED     = 'failed';
	const STATUS_CONFLICTED = 'conflicted';
	const STATUS_CANCELED   = 'canceled';

	const NON_TERMINAL_STATUSES = array(
		self::STATUS_DRAFT,
		self::STATUS_READY,
		self::STATUS_RUNNING,
		self::STATUS_PREPARED,
		self::STATUS_FAILED,
		self::STATUS_CONFLICTED,
	);

	const TERMINAL_STATUSES = array(
		self::STATUS_FINALIZED,
		self::STATUS_CANCELED,
	);

	/**
	 * Register the hidden queue post type.
	 *
	 * @return void
	 */
	public function register_post_type() {
		register_post_type(
			self::POST_TYPE,
			array(
				'label'           => 'WoodMart AI Gutenberg queue',
				'public'          => false,
				'show_ui'         => false,
				'show_in_rest'    => false,
				'has_archive'     => false,
				'rewrite'         => false,
				'query_var'       => false,
				'capability_type' => 'post',
				'map_meta_cap'    => true,
				'supports'        => array( 'title' ),
			)
		);
	}

	/**
	 * Current UTC time formatted for storage in post meta.
	 *
	 * @return string
	 */
	public static function now_mysql() {
		return gmdate( 'Y-m-d H:i:s' );
	}

	/**
	 * Read a post meta value as a string.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $key     Meta key.
	 * @return string
	 */
	public function meta_string( $post_id, $key ) {
		$value = get_post_meta( $post_id, $key, true );
		return is_scalar( $value ) ? (string) $value : '';
	}

	/**
	 * Read a post meta value as an integer.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $key     Meta key.
	 * @return int
	 */
	public function meta_int( $post_id, $key ) {
		$value = get_post_meta( $post_id, $key, true );
		return is_scalar( $value ) ? (int) $value : 0;
	}

	/**
	 * Read a post meta value as an array.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $key     Meta key.
	 * @return array<int|string,mixed>
	 */
	public function meta_array( $post_id, $key ) {
		$value = get_post_meta( $post_id, $key, true );
		return is_array( $value ) ? $value : array();
	}

	/**
	 * Write a post meta value.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $key     Meta key.
	 * @param mixed  $value   Value to store.
	 * @return void
	 */
	public function set_meta( $post_id, $key, $value ) {
		update_post_meta( $post_id, $key, $value );
	}

	/**
	 * Delete a post meta value.
	 *
	 * @param int    $post_id Post ID.
	 * @param string $key     Meta key.
	 * @return void
	 */
	public function delete_meta( $post_id, $key ) {
		delete_post_meta( $post_id, $key );
	}

	/**
	 * Hash raw block content for conflict detection.
	 *
	 * @param mixed $content Raw post_content.
	 * @return string
	 */
	public static function content_hash( $content ) {
		return hash( 'sha256', (string) $content );
	}

	/**
	 * Current status of a batch or item, defaulting to draft.
	 *
	 * @param int $post_id Batch or item post ID.
	 * @return string
	 */
	public function status( $post_id ) {
		$status = $this->meta_string( $post_id, self::META_STATUS );
		return '' !== $status ? $status : self::STATUS_DRAFT;
	}

	/**
	 * Set a batch or item's status and refresh its status-updated timestamp.
	 *
	 * @param int    $post_id Batch or item post ID.
	 * @param string $status  One of the STATUS_* constants.
	 * @return void
	 */
	public function set_status( $post_id, $status ) {
		update_post_meta( $post_id, self::META_STATUS, $status );
		update_post_meta( $post_id, self::META_STATUS_UPDATED_AT, self::now_mysql() );
	}

	/**
	 * Look up a batch post by ID, verifying its post type and kind.
	 *
	 * @param int $id Post ID.
	 * @return WP_Post|null
	 */
	public function find_batch( $id ) {
		$post = get_post( $id );
		if ( ! $post instanceof WP_Post || self::POST_TYPE !== $post->post_type || self::KIND_BATCH !== $this->meta_string( $post->ID, self::META_KIND ) ) {
			return null;
		}
		return $post;
	}

	/**
	 * Look up an item post by ID, verifying its post type and kind.
	 *
	 * @param int $id Post ID.
	 * @return WP_Post|null
	 */
	public function find_item( $id ) {
		$post = get_post( $id );
		if ( ! $post instanceof WP_Post || self::POST_TYPE !== $post->post_type || self::KIND_ITEM !== $this->meta_string( $post->ID, self::META_KIND ) ) {
			return null;
		}
		return $post;
	}

	/**
	 * List a batch's item posts, optionally filtered by status.
	 *
	 * @param int           $batch_id Parent batch post ID.
	 * @param string[]|null $statuses Optional list of statuses to filter by.
	 * @return WP_Post[]
	 */
	public function get_items( $batch_id, $statuses = null ) {
		$meta_query = array(
			array(
				'key'   => self::META_KIND,
				'value' => self::KIND_ITEM,
			),
		);
		if ( null !== $statuses ) {
			$meta_query[] = array(
				'key'     => self::META_STATUS,
				'value'   => (array) $statuses,
				'compare' => 'IN',
			);
		}

		return get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'any',
				'post_parent'    => $batch_id,
				'posts_per_page' => -1,
				'orderby'        => 'ID',
				'order'          => 'ASC',
				'meta_query'     => $meta_query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
			)
		);
	}

	/**
	 * Create a new draft batch post.
	 *
	 * @param string $label Optional human-readable label.
	 * @return int Batch post ID, or 0 on failure.
	 */
	public function create_batch( $label = '' ) {
		$batch_id = wp_insert_post(
			array(
				'post_type'   => self::POST_TYPE,
				'post_status' => 'publish',
				'post_title'  => '' !== trim( $label ) ? sanitize_text_field( $label ) : 'AI Gutenberg batch',
			)
		);

		if ( ! $batch_id ) {
			return 0;
		}

		update_post_meta( $batch_id, self::META_KIND, self::KIND_BATCH );
		update_post_meta( $batch_id, self::META_LABEL, sanitize_text_field( $label ) );
		$this->set_status( $batch_id, self::STATUS_DRAFT );

		return (int) $batch_id;
	}

	/**
	 * Create a new draft item post under a batch.
	 *
	 * @param int                            $batch_id     Parent batch post ID.
	 * @param int                            $target_id    Target post ID the change applies to.
	 * @param string                         $operation    Operation name (e.g. "replace-content").
	 * @param array<int,array<string,mixed>> $blocks       Normalized block spec to store.
	 * @param string                         $base_content Target's post_content at queue time.
	 * @param string                         $base_hash    Hash of $base_content for conflict detection.
	 * @return int|WP_Error
	 */
	public function create_item( $batch_id, $target_id, $operation, $blocks, $base_content, $base_hash ) {
		$encoded = wp_json_encode( $blocks );
		if ( ! is_string( $encoded ) ) {
			return new WP_Error( 'wd_ai_invalid_spec', 'The block_spec could not be encoded as JSON.' );
		}

		$item_id = wp_insert_post(
			array(
				'post_type'   => self::POST_TYPE,
				'post_status' => 'publish',
				'post_parent' => $batch_id,
				'post_title'  => 'AI item for #' . (int) $target_id,
			),
			true
		);
		if ( is_wp_error( $item_id ) ) {
			return $item_id;
		}

		update_post_meta( $item_id, self::META_KIND, self::KIND_ITEM );
		update_post_meta( $item_id, self::META_TARGET_ID, (int) $target_id );
		update_post_meta( $item_id, self::META_OPERATION, $operation );
		update_post_meta( $item_id, self::META_BLOCK_SPEC, wp_slash( $encoded ) );
		update_post_meta( $item_id, self::META_BASE_HASH, $base_hash );
		update_post_meta( $item_id, self::META_BASE_CONTENT, wp_slash( (string) $base_content ) );
		$this->set_status( $item_id, self::STATUS_DRAFT );

		return (int) $item_id;
	}

	/**
	 * Decode an item's stored block_spec.
	 *
	 * @param WP_Post $item Item post.
	 * @return array<int,array<string,mixed>>|WP_Error
	 */
	public function item_blocks( WP_Post $item ) {
		$encoded = $this->meta_string( $item->ID, self::META_BLOCK_SPEC );
		$decoded = json_decode( $encoded, true );
		if ( ! is_array( $decoded ) ) {
			return new WP_Error( 'wd_ai_invalid_stored_spec', sprintf( 'Item %d has an invalid stored block_spec.', $item->ID ) );
		}
		return $decoded;
	}

	/**
	 * The non-terminal (in-flight) item queued against a target, if any.
	 *
	 * @param int $target_id Target post ID.
	 * @return WP_Post|null
	 */
	public function active_item_for_target( $target_id ) {
		$items = get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'any',
				'posts_per_page' => 1,
				'orderby'        => 'ID',
				'order'          => 'ASC',
				'meta_query'     => array( // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
					array(
						'key'   => self::META_KIND,
						'value' => self::KIND_ITEM,
					),
					array(
						'key'     => self::META_TARGET_ID,
						'value'   => (int) $target_id,
						'compare' => '=',
						'type'    => 'NUMERIC',
					),
					array(
						'key'     => self::META_STATUS,
						'value'   => self::NON_TERMINAL_STATUSES,
						'compare' => 'IN',
					),
				),
			)
		);

		return isset( $items[0] ) ? $items[0] : null;
	}

	/**
	 * List batch posts, optionally filtered by status, most recent first.
	 *
	 * @param string[]|null $statuses Optional list of statuses to filter by.
	 * @return WP_Post[]
	 */
	public function get_batches( $statuses = null ) {
		$meta_query = array(
			array(
				'key'   => self::META_KIND,
				'value' => self::KIND_BATCH,
			),
		);
		if ( null !== $statuses ) {
			$meta_query[] = array(
				'key'     => self::META_STATUS,
				'value'   => $statuses,
				'compare' => 'IN',
			);
		}

		return get_posts(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'any',
				'posts_per_page' => 50,
				'orderby'        => 'ID',
				'order'          => 'DESC',
				'meta_query'     => $meta_query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
			)
		);
	}
}
