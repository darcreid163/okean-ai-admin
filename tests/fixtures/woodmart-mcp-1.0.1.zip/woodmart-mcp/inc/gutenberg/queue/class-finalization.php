<?php
/**
 * AI abilities — Gutenberg finalization runtime.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Gutenberg;

use WP_Error;
use WP_Post;
use XTS\AI_Abilities\Permission;
use XTS\AI_Abilities\Support;
use XTS\AI_Abilities\Gutenberg\Template_Library\Image_Localizer;
use XTS\AI_Abilities\Gutenberg\Pending_Changes;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Finalization ability handlers and shared finalization runtime.
 */
class Finalization {

	/**
	 * Queue storage service.
	 *
	 * @var Storage
	 */
	private $storage;

	/**
	 * Template-library image localizer.
	 *
	 * @var Image_Localizer
	 */
	private $image_localizer;

	/**
	 * Pending-changes handler (used for the shared user_instruction text).
	 *
	 * @var Pending_Changes
	 */
	private $pending_changes;

	/**
	 * Constructor.
	 *
	 * @param Storage         $storage         Queue storage service.
	 * @param Image_Localizer $image_localizer Template-library image localizer.
	 * @param Pending_Changes $pending_changes Pending-changes handler.
	 */
	public function __construct( Storage $storage, Image_Localizer $image_localizer, Pending_Changes $pending_changes ) {
		$this->storage         = $storage;
		$this->image_localizer = $image_localizer;
		$this->pending_changes = $pending_changes;
	}

	/**
	 * Mark a draft batch (and its draft items) ready for finalization.
	 *
	 * @param int $batch_id Batch post ID.
	 * @return array<string,mixed>|WP_Error
	 */
	public function enable_finalization( $batch_id ) {
		$batch = $this->storage->find_batch( $batch_id );
		if ( ! $batch instanceof WP_Post ) {
			return new WP_Error( 'wd_ai_batch_not_found', sprintf( 'Batch %d was not found.', $batch_id ) );
		}

		if ( Storage::STATUS_READY === $this->storage->status( $batch->ID ) ) {
			return $this->shape_batch( $batch );
		}

		if ( Storage::STATUS_DRAFT !== $this->storage->status( $batch->ID ) ) {
			return new WP_Error( 'wd_ai_batch_not_draft', sprintf( 'Batch %d is %s and cannot be enabled.', $batch->ID, $this->storage->status( $batch->ID ) ) );
		}

		$items = $this->storage->get_items( $batch->ID, array( Storage::STATUS_DRAFT ) );
		if ( array() === $items ) {
			return new WP_Error( 'wd_ai_batch_empty', sprintf( 'Batch %d has no draft items.', $batch->ID ) );
		}

		foreach ( $items as $item ) {
			$this->storage->set_status( $item->ID, Storage::STATUS_READY );
		}
		$this->storage->set_status( $batch->ID, Storage::STATUS_READY );

		return $this->shape_batch( $this->storage->find_batch( $batch->ID ) );
	}

	/**
	 * Claim a ready/failed batch for finalization.
	 *
	 * @param int $batch_id Batch post ID.
	 * @return array<string,mixed>|WP_Error
	 */
	public function claim_batch( $batch_id ) {
		$batch = $this->storage->find_batch( $batch_id );
		if ( ! $batch instanceof WP_Post ) {
			return new WP_Error( 'wd_ai_batch_not_found', sprintf( 'Batch %d was not found.', $batch_id ), array( 'status' => 404 ) );
		}

		if ( ! in_array( $this->storage->status( $batch->ID ), array( Storage::STATUS_READY, Storage::STATUS_FAILED ), true ) ) {
			return new WP_Error(
				'wd_ai_batch_not_claimable',
				sprintf( 'Batch %d is %s and cannot be claimed.', $batch->ID, $this->storage->status( $batch->ID ) ),
				array( 'status' => 409 )
			);
		}

		$this->storage->set_status( $batch->ID, Storage::STATUS_RUNNING );
		$this->storage->set_meta( $batch->ID, Storage::META_LAST_ERROR, '' );

		$items = array();
		foreach ( $this->storage->get_items( $batch->ID ) as $item ) {
			if ( in_array( $this->storage->status( $item->ID ), array( Storage::STATUS_DRAFT, Storage::STATUS_READY, Storage::STATUS_FAILED, Storage::STATUS_CONFLICTED ), true ) ) {
				$this->storage->set_status( $item->ID, Storage::STATUS_READY );
				$this->storage->set_meta( $item->ID, Storage::META_VALIDATION_ERRORS, array() );
				$this->localize_item_remote_images( $item->ID );
			}
			if ( Storage::STATUS_FINALIZED !== $this->storage->status( $item->ID ) ) {
				$items[] = array(
					'item_id'   => $item->ID,
					'target_id' => $this->storage->meta_int( $item->ID, Storage::META_TARGET_ID ),
				);
			}
		}

		return array(
			'batch_id' => $batch->ID,
			'items'    => $items,
		);
	}

	/**
	 * Localize any remote template-library images left in an item's stored
	 * block_spec (returned as-is by woodmart/gutenberg-get-template, which skips
	 * sideloading to stay fast/MCP-timeout-safe) before it is serialized. Runs
	 * here because claim_batch() is driven by the browser AI Block Queue page,
	 * not by an MCP tool call, so a slow multi-image sideload is safe. No-ops if
	 * the block_spec has nothing to localize or can't be read.
	 *
	 * @param int $item_id Item post ID.
	 * @return void
	 */
	public function localize_item_remote_images( $item_id ) {
		$item = $this->storage->find_item( $item_id );
		if ( ! $item instanceof WP_Post ) {
			return;
		}

		$blocks = $this->storage->item_blocks( $item );
		if ( is_wp_error( $blocks ) ) {
			return;
		}

		$result = $this->image_localizer->localize_remote_images( $blocks );
		if ( $result['changed'] ) {
			$this->storage->set_meta( $item->ID, Storage::META_BLOCK_SPEC, wp_slash( wp_json_encode( $result['blocks'] ) ) );
		}
	}

	/**
	 * Stage serialized content for an item; commit the batch when all items are prepared.
	 *
	 * @param int    $item_id     Item post ID.
	 * @param string $content     Browser-serialized post_content.
	 * @param mixed  $validations Browser-side validation payload.
	 * @return array<string,mixed>|WP_Error
	 */
	public function complete_item( $item_id, $content, $validations ) {
		$item = $this->storage->find_item( $item_id );
		if ( ! $item instanceof WP_Post ) {
			return new WP_Error( 'wd_ai_item_not_found', sprintf( 'Item %d was not found.', $item_id ), array( 'status' => 404 ) );
		}

		if ( $this->validations_have_failures( $validations ) ) {
			return $this->fail_item( $item->ID, $validations, 'JS validation failed; canonical content was not written.' );
		}

		$target_id = $this->storage->meta_int( $item->ID, Storage::META_TARGET_ID );
		$target    = get_post( $target_id );
		if ( ! $target instanceof WP_Post ) {
			return $this->fail_item( $item->ID, array( array( 'message' => 'The target post no longer exists.' ) ), 'Target post missing.' );
		}

		// Re-checked at commit time, not only when the item was queued: the browser
		// session that finalizes a batch is not necessarily the one that created it.
		$denied = Permission::check_can_edit( $target );
		if ( $denied ) {
			return $denied;
		}

		$base_hash = $this->storage->meta_string( $item->ID, Storage::META_BASE_HASH );
		if ( '' !== $base_hash && ! hash_equals( $base_hash, Storage::content_hash( $target->post_content ) ) ) {
			return $this->conflict_item( $item );
		}

		$this->storage->set_meta( $item->ID, Storage::META_FINALIZED_CONTENT, wp_slash( $content ) );
		$this->storage->set_meta( $item->ID, Storage::META_VALIDATION_ERRORS, array() );
		$this->storage->set_status( $item->ID, Storage::STATUS_PREPARED );

		$batch = $this->storage->find_batch( $item->post_parent );
		return $batch instanceof WP_Post ? $this->finish_batch_if_complete( $batch ) : array( 'done' => true );
	}

	/**
	 * Commit a batch once every item has been prepared, or mark it failed if any
	 * item failed/conflicted while others are still ready/running.
	 *
	 * @param WP_Post $batch Batch post.
	 * @return array<string,mixed>|WP_Error
	 */
	private function finish_batch_if_complete( WP_Post $batch ) {
		if ( array() !== $this->storage->get_items( $batch->ID, array( Storage::STATUS_READY, Storage::STATUS_RUNNING ) ) ) {
			return array(
				'done'  => false,
				'batch' => $this->shape_batch( $batch ),
			);
		}

		if ( array() !== $this->storage->get_items( $batch->ID, array( Storage::STATUS_FAILED, Storage::STATUS_CONFLICTED ) ) ) {
			$this->storage->set_status( $batch->ID, Storage::STATUS_FAILED );
			return array(
				'done'  => true,
				'batch' => $this->shape_batch( $this->storage->find_batch( $batch->ID ) ),
			);
		}

		return $this->commit_prepared_items( $batch );
	}

	/**
	 * Write staged content to every target, rolling back on mid-batch failure.
	 *
	 * @param WP_Post $batch Batch post.
	 * @return array<string,mixed>|WP_Error
	 */
	private function commit_prepared_items( WP_Post $batch ) {
		$prepared = $this->storage->get_items( $batch->ID, array( Storage::STATUS_PREPARED ) );
		if ( array() === $prepared ) {
			$this->storage->set_status( $batch->ID, Storage::STATUS_FINALIZED );
			return array(
				'done'  => true,
				'batch' => $this->shape_batch( $this->storage->find_batch( $batch->ID ) ),
			);
		}

		// Pre-flight: re-check every base hash before writing anything.
		foreach ( $prepared as $item ) {
			$target = get_post( $this->storage->meta_int( $item->ID, Storage::META_TARGET_ID ) );
			if ( ! $target instanceof WP_Post ) {
				return $this->fail_item( $item->ID, array( array( 'message' => 'Target post missing.' ) ), 'Target post missing; nothing was written.' );
			}
			$base_hash = $this->storage->meta_string( $item->ID, Storage::META_BASE_HASH );
			if ( '' !== $base_hash && ! hash_equals( $base_hash, Storage::content_hash( $target->post_content ) ) ) {
				return $this->conflict_item( $item );
			}
		}

		$written = array();
		foreach ( $prepared as $item ) {
			$target_id = $this->storage->meta_int( $item->ID, Storage::META_TARGET_ID );
			$updated   = wp_update_post(
				array(
					'ID'           => $target_id,
					'post_content' => wp_slash( $this->storage->meta_string( $item->ID, Storage::META_FINALIZED_CONTENT ) ),
				),
				true
			);

			if ( is_wp_error( $updated ) ) {
				foreach ( array_reverse( $written ) as $done ) {
					wp_update_post(
						array(
							'ID'           => $this->storage->meta_int( $done->ID, Storage::META_TARGET_ID ),
							'post_content' => wp_slash( $this->storage->meta_string( $done->ID, Storage::META_BASE_CONTENT ) ),
						)
					);
				}
				return $this->fail_item( $item->ID, array( array( 'message' => $updated->get_error_message() ) ), 'Write failed; rolled back.' );
			}

			$written[] = $item;
		}

		foreach ( $prepared as $item ) {
			$this->storage->set_status( $item->ID, Storage::STATUS_FINALIZED );
			$this->storage->delete_meta( $item->ID, Storage::META_BASE_CONTENT );
			$this->storage->delete_meta( $item->ID, Storage::META_FINALIZED_CONTENT );
		}
		$this->storage->set_status( $batch->ID, Storage::STATUS_FINALIZED );

		return array(
			'done'  => true,
			'batch' => $this->shape_batch( $this->storage->find_batch( $batch->ID ) ),
		);
	}

	/**
	 * Mark an item (and its batch) conflicted because its target changed since queuing.
	 *
	 * @param WP_Post $item Item post.
	 * @return WP_Error
	 */
	private function conflict_item( WP_Post $item ) {
		$this->storage->set_status( $item->ID, Storage::STATUS_CONFLICTED );
		$this->storage->set_meta(
			$item->ID,
			Storage::META_VALIDATION_ERRORS,
			array(
				array(
					'message' => 'The target changed after this change was queued. Re-read the target and queue again.',
					'code'    => 'base_content_changed',
				),
			)
		);
		$batch = $this->storage->find_batch( $item->post_parent );
		if ( $batch instanceof WP_Post ) {
			$this->storage->set_status( $batch->ID, Storage::STATUS_FAILED );
			$this->storage->set_meta( $batch->ID, Storage::META_LAST_ERROR, 'At least one target changed after it was queued; live content was left unchanged.' );
		}

		return new WP_Error(
			'wd_ai_target_changed',
			'The target content changed after this change was queued. Live content was left unchanged.',
			array(
				'status' => 409,
				'item'   => $this->shape_item( $item ),
			)
		);
	}

	/**
	 * Mark an item (and its batch) failed.
	 *
	 * @param int    $item_id Item post ID.
	 * @param mixed  $errors  Validation/serialization errors to store.
	 * @param string $message Human-readable failure summary stored on the batch.
	 * @return array<string,mixed>
	 */
	public function fail_item( $item_id, $errors, $message ) {
		$item = $this->storage->find_item( $item_id );
		if ( ! $item instanceof WP_Post ) {
			return array(
				'done'  => true,
				'error' => 'item_not_found',
			);
		}

		$this->storage->set_status( $item->ID, Storage::STATUS_FAILED );
		$this->storage->set_meta( $item->ID, Storage::META_VALIDATION_ERRORS, is_array( $errors ) ? array_values( $errors ) : array( array( 'message' => (string) $errors ) ) );

		$batch = $this->storage->find_batch( $item->post_parent );
		if ( $batch instanceof WP_Post ) {
			$this->storage->set_status( $batch->ID, Storage::STATUS_FAILED );
			$this->storage->set_meta( $batch->ID, Storage::META_LAST_ERROR, $message );
		}

		return array(
			'done'  => true,
			'item'  => $this->shape_item( $item ),
			'batch' => $batch instanceof WP_Post ? $this->shape_batch( $batch ) : null,
		);
	}

	/**
	 * Whether the browser-side validation payload contains any invalid block.
	 *
	 * @param mixed $validations Browser-side validation payload.
	 * @return bool
	 */
	private function validations_have_failures( $validations ) {
		if ( ! is_array( $validations ) || array() === $validations ) {
			return true;
		}
		foreach ( $validations as $validation ) {
			if ( ! is_array( $validation ) || true !== ( $validation['isValid'] ?? false ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Shape an item post into the response array returned by finalization abilities.
	 *
	 * @param WP_Post $item Item post.
	 * @return array<string,mixed>
	 */
	public function shape_item( WP_Post $item ) {
		$validation_errors = $this->storage->meta_array( $item->ID, Storage::META_VALIDATION_ERRORS );

		return array(
			'item_id'           => $item->ID,
			'batch_id'          => $item->post_parent,
			'target_id'         => $this->storage->meta_int( $item->ID, Storage::META_TARGET_ID ),
			'operation'         => $this->storage->meta_string( $item->ID, Storage::META_OPERATION ),
			'status'            => $this->storage->status( $item->ID ),
			'validation_errors' => $validation_errors ? $validation_errors : array(),
		);
	}

	/**
	 * Shape a batch post (and its items) into the response array returned by
	 * finalization abilities.
	 *
	 * @param WP_Post $batch Batch post.
	 * @return array<string,mixed>
	 */
	public function shape_batch( WP_Post $batch ) {
		$items = array_map( array( $this, 'shape_item' ), $this->storage->get_items( $batch->ID ) );
		return array(
			'batch_id'              => $batch->ID,
			'batch_status'          => $this->storage->status( $batch->ID ),
			'status'                => $this->storage->status( $batch->ID ),
			'label'                 => $this->storage->meta_string( $batch->ID, Storage::META_LABEL ),
			'last_error'            => $this->storage->meta_string( $batch->ID, Storage::META_LAST_ERROR ),
			'item_count'            => count( $items ),
			'items'                 => $items,
			'finalization_required' => ! in_array( $this->storage->status( $batch->ID ), Storage::TERMINAL_STATUSES, true ),
			'finalization_url'      => Finalizer_Page::url(),
		);
	}

	/**
	 * Mark a draft batch ready for finalization.
	 *
	 * @param array<string,mixed> $input Ability input.
	 * @return array<string,mixed>|WP_Error
	 */
	public function ability_enable_finalization( $input ) {
		$batch_id = isset( $input['batch_id'] ) ? (int) $input['batch_id'] : 0;
		$result   = $this->enable_finalization( $batch_id );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$result['user_instruction'] = $this->pending_changes->user_instruction( $batch_id );
		return $result;
	}

	/**
	 * Return a batch's status and its items.
	 *
	 * @param array<string,mixed> $input Ability input.
	 * @return array<string,mixed>|WP_Error
	 */
	public function ability_get_pending_batch( $input ) {
		$batch_id = isset( $input['batch_id'] ) ? (int) $input['batch_id'] : 0;
		$batch    = $this->storage->find_batch( $batch_id );
		if ( ! $batch instanceof WP_Post ) {
			return new WP_Error( 'wd_ai_batch_not_found', sprintf( 'Batch %d was not found.', $batch_id ) );
		}
		return $this->shape_batch( $batch );
	}

	/**
	 * Cancel a non-finalized batch and all its non-finalized items.
	 *
	 * @param array<string,mixed> $input Ability input.
	 * @return array<string,mixed>|WP_Error
	 */
	public function ability_delete_pending_batch( $input ) {
		$batch_id = isset( $input['batch_id'] ) ? (int) $input['batch_id'] : 0;
		return $this->cancel_batch( $batch_id );
	}

	/**
	 * Cancel a non-finalized batch and all its non-finalized items.
	 *
	 * @param int $batch_id Batch post ID.
	 * @return array<string,mixed>|WP_Error
	 */
	public function cancel_batch( $batch_id ) {
		$batch = $this->storage->find_batch( $batch_id );
		if ( ! $batch instanceof WP_Post ) {
			return new WP_Error( 'wd_ai_batch_not_found', sprintf( 'Batch %d was not found.', $batch_id ) );
		}
		if ( Storage::STATUS_FINALIZED === $this->storage->status( $batch->ID ) ) {
			return new WP_Error( 'wd_ai_batch_finalized', 'Finalized batches cannot be canceled.', array( 'status' => 409 ) );
		}

		$this->storage->set_status( $batch->ID, Storage::STATUS_CANCELED );
		foreach ( $this->storage->get_items( $batch->ID ) as $item ) {
			if ( Storage::STATUS_FINALIZED !== $this->storage->status( $item->ID ) ) {
				$this->storage->set_status( $item->ID, Storage::STATUS_CANCELED );
			}
		}

		return $this->shape_batch( $this->storage->find_batch( $batch->ID ) );
	}

	/**
	 * Register the finalization-related abilities (called from Main::init()).
	 *
	 * @return void
	 */
	public function register() {
		$id_only_schema = array(
			'type'                 => 'object',
			'properties'           => array( 'batch_id' => array( 'type' => 'integer' ) ),
			'required'             => array( 'batch_id' ),
			'additionalProperties' => false,
		);

		wp_register_ability(
			'woodmart/gutenberg-enable-finalization',
			array(
				'label'               => 'Enable WoodMart Gutenberg Finalization',
				'description'         => 'Mark a draft batch ready. Then ask the user to open the WoodMart -> Tools -> AI Block Queue page; it serializes and commits the change. Poll gutenberg-get-pending-batch until status is finalized.',
				'category'            => 'woodmart-gutenberg',
				'input_schema'        => $id_only_schema,
				'execute_callback'    => array( $this, 'ability_enable_finalization' ),
				'permission_callback' => array( Permission::class, 'callback' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array( 'idempotent' => true ),
				),
			)
		);

		wp_register_ability(
			'woodmart/gutenberg-get-pending-batch',
			array(
				'label'               => 'Get WoodMart Gutenberg Pending Batch',
				'description'         => 'Return a batch status and its items. Poll this until status is finalized, failed, or conflicted.',
				'category'            => 'woodmart-gutenberg',
				'input_schema'        => $id_only_schema,
				'execute_callback'    => array( $this, 'ability_get_pending_batch' ),
				'permission_callback' => array( Permission::class, 'callback' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array( 'readonly' => true ),
				),
			)
		);

		wp_register_ability(
			'woodmart/gutenberg-delete-pending-batch',
			array(
				'label'               => 'Delete WoodMart Gutenberg Pending Batch',
				'description'         => 'Cancel a non-finalized batch and all its non-finalized items.',
				'category'            => 'woodmart-gutenberg',
				'input_schema'        => $id_only_schema,
				'execute_callback'    => array( $this, 'ability_delete_pending_batch' ),
				'permission_callback' => array( Permission::class, 'callback' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array( 'destructive' => true ),
				),
			)
		);
	}
}
