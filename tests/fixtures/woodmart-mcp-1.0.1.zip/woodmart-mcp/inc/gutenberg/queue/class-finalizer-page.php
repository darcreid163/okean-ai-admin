<?php
/**
 * AI abilities — Block Editor Queue admin page (browser serializer).
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Gutenberg;

use XTS\Admin\Modules\Dashboard;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Registers and renders the "AI Block Queue" wp-admin page: a background page
 * that polls for ready batches and serializes them via a hidden block-editor
 * iframe (see finalizer_script()).
 */
class Finalizer_Page {
	const PAGE_SLUG = 'xts_ai_block_queue';

	/**
	 * Register the admin_menu/admin_enqueue_scripts hooks.
	 *
	 * @return void
	 */
	public function boot() {
		add_action( 'admin_menu', array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_filter( 'wp_client_side_media_processing_enabled', array( $this, 'disable_editor_client_side_media_processing' ) );
	}

	/**
	 * Keep the hidden editor accessible to its parent Queue page.
	 *
	 * WordPress 7.1 enables document isolation for client-side media processing
	 * in supported browsers. The finalizer does not process media and needs
	 * same-origin access to the hidden editor's wp.blocks runtime.
	 *
	 * @param bool $enabled Whether client-side media processing is enabled.
	 * @return bool
	 */
	public function disable_editor_client_side_media_processing( $enabled ) {
		if ( self::is_finalizer_editor_request() ) {
			return false;
		}

		return $enabled;
	}

	/**
	 * Add the "AI Block Queue" page under the WoodMart dashboard menu.
	 *
	 * @return void
	 */
	public function register_menu() {
		add_submenu_page(
			'xts_dashboard',
			esc_html__( 'AI Block Queue', 'woodmart' ),
			esc_html__( 'AI Block Queue', 'woodmart' ),
			'edit_posts',
			self::PAGE_SLUG,
			array( $this, 'render_page' ),
			11
		);
	}

	/**
	 * Whether the current admin request is for the AI Block Queue page.
	 *
	 * @return bool
	 */
	public static function is_finalizer_page() {
		return isset( $_GET['page'] ) && self::PAGE_SLUG === $_GET['page']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	/**
	 * Whether the current request is for the Queue's hidden block editor.
	 *
	 * @return bool
	 */
	public static function is_finalizer_editor_request() {
		return isset( $_GET['wd_ai_finalizer'] ) && '1' === $_GET['wd_ai_finalizer']; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
	}

	/**
	 * Enqueue the finalizer's inline script and styles on the AI Block Queue page only.
	 *
	 * @param string $hook Current admin page hook suffix (unused; required by the admin_enqueue_scripts hook signature).
	 * @return void
	 */
	public function enqueue_assets( $hook ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
		if ( ! current_user_can( 'edit_posts' ) ) {
			return;
		}
		if ( ! self::is_finalizer_page() ) {
			return;
		}

		// The page's only styles are the status indicator below, so they ship inline
		// with the page instead of a compiled `css/parts/` stylesheet.
		wp_register_style( 'wd-ai-finalizer', false, array( 'wd-admin-base' ), WOODMART_VERSION );
		wp_add_inline_style( 'wd-ai-finalizer', self::finalizer_styles() );
		wp_enqueue_style( 'wd-ai-finalizer' );

		wp_register_script(
			'wd-ai-finalizer',
			false,
			array( 'wp-api-fetch', 'wp-blocks', 'wp-block-library' ),
			WOODMART_VERSION,
			true
		);
		wp_add_inline_script(
			'wd-ai-finalizer',
			'window.wdAiFinalizer = ' . wp_json_encode( array( 'nonce' => wp_create_nonce( 'wp_rest' ) ) ) . ';',
			'before'
		);
		wp_add_inline_script( 'wd-ai-finalizer', self::finalizer_script() );
		wp_enqueue_script( 'wd-ai-finalizer' );
	}

	/**
	 * Render the AI Block Queue admin page markup (progress notice + hidden editor iframe)
	 * inside the WoodMart dashboard chrome.
	 *
	 * @return void
	 */
	public function render_page() {
		if ( ! current_user_can( 'edit_posts' ) ) {
			return;
		}

		$dashboard = Dashboard::get_instance();

		$dashboard->print_header();
		?>
		<div class="xts-box xts-theme-style" id="wd-ai-finalizer-root">
			<div class="xts-box-header">
				<h3>
					<?php esc_html_e( 'AI Block Queue', 'woodmart' ); ?>
				</h3>
			</div>

			<div class="xts-box-content">
				<p>
					<?php esc_html_e( 'This background page lets the AI serialize WoodMart blocks with the real editor. Keep this tab open while an AI editing session runs; closing it pauses finalization.', 'woodmart' ); ?>
				</p>

				<div class="wd-ai-status wd-ai-status-idle" id="wd-ai-status">
					<span class="wd-ai-status-dot"></span>
					<span class="wd-ai-status-text" id="wd-ai-progress">
						<?php esc_html_e( 'Checking for queued changes…', 'woodmart' ); ?>
					</span>
				</div>

				<div id="wd-ai-notice" class="xts-notice" hidden></div>

				<div class="wd-ai-editor-frame-wrap" aria-hidden="true">
					<iframe id="wd-ai-editor-frame" title="<?php esc_attr_e( 'WoodMart hidden block editor', 'woodmart' ); ?>" tabindex="-1" src="about:blank"></iframe>
				</div>
			</div>
		</div>
		<?php
		$dashboard->print_footer();
	}

	/**
	 * The page's inline CSS: the status row with its state-coloured pulsing dot,
	 * plus the off-screen wrapper for the hidden block-editor iframe.
	 *
	 * @return string
	 */
	public static function finalizer_styles() {
		return <<<'CSS'
.wd-ai-status {
	display: flex;
	align-items: center;
	gap: 10px;
	margin-bottom: 15px;
	padding: 12px 15px;
	border-radius: 5px;
	background-color: rgba(0, 0, 0, 0.03);
	font-weight: 600;
}
.wd-ai-status-dot {
	position: relative;
	flex: 0 0 auto;
	width: 10px;
	height: 10px;
	border-radius: 50%;
	background-color: currentColor;
}
.wd-ai-status-dot:before {
	content: "";
	position: absolute;
	inset: 0;
	border-radius: 50%;
	background-color: currentColor;
	animation: wd-ai-pulse 1.5s ease-out infinite;
}
.wd-ai-status-idle {
	color: #8a8a8a;
}
.wd-ai-status-working {
	color: #3f7bd6;
}
.wd-ai-status-done {
	color: #46a04a;
}
.wd-ai-status-error {
	color: #d64f4f;
}
.wd-ai-status-done .wd-ai-status-dot:before,
.wd-ai-status-error .wd-ai-status-dot:before {
	animation: none;
	opacity: 0;
}
.wd-ai-status-text {
	color: #333;
}
@keyframes wd-ai-pulse {
	0% {
		opacity: 0.6;
		transform: scale(1);
	}
	100% {
		opacity: 0;
		transform: scale(3);
	}
}
@media (prefers-reduced-motion: reduce) {
	.wd-ai-status-dot:before {
		animation: none;
	}
}
.wd-ai-editor-frame-wrap {
	position: absolute;
	top: 0;
	left: -10000px;
	overflow: hidden;
	width: 1280px;
	height: 900px;
	opacity: 0;
	pointer-events: none;
}
#wd-ai-editor-frame {
	width: 1280px;
	height: 900px;
	border: 0;
}
CSS;
	}

	/**
	 * Admin URL of the AI Block Queue page.
	 *
	 * @return string
	 */
	public static function url() {
		return add_query_arg( array( 'page' => self::PAGE_SLUG ), admin_url( 'admin.php' ) );
	}

	/**
	 * The inline JS that polls for ready batches and serializes them client-side
	 * using a hidden block-editor iframe (wp.blocks from the target's own edit page).
	 *
	 * @return string
	 */
	public static function finalizer_script() {
		return <<<'JS'
( function () {
	var cfg = window.wdAiFinalizer || {};
	if ( ! window.wp || ! wp.apiFetch ) { return; }
	var apiFetch = wp.apiFetch;
	apiFetch.use( apiFetch.createNonceMiddleware( cfg.nonce ) );

	var progress = document.getElementById( 'wd-ai-progress' );
	var status   = document.getElementById( 'wd-ai-status' );
	var notice   = document.getElementById( 'wd-ai-notice' );
	var frame    = document.getElementById( 'wd-ai-editor-frame' );
	var busy     = false;
	var frameUrl = '';

	var path = function ( s ) { return '/wd/v1' + s; };
	// state is one of idle, working, done, error — it drives the dot colour and pulse.
	var setProgress = function ( m, state ) {
		if ( progress ) { progress.textContent = m; }
		if ( status ) { status.className = 'wd-ai-status wd-ai-status-' + ( state || 'idle' ); }
	};
	var setNotice = function ( type, m ) {
		if ( ! notice ) { return; }
		notice.className = 'xts-notice xts-' + type;
		notice.hidden = false;
		notice.textContent = m;
	};
	var clearNotice = function () { if ( notice ) { notice.hidden = true; } };
	var sleep = function ( ms ) { return new Promise( function ( r ) { window.setTimeout( r, ms ); } ); };

	var sameOrigin = function ( url ) {
		var u = new URL( url, window.location.href );
		if ( u.origin !== window.location.origin ) { throw new Error( 'Editor URL is not same-origin.' ); }
		return u.href;
	};

	var loadFrame = function ( url ) {
		var next = sameOrigin( url );
		if ( frameUrl === next ) { return Promise.resolve(); }
		frameUrl = next;
		return new Promise( function ( resolve, reject ) {
			var done = false;
			var to = window.setTimeout( function () { if ( ! done ) { done = true; frameUrl = ''; reject( new Error( 'Editor iframe did not load.' ) ); } }, 30000 );
			frame.addEventListener( 'load', function onLoad() {
				frame.removeEventListener( 'load', onLoad );
				if ( done ) { return; }
				done = true;
				window.clearTimeout( to );
				resolve();
			} );
			frame.src = next;
		} );
	};

	var frameBlocksApi = function () {
		try {
			var w = frame.contentWindow;
			if ( ! w || ! w.wp || ! w.wp.blocks ) { return null; }
			var b = w.wp.blocks;
			var req = [ 'createBlock', 'serialize', 'parse', 'validateBlock', 'getBlockType' ];
			for ( var i = 0; i < req.length; i++ ) { if ( typeof b[ req[ i ] ] !== 'function' ) { return null; } }
			return b;
		} catch ( e ) { return null; }
	};

	var waitForBlocksApi = async function () {
		var start = Date.now();
		while ( Date.now() - start < 30000 ) {
			var b = frameBlocksApi();
			if ( b ) { return b; }
			await sleep( 100 );
		}
		throw new Error( 'Block editor JS not available in the iframe.' );
	};

	var collectNames = function ( blocks, acc ) {
		( blocks || [] ).forEach( function ( b ) {
			if ( b && b.name ) { acc[ b.name ] = true; }
			if ( b && b.innerBlocks ) { collectNames( b.innerBlocks, acc ); }
		} );
		return acc;
	};

	var waitForRegistrations = async function ( api, blocks ) {
		var names = Object.keys( collectNames( blocks, {} ) );
		var start = Date.now();
		var missing = names.filter( function ( n ) { return ! api.getBlockType( n ); } );
		while ( missing.length && Date.now() - start < 30000 ) {
			await sleep( 100 );
			missing = names.filter( function ( n ) { return ! api.getBlockType( n ); } );
		}
		if ( missing.length ) { throw new Error( 'Blocks not registered in editor: ' + missing.join( ', ' ) ); }
	};

	// Block comment uses the unprefixed name for core blocks (wp:paragraph), the
	// full name otherwise (wp:wd/button).
	var blockCommentName = function ( name ) {
		return name.indexOf( 'core/' ) === 0 ? name.slice( 5 ) : name;
	};

	// The normal block editor assigns blockVersion from the block's Edit lifecycle,
	// but the queue creates blocks directly through wp.blocks.createBlock(). Keep the
	// serialized wrapper and PHP-generated CSS on the same class-based selector.
	var normalizeBlockVersion = function ( api, name, attributes ) {
		if ( name.indexOf( 'wd/' ) !== 0 ) { return attributes; }
		if ( attributes.blockVersion && attributes.blockVersion !== '1' && attributes.blockVersion !== 1 ) {
			return attributes;
		}

		var version = '2';
		try {
			var type = api.getBlockType( name );
			var definition = type && type.attributes && type.attributes.blockVersion;
			if ( definition && definition.default && definition.default !== '1' && definition.default !== 1 ) {
				version = String( definition.default );
			}
		} catch ( e ) {}

		attributes.blockVersion = version;
		return attributes;
	};

	// Rebuild a leaf block from its saved innerHTML so html-sourced attributes
	// (RichText content like button/heading/paragraph text) are recovered by the
	// editor's own parser. Returns null on any failure so the caller can fall
	// back to createBlock.
	//
	// Crucially, after parsing we re-apply the spec's explicit attributes ON TOP
	// of the parsed ones. WP re-sources html/rich-text attributes (e.g. paragraph
	// `content`, button label) from the markup, which would otherwise override an
	// agent's explicitly-updated attribute with the stale text. Re-applying makes
	// the explicit value win while leaving sourced attributes the agent did NOT
	// touch (e.g. button href) recovered from the old markup. So an agent can edit
	// text by setting just the content attribute — no hand-written innerHTML.
	var blockFromMarkup = function ( api, spec ) {
		try {
			var name = blockCommentName( spec.name );
			var attrs = spec.attributes && Object.keys( spec.attributes ).length
				? ' ' + JSON.stringify( spec.attributes )
				: '';
			var markup = '<!-- wp:' + name + attrs + ' -->' + spec.innerHTML + '<!-- /wp:' + name + ' -->';
			var parsed = api.parse( markup );
			var block = parsed && parsed[ 0 ];
			if ( block && block.name === spec.name && block.isValid !== false ) {
				if ( spec.attributes && typeof spec.attributes === 'object' ) {
					block.attributes = Object.assign( {}, block.attributes, spec.attributes );
				}
				block.attributes = normalizeBlockVersion( api, spec.name, block.attributes || {} );
				return block;
			}
		} catch ( e ) {}
		return null;
	};

	// Names of attributes the block sources from its saved markup (html, rich-text,
	// attribute, text, query) rather than the delimiter JSON. When an agent leaves
	// these untouched they are NOT in spec.attributes, so they must be recovered
	// from the markup or they reset to defaults on rebuild.
	var sourcedAttrNames = function ( api, name ) {
		try {
			var type = api.getBlockType( name );
			var out = [];
			if ( type && type.attributes ) {
				Object.keys( type.attributes ).forEach( function ( k ) {
					if ( type.attributes[ k ] && type.attributes[ k ].source ) { out.push( k ); }
				} );
			}
			return out;
		} catch ( e ) { return []; }
	};

	// Parse a block's wrapper markup to recover its html-sourced attributes. Unlike
	// blockFromMarkup this ignores validity — a container's wrapper markup alone is
	// "invalid" because the inner blocks are absent; we only want the attributes.
	var recoverAttributes = function ( api, spec ) {
		try {
			var name = blockCommentName( spec.name );
			var attrs = spec.attributes && Object.keys( spec.attributes ).length
				? ' ' + JSON.stringify( spec.attributes )
				: '';
			var markup = '<!-- wp:' + name + attrs + ' -->' + spec.innerHTML + '<!-- /wp:' + name + ' -->';
			var parsed = api.parse( markup );
			var block = parsed && parsed[ 0 ];
			if ( block && block.name === spec.name && block.attributes ) { return block.attributes; }
		} catch ( e ) {}
		return null;
	};

	var toBlock = function ( api, spec ) {
		var inner = ( spec.innerBlocks || [] ).map( function ( s ) { return toBlock( api, s ); } );
		var hasMarkup = typeof spec.innerHTML === 'string' && spec.innerHTML.trim() !== '';

		// Leaf with saved markup: rebuild from markup (recovers html-sourced text and
		// yields a valid save output). Authored leaves (no innerHTML) fall through.
		if ( inner.length === 0 && hasMarkup ) {
			var rebuilt = blockFromMarkup( api, spec );
			if ( rebuilt ) { return rebuilt; }
		}

		// Otherwise build via createBlock, recovering any html-sourced attribute the
		// agent did NOT set (e.g. wd/accordion-pane `title` lives in a nested span,
		// not the delimiter, and would reset to default on an untouched round-trip).
		var attributes = Object.assign( {}, spec.attributes || {} );
		if ( hasMarkup ) {
			var sourced = sourcedAttrNames( api, spec.name );
			if ( sourced.length ) {
				var recovered = recoverAttributes( api, spec );
				if ( recovered ) {
					sourced.forEach( function ( k ) {
						if ( ! ( spec.attributes && k in spec.attributes ) && k in recovered ) {
							attributes[ k ] = recovered[ k ];
						}
					} );
				}
			}
		}
		attributes = normalizeBlockVersion( api, spec.name, attributes );
		return api.createBlock( spec.name, attributes, inner );
	};

	var validate = function ( api, blocks, prefix, out ) {
		( blocks || [] ).forEach( function ( block, i ) {
			var p = prefix === '' ? String( i ) : prefix + '.' + i;
			var res;
			try { res = api.validateBlock( block ); } catch ( e ) { res = [ false, [ { message: e.message || String( e ) } ] ]; }
			var ok = Array.isArray( res ) ? res[ 0 ] === true : res === true;
			out.push( { name: block.name || '', path: p, isValid: ok } );
			if ( block.innerBlocks && block.innerBlocks.length ) { validate( api, block.innerBlocks, p, out ); }
		} );
		return out;
	};

	var serializeJob = async function ( job ) {
		var blocks = job.blocks || [];
		await loadFrame( job.editor_url || '' );
		var api = await waitForBlocksApi();
		await waitForRegistrations( api, blocks );
		var created = blocks.map( function ( s ) { return toBlock( api, s ); } );
		var content = api.serialize( created );
		var parsed = api.parse( content );
		var validations = validate( api, parsed, '', [] );
		var errors = validations.filter( function ( v ) { return ! v.isValid; } );
		return { content: content, validations: validations, errors: errors };
	};

	var processBatch = async function ( batchId ) {
		var claim = await apiFetch( { path: path( '/gb-queue/batches/' + batchId + '/claim' ), method: 'POST' } );
		var items = claim.items || [];
		for ( var i = 0; i < items.length; i++ ) {
			var item = items[ i ];
			setProgress( 'Serializing change ' + ( i + 1 ) + ' of ' + items.length + '…', 'working' );
			var job = await apiFetch( { path: path( '/gb-queue/items/' + item.item_id + '/spec' ), method: 'GET' } );
			try {
				var result = await serializeJob( job );
				if ( result.errors.length ) {
					await apiFetch( { path: path( '/gb-queue/items/' + item.item_id + '/fail' ), method: 'POST', data: { errors: result.errors, message: 'JS validation failed.' } } );
					setProgress( 'Stopped: a block failed validation.', 'error' );
					setNotice( 'error', 'A block failed validation. Return to the agent.' );
					return;
				}
				await apiFetch( { path: path( '/gb-queue/items/' + item.item_id + '/complete' ), method: 'POST', data: { content: result.content, validations: result.validations } } );
			} catch ( e ) {
				await apiFetch( { path: path( '/gb-queue/items/' + item.item_id + '/fail' ), method: 'POST', data: { errors: [ { message: e.message || String( e ) } ], message: 'Serializer exception.' } } );
				setProgress( 'Stopped: serializer error.', 'error' );
				setNotice( 'error', 'Serializer error: ' + ( e.message || e ) + '. Return to the agent.' );
				return;
			}
		}
		clearNotice();
		setProgress( 'Done. The queue is up to date.', 'done' );
	};

	var tick = async function () {
		if ( busy ) { return; }
		busy = true;
		try {
			var res = await apiFetch( { path: path( '/gb-queue/batches?status=ready,failed' ), method: 'GET' } );
			var batch = ( res.batches || [] ).find( function ( b ) { return b.status === 'ready' || b.status === 'failed'; } );
			if ( ! batch ) { setProgress( 'Nothing to do. Waiting for queued changes…', 'idle' ); return; }
			clearNotice();
			setProgress( 'Working on queued changes…', 'working' );
			await processBatch( batch.batch_id );
		} catch ( e ) {
			setProgress( 'Queue disconnected.', 'error' );
			setNotice( 'error', 'Queue disconnected. Reload this page.' );
		} finally {
			busy = false;
		}
	};

	window.setTimeout( tick, 250 );
	window.setInterval( tick, 5000 );
}() );
JS;
	}
}
