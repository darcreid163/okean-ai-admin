<?php
/**
 * AI ability — read a target's Gutenberg block tree.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Gutenberg;

use WP_Error;
use WP_Post;
use XTS\AI_Abilities\Permission;
use XTS\AI_Abilities\Support;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ability handler that reads a target's Gutenberg block tree.
 */
class Reader {
	/**
	 * Read a target's block tree.
	 *
	 * @param array<string,mixed> $input Ability input.
	 * @return array<string,mixed>|WP_Error
	 */
	public function ability_get_content( $input ) {
		$target_id = Support::resolve_target_id( $input );
		$target    = get_post( $target_id );
		if ( ! $target instanceof WP_Post ) {
			return new WP_Error( 'wd_ai_target_not_found', sprintf( 'Target post %d was not found.', $target_id ) );
		}

		$parsed = parse_blocks( $target->post_content );
		$blocks = array();
		foreach ( $parsed as $block ) {
			// Blocks with a null name are either whitespace between blocks, or
			// non-block content (e.g. leftover classic-editor/freeform HTML) that
			// has no block_spec representation — see include_raw_content below.
			if ( empty( $block['blockName'] ) ) {
				continue;
			}
			$blocks[] = Block_Editor::parsed_block_to_spec( $block );
		}

		$response = array(
			'target_id'    => $target->ID,
			'title'        => $target->post_title,
			'content_hash' => Storage::content_hash( $target->post_content ),
			'block_spec'   => $blocks,
		);

		// Optional full raw post_content for the agent's reference (can be large).
		if ( ! empty( $input['include_raw_content'] ) ) {
			$response['raw_content'] = $target->post_content;
		}

		return $response;
	}

	/**
	 * Register the woodmart/gutenberg-get-content ability.
	 */
	public function register() {
		wp_register_ability(
			'woodmart/gutenberg-get-content',
			array(
				'label'               => 'Get WoodMart Gutenberg Content',
				'description'         => 'Read a post/page block tree as {name, attributes, innerHTML, innerBlocks} plus a content_hash for conflict detection. Pass include_raw_content=true only when the full live post_content is needed.',
				'category'            => 'woodmart-gutenberg',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array_merge(
						Support::target_id_properties(),
						array(
							'include_raw_content' => array(
								'type'        => 'boolean',
								'default'     => false,
								'description' => 'Also return the full raw post_content string. block_spec omits content that is not inside a registered block (e.g. leftover classic-editor/freeform HTML) — set this to true and inspect raw_content before a replace-content change on a target that might have such content, so it is not silently dropped. Not needed for a normal block-only page. Can be large.',
							),
						)
					),
					'required'             => array( 'target_id' ),
					'additionalProperties' => false,
				),
				'execute_callback'    => array( $this, 'ability_get_content' ),
				'permission_callback' => array( Permission::class, 'callback' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
				),
			)
		);
	}
}
