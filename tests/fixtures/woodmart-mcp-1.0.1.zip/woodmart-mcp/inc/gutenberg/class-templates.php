<?php
/**
 * AI abilities — WoodMart's demo template library (search + get).
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Gutenberg;

use WP_Error;
use XTS\AI_Abilities\Permission;
use XTS\AI_Abilities\Gutenberg\Template_Library\Client;
use XTS\AI_Abilities\Gutenberg\Template_Library\Markup_Converter;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ability handlers for searching and fetching WoodMart's demo template library.
 */
class Templates {

	/**
	 * Template-library catalog client.
	 *
	 * @var Client
	 */
	private $client;

	/**
	 * Constructor.
	 *
	 * @param Client $client Template-library catalog client.
	 */
	public function __construct( Client $client ) {
		$this->client = $client;
	}

	/**
	 * Search the demo template library by title and/or tag.
	 *
	 * @param array<string,mixed> $input Ability input.
	 * @return array<string,mixed>|WP_Error
	 */
	public function ability_search_templates( $input ) {
		$input   = (array) $input;
		$catalog = $this->client->fetch_catalog();
		if ( is_wp_error( $catalog ) ) {
			return $catalog;
		}

		$search = isset( $input['search'] ) ? strtolower( trim( (string) $input['search'] ) ) : '';
		$tag    = isset( $input['tag'] ) ? strtolower( trim( (string) $input['tag'] ) ) : '';

		$templates = array();
		foreach ( $catalog['elements'] as $element ) {
			$raw_tags = preg_split( '/\s+/', trim( (string) ( $element['class'] ?? '' ) ), -1, PREG_SPLIT_NO_EMPTY );
			// The demo server's per-template classes are prefixed (e.g. "tag-hero-section"),
			// but available_tags below lists unprefixed slugs (e.g. "hero-section"). Strip the
			// prefix so a tag param matching available_tags actually filters, and so the
			// per-template tags field returned here is consistent with available_tags.
			$tags = array_map(
				static function ( $raw_tag ) {
					return 0 === strpos( $raw_tag, 'tag-' ) ? substr( $raw_tag, 4 ) : $raw_tag;
				},
				$raw_tags
			);

			if ( '' !== $tag && ! in_array( $tag, array_map( 'strtolower', $tags ), true ) ) {
				continue;
			}
			if ( '' !== $search && false === strpos( strtolower( (string) ( $element['title'] ?? '' ) ), $search ) ) {
				continue;
			}

			$templates[] = array(
				'id'            => isset( $element['id'] ) ? (int) $element['id'] : 0,
				'title'         => isset( $element['title'] ) ? (string) $element['title'] : '',
				'tags'          => $tags,
				'preview_image' => isset( $element['image'] ) ? (string) $element['image'] : '',
				'preview_url'   => isset( $element['link'] ) ? (string) $element['link'] : '',
			);
		}

		return array(
			'count'          => count( $templates ),
			'templates'      => $templates,
			'available_tags' => $catalog['tags'],
			'hint'           => 'Use gutenberg-get-template with a template_id to get its block_spec, ready for gutenberg-add-pending-change or gutenberg-edit-blocks.',
		);
	}

	/**
	 * Fetch one template's block_spec by id.
	 *
	 * @param array<string,mixed> $input Ability input.
	 * @return array<string,mixed>|WP_Error
	 */
	public function ability_get_template( $input ) {
		$template_id = isset( $input['template_id'] ) ? (int) $input['template_id'] : 0;
		if ( $template_id <= 0 ) {
			return new WP_Error( 'wd_ai_invalid_input', 'template_id must be a positive integer.' );
		}

		$result = \XTS\Gutenberg\Template_Library::get_instance()->fetch_template_markup( $template_id );

		if ( empty( $result['success'] ) ) {
			$message = isset( $result['message'] ) ? $result['message'] : sprintf( 'Template %d was not found.', $template_id );
			if ( is_wp_error( $message ) ) {
				return $message;
			}
			return new WP_Error( 'wd_ai_template_not_found', (string) $message );
		}

		$markup = (string) $result['template'];

		return array(
			'id'         => $template_id,
			'title'      => $this->find_cached_title( $template_id ),
			'block_spec' => Markup_Converter::markup_to_block_spec( $markup ),
			'raw_markup' => $markup,
		);
	}

	/*
	 * Note: block_spec/raw_markup above still reference the original demo-server
	 * image URLs (e.g. bgImage.url on woodmart.xtemos.com) — this ability does not
	 * sideload images, so it stays fast and isn't at risk of a client-side (MCP)
	 * timeout on templates with several images. Images are localized later, at
	 * finalize time, by localize_item_remote_images() in runtime.php (driven by
	 * the AI Block Queue browser page, which has no such timeout constraint).
	 */

	/**
	 * Best-effort title lookup from the client's cached catalog. No remote
	 * call: returns null if the catalog isn't cached or doesn't contain this id.
	 *
	 * @param int $template_id Template id.
	 * @return string|null
	 */
	private function find_cached_title( $template_id ) {
		$catalog = $this->client->cached_catalog();
		if ( null === $catalog || ! isset( $catalog['elements'] ) ) {
			return null;
		}
		foreach ( $catalog['elements'] as $element ) {
			if ( isset( $element['id'] ) && (int) $element['id'] === $template_id ) {
				return isset( $element['title'] ) ? (string) $element['title'] : null;
			}
		}
		return null;
	}

	/**
	 * Register the woodmart/gutenberg-search-templates and woodmart/gutenberg-get-template abilities.
	 */
	public function register() {
		wp_register_ability(
			'woodmart/gutenberg-search-templates',
			array(
				'label'               => 'Search WoodMart Template Library',
				'description'         => 'Search WoodMart\'s demo template library for pre-built Gutenberg sections/pages by title and/or tag. Returns compact matches; use gutenberg-get-template on a result\'s id to get its block_spec for insertion.',
				'category'            => 'woodmart-gutenberg',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'search' => array(
							'type'        => 'string',
							'description' => 'Substring match on template title.',
						),
						'tag'    => array(
							'type'        => 'string',
							'description' => 'Filter to templates carrying this tag slug (see available_tags in the response).',
						),
					),
					'additionalProperties' => false,
				),
				'execute_callback'    => array( $this, 'ability_search_templates' ),
				'permission_callback' => array( Permission::class, 'callback' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);

		wp_register_ability(
			'woodmart/gutenberg-get-template',
			array(
				'label'               => 'Get WoodMart Template',
				'description'         => 'Fetch one template from WoodMart\'s demo template library by id (see gutenberg-search-templates). Returns a block_spec ready to pass into gutenberg-add-pending-change (block_spec) or gutenberg-edit-blocks (an insert op\'s block), plus the original raw_markup for reference. Fast and read-only: image URLs still point at the demo server at this point. They are localized into your media library automatically later, when the queued change is finalized through the AI Block Queue page — no extra step needed.',
				'category'            => 'woodmart-gutenberg',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'template_id' => array(
							'type'        => 'integer',
							'description' => 'Template id from gutenberg-search-templates.',
						),
					),
					'required'             => array( 'template_id' ),
					'additionalProperties' => false,
				),
				'execute_callback'    => array( $this, 'ability_get_template' ),
				'permission_callback' => array( Permission::class, 'callback' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);
	}
}
