<?php
/**
 * AI ability — replace the logo image in every Header Builder header.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Headers;

use WP_Error;
use XTS\AI_Abilities\Permission;
use XTS\Modules\Header_Builder;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Ability handler that swaps the logo image across every saved header.
 *
 * The logo lives inside each header's structure tree, in the params of every
 * element of type "logo" — not in theme options and not in post content — so no
 * other ability can reach it. A header commonly holds more than one logo element.
 */
class Header_Logo {

	/**
	 * Replace the logo image in every logo element of every saved header.
	 *
	 * @param array<string,mixed> $input Ability input.
	 * @return array<string,mixed>|WP_Error
	 */
	public function ability_replace_header_logo( $input ) {
		$attachment_id = isset( $input['attachment_id'] ) ? (int) $input['attachment_id'] : 0;

		$image = $this->image_value( $attachment_id );
		if ( is_wp_error( $image ) ) {
			return $image;
		}

		$builder = Header_Builder::get_instance();
		$report  = array();
		$totals  = array(
			'headers_updated'       => 0,
			'logo_elements_updated' => 0,
		);

		foreach ( $builder->list->get_all() as $meta ) {
			$id = isset( $meta['id'] ) ? (string) $meta['id'] : '';

			if ( '' === $id ) {
				continue;
			}

			$name = isset( $meta['name'] ) ? (string) $meta['name'] : $id;

			// A header with no saved option renders from the theme config. Materializing
			// it here would freeze it in the DB and stop it tracking config changes on
			// theme updates, so report it instead and let the user save it once.
			if ( false === get_option( 'whb_' . $id, false ) ) {
				$report[] = array(
					'id'     => $id,
					'name'   => $name,
					'status' => 'skipped',
					'reason' => sprintf( 'No saved data (option whb_%s does not exist); this header renders from the theme config. Open it in the Header Builder and save it once to make it editable.', $id ),
				);
				continue;
			}

			$header = $builder->factory->get_header( $id );
			$raw    = $header->get_raw_data();

			$structure = ( isset( $raw['structure'] ) && is_array( $raw['structure'] ) ) ? $raw['structure'] : array();
			$settings  = ( isset( $raw['settings'] ) && is_array( $raw['settings'] ) ) ? $raw['settings'] : array();

			$counts = array(
				'logos'  => 0,
				'sticky' => 0,
			);

			$structure = $this->replace_in_node( $structure, $image, $counts );

			if ( 0 === $counts['logos'] ) {
				$report[] = array(
					'id'     => $id,
					'name'   => $name,
					'status' => 'unchanged',
					'reason' => 'This header contains no logo element.',
				);
				continue;
			}

			$builder->factory->update_header( $id, $name, $structure, $settings );

			// update_header()/Header::save() return nothing, so confirm the write landed
			// by reading the option back rather than assuming success.
			if ( ! $this->logo_url_persisted( $id, $image['url'] ) ) {
				$report[] = array(
					'id'     => $id,
					'name'   => $name,
					'status' => 'failed',
					'reason' => 'The header was saved but the new logo URL is not present in the stored option.',
				);
				continue;
			}

			$report[] = array(
				'id'             => $id,
				'name'           => $name,
				'status'         => 'updated',
				'logos_updated'  => $counts['logos'],
				'sticky_updated' => $counts['sticky'],
			);

			++$totals['headers_updated'];
			$totals['logo_elements_updated'] += $counts['logos'];
		}

		return array(
			'attachment' => $image,
			'headers'    => $report,
			'totals'     => $totals,
		);
	}

	/**
	 * Resolve an attachment into the value shape the Header Builder stores.
	 *
	 * @param int $attachment_id Media library attachment ID.
	 * @return array<string,mixed>|WP_Error Image value with id, url, width, height.
	 */
	private function image_value( $attachment_id ) {
		if ( $attachment_id <= 0 ) {
			return new WP_Error( 'wd_ai_invalid_attachment', 'attachment_id is required and must be a positive integer.' );
		}

		if ( ! wp_attachment_is_image( $attachment_id ) ) {
			return new WP_Error(
				'wd_ai_invalid_attachment',
				sprintf( 'Attachment %d does not exist or is not an image.', $attachment_id )
			);
		}

		$src = wp_get_attachment_image_src( $attachment_id, 'full' );

		if ( ! $src || empty( $src[0] ) ) {
			return new WP_Error(
				'wd_ai_invalid_attachment',
				sprintf( 'Could not resolve a URL for attachment %d.', $attachment_id )
			);
		}

		return array(
			'id'     => $attachment_id,
			'url'    => (string) $src[0],
			'width'  => isset( $src[1] ) ? (int) $src[1] : 0,
			'height' => isset( $src[2] ) ? (int) $src[2] : 0,
		);
	}

	/**
	 * Walk a structure node, replacing the image of every logo element beneath it.
	 *
	 * Logo elements sit at an arbitrary depth of nested "content" arrays, and a header
	 * usually has several of them.
	 *
	 * @param mixed               $node   Structure node (array or scalar).
	 * @param array<string,mixed> $image  Replacement image value.
	 * @param array<string,int>   $counts Running counts, by reference: logos, sticky.
	 * @return mixed The node with logo images replaced.
	 */
	private function replace_in_node( $node, $image, &$counts ) {
		if ( ! is_array( $node ) ) {
			return $node;
		}

		// A logo element has no child elements, so replace its params and stop here.
		if ( isset( $node['type'] ) && 'logo' === $node['type'] ) {
			if ( isset( $node['params'] ) && is_array( $node['params'] ) ) {
				$node['params'] = $this->replace_params( $node['params'], $image, $counts );
			}

			return $node;
		}

		foreach ( $node as $key => $value ) {
			if ( is_array( $value ) ) {
				$node[ $key ] = $this->replace_in_node( $value, $image, $counts );
			}
		}

		return $node;
	}

	/**
	 * Replace the image params of a single logo element.
	 *
	 * The sticky_image param is only replaced when it already holds an image. An empty
	 * sticky image means "reuse the main logo", and header-elements/logo.php only adds
	 * the wd-switch-logo behaviour when a sticky image exists — filling an empty one
	 * would silently enable scroll logo-swapping on a header whose designer never wanted
	 * it. Empty stickies pick up the new logo for free. Sizes are a design decision and
	 * are never touched.
	 *
	 * @param array<string,mixed> $params Logo element params.
	 * @param array<string,mixed> $image  Replacement image value.
	 * @param array<string,int>   $counts Running counts, by reference: logos, sticky.
	 * @return array<string,mixed>
	 */
	private function replace_params( $params, $image, &$counts ) {
		if ( isset( $params['image'] ) && is_array( $params['image'] ) ) {
			$params['image']['value'] = $image;
			++$counts['logos'];
		}

		$has_sticky = isset( $params['sticky_image']['value'] )
			&& is_array( $params['sticky_image']['value'] )
			&& ! empty( $params['sticky_image']['value']['url'] );

		if ( $has_sticky ) {
			$params['sticky_image']['value'] = $image;
			++$counts['sticky'];
		}

		return $params;
	}

	/**
	 * Confirm every logo in the saved header option now carries the new URL.
	 *
	 * Walks the stored structure rather than string-matching its JSON: wp_json_encode()
	 * escapes forward slashes by default, so searching an encoded tree for a raw URL
	 * never matches and would report a perfectly good write as a failure.
	 *
	 * @param string $id  Header ID.
	 * @param string $url Expected logo URL.
	 * @return bool True when at least one logo is stored and all of them carry $url.
	 */
	private function logo_url_persisted( $id, $url ) {
		$saved = get_option( 'whb_' . $id, false );

		if ( ! is_array( $saved ) || ! isset( $saved['structure'] ) ) {
			return false;
		}

		$stored = $this->collect_logo_urls( $saved['structure'] );

		if ( array() === $stored ) {
			return false;
		}

		return array( $url ) === array_values( array_unique( $stored ) );
	}

	/**
	 * Collect the main-logo URL of every logo element in a structure tree.
	 *
	 * @param mixed $node Structure node (array or scalar).
	 * @return array<int,string>
	 */
	private function collect_logo_urls( $node ) {
		if ( ! is_array( $node ) ) {
			return array();
		}

		if ( isset( $node['type'] ) && 'logo' === $node['type'] ) {
			return isset( $node['params']['image']['value']['url'] )
				? array( (string) $node['params']['image']['value']['url'] )
				: array();
		}

		$urls = array();

		foreach ( $node as $value ) {
			if ( is_array( $value ) ) {
				$urls = array_merge( $urls, $this->collect_logo_urls( $value ) );
			}
		}

		return $urls;
	}

	/**
	 * Register the woodmart/replace-header-logo ability.
	 *
	 * @return void
	 */
	public function register() {
		wp_register_ability(
			'woodmart/replace-header-logo',
			array(
				'label'               => 'Replace Header Logo',
				'description'         => 'Replace the logo image in every logo element of every saved Header Builder header. A header often holds more than one logo element, and a site often has several headers; this covers all of them in one call. Applies immediately — not queued, and it does not need the AI Block Queue page. Pass a media-library attachment_id (resolve one first; this ability never downloads a remote image). Headers with no saved data (typically the default header, which renders from the theme config) are skipped and reported. The sticky-header logo is only replaced where one is already set; an empty sticky logo already reuses the main one.',
				'category'            => 'woodmart-theme',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'attachment_id' => array(
							'type'        => 'integer',
							'description' => 'Media library attachment ID of the new logo image.',
						),
					),
					'required'             => array( 'attachment_id' ),
					'additionalProperties' => false,
				),
				'execute_callback'    => array( $this, 'ability_replace_header_logo' ),
				'permission_callback' => array( Permission::class, 'manage_theme' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => true,
					),
				),
			)
		);
	}
}
