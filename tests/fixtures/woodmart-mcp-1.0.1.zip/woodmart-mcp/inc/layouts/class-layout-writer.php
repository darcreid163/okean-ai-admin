<?php
/**
 * AI abilities — create WoodMart layouts and set their assignment conditions.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Layouts;

use WP_Error;
use WP_Post;
use XTS\AI_Abilities\Gutenberg\Block_Normalizer;
use XTS\AI_Abilities\Gutenberg\Finalization;
use XTS\AI_Abilities\Gutenberg\Finalizer_Page;
use XTS\AI_Abilities\Gutenberg\Pending_Changes;
use XTS\AI_Abilities\Gutenberg\Storage;
use XTS\AI_Abilities\Permission;
use XTS\Modules\Layouts\Import;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Write ability handlers for the woodmart_layout CPT.
 */
class Layout_Writer {
	const POST_TYPE = 'woodmart_layout';

	/**
	 * Allowed statuses for a new layout.
	 *
	 * @var array<int,string>
	 */
	private const STATUSES = array( 'draft', 'publish' );

	/**
	 * Queue storage service.
	 *
	 * @var Storage
	 */
	private $storage;

	/**
	 * Conditions service.
	 *
	 * @var Conditions
	 */
	private $conditions;

	/**
	 * Pending-changes handler.
	 *
	 * @var Pending_Changes
	 */
	private $pending_changes;

	/**
	 * Finalization runtime.
	 *
	 * @var Finalization
	 */
	private $finalization;

	/**
	 * Constructor.
	 *
	 * @param Storage         $storage         Queue storage service.
	 * @param Conditions      $conditions      Conditions service.
	 * @param Pending_Changes $pending_changes Pending-changes handler.
	 * @param Finalization    $finalization    Finalization runtime.
	 */
	public function __construct( Storage $storage, Conditions $conditions, Pending_Changes $pending_changes, Finalization $finalization ) {
		$this->storage         = $storage;
		$this->conditions      = $conditions;
		$this->pending_changes = $pending_changes;
		$this->finalization    = $finalization;
	}

	/**
	 * Execute callback for woodmart/create-layout.
	 *
	 * @param array<string,mixed> $input Ability input.
	 * @return array<string,mixed>|WP_Error
	 */
	public function ability_create_layout( $input ) {
		$type = isset( $input['type'] ) ? sanitize_key( (string) $input['type'] ) : '';
		if ( ! Layout_Types::is_valid( $type ) ) {
			return new WP_Error( 'wd_ai_invalid_layout_type', sprintf( 'type must be one of: %s.', implode( ', ', Layout_Types::enum() ) ) );
		}

		$title = isset( $input['title'] ) ? trim( (string) $input['title'] ) : '';
		if ( '' === $title ) {
			return new WP_Error( 'wd_ai_missing_title', 'title is required.' );
		}

		$status = isset( $input['status'] ) ? sanitize_key( (string) $input['status'] ) : 'draft';
		if ( ! in_array( $status, self::STATUSES, true ) ) {
			return new WP_Error( 'wd_ai_invalid_status', sprintf( 'status must be one of: %s.', implode( ', ', self::STATUSES ) ) );
		}

		$prerequisite = $this->prerequisite_error( $type );
		if ( is_wp_error( $prerequisite ) ) {
			return $prerequisite;
		}

		// Validate conditions up front so a bad value fails before any post is created.
		$conditions = array();
		if ( isset( $input['conditions'] ) ) {
			$conditions = $this->conditions->validate( $input['conditions'], $type );
			if ( is_wp_error( $conditions ) ) {
				return $conditions;
			}
		}

		$predefined = isset( $input['predefined_name'] ) ? sanitize_file_name( (string) $input['predefined_name'] ) : '';
		if ( '' !== $predefined && ! in_array( $predefined, Layout_Types::predefined_for( $type ), true ) ) {
			return new WP_Error( 'wd_ai_invalid_predefined', sprintf( 'predefined_name "%s" is not available for type "%s".', $predefined, $type ) );
		}

		if ( '' !== $predefined ) {
			// Import::import_xml() runs WoodMart's WXR importer, which expects the
			// admin filesystem + media-sideload APIs. wp-admin loads these
			// automatically, but a REST/ability request does not, so the importer's
			// WP_Filesystem() / image-sideload calls would fatally fail. Load them.
			if ( ! function_exists( 'WP_Filesystem' ) ) {
				require_once ABSPATH . 'wp-admin/includes/file.php';
			}
			if ( ! function_exists( 'post_exists' ) ) {
				require_once ABSPATH . 'wp-admin/includes/post.php';
			}
			if ( ! function_exists( 'media_sideload_image' ) ) {
				require_once ABSPATH . 'wp-admin/includes/media.php';
			}
			if ( ! function_exists( 'wp_generate_attachment_metadata' ) ) {
				require_once ABSPATH . 'wp-admin/includes/image.php';
			}

			$post_id = Import::import_xml( $type, $predefined );
			if ( ! $post_id ) {
				return new WP_Error( 'wd_ai_import_failed', 'Failed to import the predefined layout.' );
			}
			wp_update_post(
				array(
					'ID'          => $post_id,
					'post_title'  => sanitize_text_field( $title ),
					'post_status' => $status,
				)
			);
		} else {
			$post_id = wp_insert_post(
				array(
					'post_title'  => sanitize_text_field( $title ),
					'post_type'   => self::POST_TYPE,
					'post_status' => $status,
				),
				true
			);
			if ( is_wp_error( $post_id ) ) {
				return $post_id;
			}
		}

		$this->storage->set_meta( $post_id, 'wd_layout_type', $type );

		if ( 'product_loop_item' === $type && '' !== $predefined ) {
			$this->storage->set_meta( $post_id, 'wd_force_block_id', true );
		}

		// Always replace imported conditions. Predefined XML files contain their
		// own assignment meta, but create-layout treats omitted or empty conditions
		// as an intentionally unassigned layout.
		$this->conditions->set( $post_id, $conditions );

		$response = array(
			'id'        => $post_id,
			'type'      => $type,
			'status'    => $status,
			'edit_url'  => get_edit_post_link( $post_id, 'raw' ),
			'target_id' => $post_id,
		);

		// block_spec is only used for an empty (non-predefined) layout; a predefined
		// layout already ships content, so block_spec is ignored there.
		if ( '' === $predefined && isset( $input['block_spec'] ) ) {
			$blocks = Block_Normalizer::normalize_blocks( $input['block_spec'] );
			if ( is_wp_error( $blocks ) ) {
				return $blocks;
			}

			$target = get_post( $post_id );
			$queued = $this->pending_changes->queue_replace_content( $target, $blocks, 0, $title, ! empty( $input['allow_raw_html'] ) );
			if ( is_wp_error( $queued ) ) {
				return $queued;
			}

			$enabled = $this->finalization->enable_finalization( $queued['batch_id'] );
			if ( is_wp_error( $enabled ) ) {
				return $enabled;
			}

			$queued['batch_status']          = $enabled['batch_status'];
			$queued['finalization_required'] = $enabled['finalization_required'];
			$queued['user_instruction']      = sprintf(
				'Layout content queued and marked ready in batch #%d. Ask the user to open the WoodMart -> Tools -> AI Block Queue page (%s) and keep it open; it finalizes automatically. The layout is not live with this content until the batch status is "finalized".',
				$queued['batch_id'],
				Finalizer_Page::url()
			);

			$response = array_merge( $response, $queued );
		}

		return $response;
	}

	/**
	 * Execute callback for woodmart/set-layout-conditions.
	 *
	 * @param array<string,mixed> $input Ability input.
	 * @return array<string,mixed>|WP_Error
	 */
	public function ability_set_conditions( $input ) {
		$layout_id = isset( $input['layout_id'] ) ? (int) $input['layout_id'] : 0;
		$layout    = get_post( $layout_id );

		if ( ! $layout instanceof WP_Post || self::POST_TYPE !== $layout->post_type ) {
			return new WP_Error( 'wd_ai_layout_not_found', sprintf( 'Layout %d was not found.', $layout_id ) );
		}

		if ( ! isset( $input['conditions'] ) ) {
			return new WP_Error( 'wd_ai_missing_conditions', 'conditions is required.' );
		}

		$type = $this->storage->meta_string( $layout_id, 'wd_layout_type' );
		if ( ! Layout_Types::is_valid( $type ) ) {
			return new WP_Error( 'wd_ai_invalid_layout_type', sprintf( 'Layout %d does not have a valid layout type.', $layout_id ) );
		}
		$conditions = $this->conditions->validate( $input['conditions'], $type );
		if ( is_wp_error( $conditions ) ) {
			return $conditions;
		}

		$old = $this->conditions->get( $layout_id );
		$this->conditions->set( $layout_id, $conditions );

		$assigned_id = $type ? (int) \XTS\Modules\Layouts\Main::get_instance()->get_layout_id( $type ) : 0;

		return array(
			'layout_id'      => $layout_id,
			'old_conditions' => $old,
			'new_conditions' => $conditions,
			'is_assigned'    => $assigned_id === $layout_id,
		);
	}

	/**
	 * Guard that a type's preview prerequisite (published product/post/portfolio) is met.
	 *
	 * @param string $type Layout type id.
	 * @return WP_Error|null
	 */
	private function prerequisite_error( $type ) {
		$needs = Layout_Types::preview_prerequisite( $type );
		if ( null === $needs ) {
			return null;
		}

		$found = get_posts(
			array(
				'post_type'      => $needs,
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'no_found_rows'  => true,
			)
		);

		if ( empty( $found ) ) {
			return new WP_Error( 'wd_ai_missing_prerequisite', sprintf( 'Layout type "%1$s" needs at least one published %2$s before it can be created.', $type, $needs ) );
		}

		return null;
	}

	/**
	 * Register the write abilities.
	 *
	 * @return void
	 */
	public function register() {
		wp_register_ability(
			'woodmart/create-layout',
			array(
				'label'               => 'Create WoodMart Layout',
				'description'         => 'Create a woodmart_layout template of a given type. Omit predefined_name and block_spec for an empty layout; pass predefined_name (from list-layout-types) to import a ready template; or pass block_spec to queue authored blocks (finalize via the AI Block Queue page). Optionally pass conditions to target it. predefined_name wins over block_spec.',
				'category'            => 'woodmart-layouts',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'type'            => array(
							'type'        => 'string',
							'enum'        => Layout_Types::enum(),
							'description' => 'Layout type id (see list-layout-types).',
						),
						'title'           => array(
							'type'        => 'string',
							'description' => 'Layout title.',
						),
						'status'          => array(
							'type'        => 'string',
							'enum'        => self::STATUSES,
							'default'     => 'draft',
							'description' => 'Post status. Defaults to draft.',
						),
						'predefined_name' => array(
							'type'        => 'string',
							'description' => 'Optional predefined template directory name for this type (see list-layout-types.predefined). Wins over block_spec.',
						),
						'block_spec'      => array(
							'type'        => 'array',
							'description' => 'Optional authored block tree [{name, attributes, innerBlocks}] for an empty layout. Ignored when predefined_name is set.',
							'items'       => array( 'type' => 'object' ),
						),
						'conditions'      => array(
							'type'        => 'array',
							'description' => 'Optional assignment conditions. Omit or pass [] to create an unassigned layout. See set-layout-conditions for condition_type and query rules.',
							'items'       => array( 'type' => 'object' ),
						),
						'allow_raw_html'  => array(
							'type'    => 'boolean',
							'default' => false,
						),
					),
					'required'             => array( 'type', 'title' ),
					'additionalProperties' => false,
				),
				'output_schema'       => array( 'type' => 'object' ),
				'execute_callback'    => array( $this, 'ability_create_layout' ),
				'permission_callback' => array( Permission::class, 'manage_theme' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => false,
					),
				),
			)
		);

		wp_register_ability(
			'woodmart/set-layout-conditions',
			array(
				'label'               => 'Set WoodMart Layout Conditions',
				'description'         => 'Replace a layout\'s assignment conditions (where the template applies) and rebuild the conditions cache. condition_type must be valid for that layout type. Most targeted conditions require a scalar condition_query; shipping/billing-country conditions require an array. Page-wide, "all", user-state, and account-endpoint conditions need no query. Order-total conditions require condition_query_number_min and/or condition_query_number_max. Passing an empty array unassigns the layout.',
				'category'            => 'woodmart-layouts',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(
						'layout_id'  => array(
							'type'        => 'integer',
							'description' => 'woodmart_layout post id.',
						),
						'conditions' => array(
							'type'        => 'array',
							'description' => 'Full replacement set of condition entries.',
							'items'       => array( 'type' => 'object' ),
						),
					),
					'required'             => array( 'layout_id', 'conditions' ),
					'additionalProperties' => false,
				),
				'output_schema'       => array( 'type' => 'object' ),
				'execute_callback'    => array( $this, 'ability_set_conditions' ),
				'permission_callback' => array( Permission::class, 'manage_theme' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'readonly'    => false,
						'destructive' => true,
						'idempotent'  => true,
					),
				),
			)
		);
	}
}
