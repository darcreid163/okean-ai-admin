<?php
/**
 * AI abilities — WoodMart layout assignment conditions service.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Layouts;

use WP_Error;
use XTS\AI_Abilities\Gutenberg\Storage;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Validates and persists a layout's assignment conditions, then rebuilds the
 * global conditions cache the front end reads.
 */
class Conditions {
	const META_KEY = 'wd_layout_conditions';

	/**
	 * Allowed condition_comparison values.
	 *
	 * @var array<int,string>
	 */
	private const COMPARISONS = array( 'include', 'exclude' );

	/**
	 * Allowed condition types by layout type.
	 *
	 * @var array<string,array<int,string>>
	 */
	private const CONDITION_TYPES = array(
		'single_product'           => array( 'all', 'product', 'product_cat', 'product_cat_children', 'product_tag', 'product_brand', 'product_attr_term', 'product_type' ),
		'shop_archive'             => array( 'all', 'shop_page', 'product_search', 'product_cats', 'product_tags', 'product_brands', 'product_attr', 'product_term', 'product_cat_children', 'filtered_product_term', 'filtered_product_by_term', 'filtered_product_term_any', 'filtered_product_stock_status' ),
		'cart'                     => array( 'cart' ),
		'empty_cart'               => array( 'empty_cart' ),
		'checkout_form'            => array( 'checkout_form' ),
		'checkout_content'         => array( 'checkout_content' ),
		'thank_you_page'           => array( 'all', 'products', 'product_cat', 'product_cat_children', 'product_tag', 'product_brand', 'product_attr_term', 'product_type', 'product_shipping_class', 'order_payment_gateway', 'order_shipping_method', 'order_shipping_country', 'order_billing_country', 'order_total', 'order_subtotal', 'order_subtotal_after_discount', 'user_logged_in', 'user_logged_out' ),
		'my_account_auth'          => array( 'all' ),
		'my_account_lost_password' => array( 'all' ),
		'product_loop_item'        => array( 'all' ),
		'single_post'              => array( 'all', 'post_id', 'post_cat', 'post_tag', 'post_format' ),
		'blog_archive'             => array( 'all', 'blog_search_result', 'blog_category', 'blog_tag', 'blog_author', 'blog_date' ),
		'single_portfolio'         => array( 'all', 'project_id', 'project_cat' ),
		'portfolio_archive'        => array( 'all', 'portfolio_search_result', 'portfolio_category' ),
	);

	/**
	 * Condition types that do not use condition_query.
	 *
	 * @var array<int,string>
	 */
	private const NO_QUERY_TYPES = array(
		'all',
		'shop_page',
		'product_search',
		'product_cats',
		'product_tags',
		'product_brands',
		'filtered_product_term_any',
		'cart',
		'empty_cart',
		'checkout_form',
		'checkout_content',
		'blog_search_result',
		'blog_author',
		'blog_date',
		'portfolio_search_result',
		'user_logged_in',
		'user_logged_out',
	);

	/**
	 * Condition types that use min/max number inputs instead of condition_query.
	 *
	 * @var array<int,string>
	 */
	private const NUMBER_QUERY_TYPES = array( 'order_total', 'order_subtotal', 'order_subtotal_after_discount' );

	/**
	 * Condition types whose query value must be an array.
	 *
	 * @var array<int,string>
	 */
	private const ARRAY_QUERY_TYPES = array( 'order_shipping_country', 'order_billing_country' );

	/**
	 * Queue storage service (used only for its generic post-meta helpers).
	 *
	 * @var Storage
	 */
	private $storage;

	/**
	 * Constructor.
	 *
	 * @param Storage $storage Queue storage service.
	 */
	public function __construct( Storage $storage ) {
		$this->storage = $storage;
	}

	/**
	 * Current assignment conditions for a layout.
	 *
	 * @param int $layout_id Layout post id.
	 * @return array<int,array<string,mixed>>
	 */
	public function get( $layout_id ) {
		return $this->storage->meta_array( $layout_id, self::META_KEY );
	}

	/**
	 * Describe the valid condition types and query shape for a layout type.
	 *
	 * @param string $layout_type Layout type.
	 * @return array<int,array{type:string,query_kind:string}>
	 */
	public function describe_for_layout( $layout_type ) {
		$descriptors = array();

		foreach ( $this->allowed_types( $layout_type ) as $type ) {
			if ( in_array( $type, $this->no_query_types( $layout_type ), true ) ) {
				$query_kind = 'none';
			} elseif ( in_array( $type, self::NUMBER_QUERY_TYPES, true ) ) {
				$query_kind = 'number_range';
			} elseif ( in_array( $type, self::ARRAY_QUERY_TYPES, true ) ) {
				$query_kind = 'array';
			} else {
				$query_kind = 'scalar';
			}

			$descriptors[] = array(
				'type'       => $type,
				'query_kind' => $query_kind,
			);
		}

		return $descriptors;
	}

	/**
	 * Validate and sanitize a conditions array.
	 *
	 * @param mixed  $conditions  Raw conditions input.
	 * @param string $layout_type Layout type the conditions target.
	 * @return array<int,array<string,mixed>>|WP_Error
	 */
	public function validate( $conditions, $layout_type = '' ) {
		if ( ! is_array( $conditions ) ) {
			return new WP_Error( 'wd_ai_conditions_not_array', 'conditions must be an array of condition entries.' );
		}

		$sanitized     = array();
		$allowed_types = $this->allowed_types( $layout_type );

		foreach ( array_values( $conditions ) as $index => $entry ) {
			if ( ! is_array( $entry ) ) {
				return new WP_Error( 'wd_ai_condition_invalid', sprintf( 'Condition #%d must be an object.', $index ) );
			}

			$comparison = isset( $entry['condition_comparison'] ) ? (string) $entry['condition_comparison'] : '';
			if ( ! in_array( $comparison, self::COMPARISONS, true ) ) {
				return new WP_Error( 'wd_ai_condition_comparison', sprintf( 'Condition #%d: condition_comparison must be "include" or "exclude".', $index ) );
			}

			$type = isset( $entry['condition_type'] ) ? sanitize_key( (string) $entry['condition_type'] ) : '';
			if ( '' === $type ) {
				return new WP_Error( 'wd_ai_condition_type', sprintf( 'Condition #%d: condition_type is required.', $index ) );
			}
			if ( ! empty( $allowed_types ) && ! in_array( $type, $allowed_types, true ) ) {
				return new WP_Error( 'wd_ai_condition_type', sprintf( 'Condition #%1$d: condition_type "%2$s" is not valid for layout type "%3$s".', $index, $type, $layout_type ) );
			}

			$clean = array(
				'condition_comparison' => $comparison,
				'condition_type'       => $type,
				'condition_query'      => '',
			);

			$no_query_type = in_array( $type, $this->no_query_types( $layout_type ), true );
			$number_type   = in_array( $type, self::NUMBER_QUERY_TYPES, true );
			$has_query     = false;

			if ( ! $no_query_type && ! $number_type && array_key_exists( 'condition_query', $entry ) ) {
				$query = $entry['condition_query'];
				if ( is_array( $query ) ) {
					if ( ! in_array( $type, self::ARRAY_QUERY_TYPES, true ) ) {
						return new WP_Error( 'wd_ai_condition_query', sprintf( 'Condition #%d: condition_query must be a scalar value for this condition_type.', $index ) );
					}
					if ( array_filter( $query, 'is_scalar' ) !== $query ) {
						return new WP_Error( 'wd_ai_condition_query', sprintf( 'Condition #%d: condition_query array values must be scalar.', $index ) );
					}
					$query = array_values( array_filter( array_map( 'sanitize_text_field', array_map( 'strval', $query ) ), 'strlen' ) );
					if ( ! empty( $query ) ) {
						$clean['condition_query'] = $query;
						$has_query                = true;
					}
				} elseif ( is_scalar( $query ) ) {
					if ( in_array( $type, self::ARRAY_QUERY_TYPES, true ) ) {
						return new WP_Error( 'wd_ai_condition_query', sprintf( 'Condition #%d: condition_query must be a non-empty array for this condition_type.', $index ) );
					}
					$query = sanitize_text_field( (string) $query );
					if ( '' !== $query ) {
						$clean['condition_query'] = $query;
						$has_query                = true;
					}
				} else {
					return new WP_Error( 'wd_ai_condition_query', sprintf( 'Condition #%d: condition_query must be a string, number, or array.', $index ) );
				}
			}

			if ( $number_type ) {
				foreach ( array( 'condition_query_number_min', 'condition_query_number_max' ) as $number_key ) {
					if ( isset( $entry[ $number_key ] ) && '' !== $entry[ $number_key ] ) {
						if ( ! is_numeric( $entry[ $number_key ] ) || (float) $entry[ $number_key ] < 0 ) {
							return new WP_Error( 'wd_ai_condition_number', sprintf( 'Condition #%1$d: %2$s must be a non-negative number.', $index, $number_key ) );
						}
						$clean[ $number_key ] = (float) $entry[ $number_key ];
					}
				}
			}

			if ( $number_type ) {
				if ( ! isset( $clean['condition_query_number_min'] ) && ! isset( $clean['condition_query_number_max'] ) ) {
					return new WP_Error( 'wd_ai_condition_number', sprintf( 'Condition #%d: at least one of condition_query_number_min or condition_query_number_max is required.', $index ) );
				}
				if ( isset( $clean['condition_query_number_min'], $clean['condition_query_number_max'] ) && $clean['condition_query_number_min'] > $clean['condition_query_number_max'] ) {
					return new WP_Error( 'wd_ai_condition_number', sprintf( 'Condition #%d: condition_query_number_min cannot exceed condition_query_number_max.', $index ) );
				}
			} elseif ( ! $no_query_type && ! $has_query ) {
				return new WP_Error( 'wd_ai_condition_query', sprintf( 'Condition #%d: condition_query is required for this condition_type.', $index ) );
			}

			$sanitized[] = $clean;
		}

		return $sanitized;
	}

	/**
	 * Allowed condition types for a layout.
	 *
	 * @param string $layout_type Layout type.
	 * @return array<int,string>
	 */
	private function allowed_types( $layout_type ) {
		if ( 'my_account_page' !== $layout_type ) {
			return isset( self::CONDITION_TYPES[ $layout_type ] ) ? self::CONDITION_TYPES[ $layout_type ] : array();
		}

		$types = array( 'all', 'dashboard', 'waitlist', 'wishlist', 'price-tracker' );
		if ( function_exists( 'wc_get_account_menu_items' ) ) {
			$types = array_merge( $types, array_keys( wc_get_account_menu_items() ) );
		}

		return array_values( array_unique( $types ) );
	}

	/**
	 * Condition types that do not require condition_query for a layout.
	 *
	 * @param string $layout_type Layout type.
	 * @return array<int,string>
	 */
	private function no_query_types( $layout_type ) {
		if ( 'my_account_page' === $layout_type ) {
			return $this->allowed_types( $layout_type );
		}

		return self::NO_QUERY_TYPES;
	}

	/**
	 * Persist conditions to a layout and rebuild the conditions cache.
	 *
	 * @param int                            $layout_id  Layout post id.
	 * @param array<int,array<string,mixed>> $conditions Sanitized conditions.
	 * @return void
	 */
	public function set( $layout_id, array $conditions ) {
		$this->storage->set_meta( $layout_id, self::META_KEY, $conditions );
		$this->regenerate();
	}

	/**
	 * Rebuild the global wd_layouts_conditions cache from every layout's meta.
	 *
	 * @return void
	 */
	public function regenerate() {
		if ( class_exists( '\XTS\Modules\Layouts\Conditions_Cache' ) ) {
			( new \XTS\Modules\Layouts\Conditions_Cache() )->regenerate();
		}
	}
}
