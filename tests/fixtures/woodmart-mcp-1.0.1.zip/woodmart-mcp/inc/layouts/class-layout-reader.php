<?php
/**
 * AI abilities — read WoodMart layouts and their types.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Layouts;

use WP_Query;
use XTS\AI_Abilities\Gutenberg\Storage;
use XTS\AI_Abilities\Permission;
use XTS\Modules\Layouts\Main as Layouts_Main;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Read ability handlers for the woodmart_layout CPT.
 */
class Layout_Reader {
	const POST_TYPE = 'woodmart_layout';

	/**
	 * Queue storage service (generic meta helpers).
	 *
	 * @var Storage
	 */
	private $storage;

	/**
	 * Conditions service.
	 *
	 * @var Conditions
	 */
	private $conditions;

	/**
	 * Constructor.
	 *
	 * @param Storage    $storage    Queue storage service.
	 * @param Conditions $conditions Conditions service.
	 */
	public function __construct( Storage $storage, Conditions $conditions ) {
		$this->storage    = $storage;
		$this->conditions = $conditions;
	}

	/**
	 * Execute callback for woodmart/list-layout-types.
	 *
	 * Accepts an empty object so REST/MCP clients can validate their conventional
	 * parameters payload without passing meaningful input.
	 *
	 * @param array<string,mixed>|null $input Ability input (unused).
	 * @return array<int,array<string,mixed>>
	 */
	public function ability_list_types( $input = null ) { // phpcs:ignore Generic.CodeAnalysis.UnusedFunctionParameter.Found
		$rows = array();

		foreach ( Layout_Types::labels() as $type => $label ) {
			$rows[] = array(
				'type'             => $type,
				'label'            => $label,
				'woocommerce'      => Layout_Types::is_woocommerce_type( $type ),
				'block_categories' => Layout_Types::block_categories( $type ),
				'condition_types'  => $this->conditions->describe_for_layout( $type ),
				'existing_count'   => $this->count_layouts( $type ),
				'predefined'       => Layout_Types::predefined_for( $type ),
			);
		}

		return $rows;
	}

	/**
	 * Execute callback for woodmart/list-layouts.
	 *
	 * @param array<string,mixed>|null $input Ability input. Null when the ability is
	 *                                        invoked with no arguments (list everything).
	 * @return array<int,array<string,mixed>>
	 */
	public function ability_list_layouts( $input ) {
		$input = is_array( $input ) ? $input : array();

		$type     = isset( $input['type'] ) ? sanitize_key( (string) $input['type'] ) : '';
		$per_page = isset( $input['per_page'] ) && (int) $input['per_page'] > 0 ? min( 100, (int) $input['per_page'] ) : 20;
		$page     = isset( $input['page'] ) && (int) $input['page'] > 0 ? (int) $input['page'] : 1;

		$args = array(
			'post_type'      => self::POST_TYPE,
			'post_status'    => 'any',
			'posts_per_page' => $per_page,
			'paged'          => $page,
			'orderby'        => 'modified',
			'order'          => 'DESC',
		);

		if ( '' !== $type ) {
			$args['meta_key']   = 'wd_layout_type'; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
			$args['meta_value'] = $type; // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
		}

		$query = new WP_Query( $args );
		$rows  = array();

		foreach ( $query->posts as $post ) {
			$layout_type = $this->storage->meta_string( $post->ID, 'wd_layout_type' );
			$assigned_id = $layout_type ? (int) Layouts_Main::get_instance()->get_layout_id( $layout_type ) : 0;

			$rows[] = array(
				'id'          => $post->ID,
				'title'       => $post->post_title,
				'type'        => $layout_type,
				'status'      => $post->post_status,
				'conditions'  => $this->conditions->get( $post->ID ),
				'is_assigned' => $assigned_id === (int) $post->ID,
				'edit_url'    => get_edit_post_link( $post->ID, 'raw' ),
				'target_id'   => $post->ID,
			);
		}

		return $rows;
	}

	/**
	 * Count published/draft layouts of a type.
	 *
	 * @param string $type Layout type id.
	 * @return int
	 */
	private function count_layouts( $type ) {
		$query = new WP_Query(
			array(
				'post_type'      => self::POST_TYPE,
				'post_status'    => 'any',
				'fields'         => 'ids',
				'posts_per_page' => -1,
				'meta_key'       => 'wd_layout_type', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key
				'meta_value'     => $type, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'no_found_rows'  => true,
			)
		);

		return count( $query->posts );
	}

	/**
	 * Register the read abilities.
	 *
	 * @return void
	 */
	public function register() {
		wp_register_ability(
			'woodmart/list-layout-types',
			array(
				'label'               => 'List WoodMart Layout Types',
				'description'         => 'Entry point for layouts: list every WoodMart layout type with its label, WooCommerce requirement, block_categories for gutenberg-list-blocks, predefined templates, existing count, and valid condition_types. Each condition type reports query_kind: none, scalar condition_query, array condition_query, or number_range using condition_query_number_min/max. Then create-layout, edit its blocks with gutenberg-* against the layout target_id, and use set-layout-conditions to control where it applies.',
				'category'            => 'woodmart-layouts',
				'input_schema'        => array(
					'type'                 => 'object',
					'properties'           => array(),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'  => 'array',
					'items' => array( 'type' => 'object' ),
				),
				'execute_callback'    => array( $this, 'ability_list_types' ),
				'permission_callback' => array( Permission::class, 'callback' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);

		wp_register_ability(
			'woodmart/list-layouts',
			array(
				'label'               => 'List WoodMart Layouts',
				'description'         => 'List existing woodmart_layout template posts, optionally filtered by type. Returns id, title, type, status, assignment conditions, is_assigned (whether it currently wins for its type; note it is resolved in the current request context, so over REST/MCP a condition like "all" that depends on being on a product/shop page may report false even when correctly configured), edit_url, and target_id. Pass target_id to gutenberg-get-content / gutenberg-edit-blocks to read or edit the layout blocks.',
				'category'            => 'woodmart-layouts',
				'input_schema'        => array(
					// A `{}` default is added for woodmart/* object schemas in
					// Main::ensure_object_input_default(), so a no-argument call
					// ("list all layouts") resolves to an empty object and validates.
					'type'                 => 'object',
					'properties'           => array(
						'type'     => array(
							'type'        => 'string',
							'enum'        => Layout_Types::enum(),
							'description' => 'Optional layout type filter (see list-layout-types).',
						),
						'per_page' => array(
							'type'        => 'integer',
							'minimum'     => 1,
							'maximum'     => 100,
							'description' => 'Results per page (default 20).',
						),
						'page'     => array(
							'type'        => 'integer',
							'minimum'     => 1,
							'description' => 'Page number (default 1).',
						),
					),
					'additionalProperties' => false,
				),
				'output_schema'       => array(
					'type'  => 'array',
					'items' => array( 'type' => 'object' ),
				),
				'execute_callback'    => array( $this, 'ability_list_layouts' ),
				'permission_callback' => array( Permission::class, 'callback' ),
				'meta'                => array(
					'show_in_rest' => true,
					'mcp'          => array( 'public' => true ),
					'annotations'  => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
				),
			)
		);
	}
}
