<?php
/**
 * AI abilities — canonical WoodMart layout-type registry.
 *
 * @package woodmart
 */

namespace XTS\AI_Abilities\Layouts;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Pure helper describing the WoodMart layout types the AI may work with.
 *
 * Mirrors XTS\Modules\Layouts\Admin\Admin::set_layout_types() so abilities do not
 * depend on the admin object being constructed at ability-registration time.
 */
class Layout_Types {
	/**
	 * WooCommerce-gated type id => label.
	 *
	 * @var array<string,string>
	 */
	private const WOOCOMMERCE_TYPES = array(
		'single_product'           => 'Single product',
		'shop_archive'             => 'Products archive',
		'cart'                     => 'Cart',
		'empty_cart'               => 'Empty cart',
		'checkout_form'            => 'Checkout form',
		'checkout_content'         => 'Checkout top content',
		'thank_you_page'           => 'Thank you page',
		'my_account_page'          => 'My account',
		'my_account_auth'          => 'Login/Register',
		'my_account_lost_password' => 'Lost password',
		'product_loop_item'        => 'Product loop item',
	);

	/**
	 * Always-available type id => label.
	 *
	 * @var array<string,string>
	 */
	private const GENERAL_TYPES = array(
		'single_post'       => 'Single post',
		'blog_archive'      => 'Blog',
		'single_portfolio'  => 'Single project',
		'portfolio_archive' => 'Portfolio',
	);

	/**
	 * Type id => layout block.json category used by gutenberg-list-blocks.
	 *
	 * @var array<string,string>
	 */
	private const BLOCK_CATEGORIES = array(
		'single_product'           => 'xtemos_single_product',
		'shop_archive'             => 'xtemos_archive_elements',
		'product_loop_item'        => 'xtemos_loop_builder',
		'cart'                     => 'xtemos_cart_elements',
		'empty_cart'               => 'xtemos_cart_elements',
		'checkout_form'            => 'xtemos_checkout_elements',
		'checkout_content'         => 'xtemos_checkout_elements',
		'thank_you_page'           => 'xtemos_thank_you_page_elements',
		'my_account_page'          => 'xtemos_my_account_elements',
		'my_account_auth'          => 'xtemos_my_account_elements',
		'my_account_lost_password' => 'xtemos_my_account_elements',
		'single_post'              => 'xtemos_posts_elements',
		'blog_archive'             => 'xtemos_posts_elements',
		'single_portfolio'         => 'xtemos_posts_elements',
		'portfolio_archive'        => 'xtemos_posts_elements',
	);

	/**
	 * Block category available to every layout type.
	 *
	 * Holds the site-wide elements (page title, breadcrumbs, notices, checkout
	 * steps, shipping progress bar, …) that are not tied to what a particular
	 * layout renders, so BLOCK_CATEGORIES alone would hide them.
	 *
	 * @var string
	 */
	private const SHARED_BLOCK_CATEGORY = 'xtemos_site_elements';

	/**
	 * Type id => published-content prerequisite for the layout preview to work.
	 *
	 * @var array<string,string>
	 */
	private const PREVIEW_PREREQUISITE = array(
		'single_product'    => 'product',
		'product_loop_item' => 'product',
		'single_post'       => 'post',
		'single_portfolio'  => 'portfolio',
	);

	/**
	 * Valid type id => label, honouring WooCommerce availability.
	 *
	 * @return array<string,string>
	 */
	public static function labels() {
		$types = array();

		if ( woodmart_woocommerce_installed() ) {
			$woocommerce_types = self::WOOCOMMERCE_TYPES;

			if ( 'native' === woodmart_get_opt( 'current_builder' ) ) {
				$woocommerce_types['checkout_form'] = 'Checkout';
				unset( $woocommerce_types['checkout_content'] );
			}

			$types += $woocommerce_types;
		}

		$types += self::GENERAL_TYPES;

		return $types;
	}

	/**
	 * List of valid type ids for use as a schema enum.
	 *
	 * @return array<int,string>
	 */
	public static function enum() {
		return array_keys( self::labels() );
	}

	/**
	 * Whether the given id is a currently-valid layout type.
	 *
	 * @param string $type Type id.
	 * @return bool
	 */
	public static function is_valid( $type ) {
		return isset( self::labels()[ $type ] );
	}

	/**
	 * Whether the given type requires WooCommerce.
	 *
	 * @param string $type Type id.
	 * @return bool
	 */
	public static function is_woocommerce_type( $type ) {
		return isset( self::WOOCOMMERCE_TYPES[ $type ] );
	}

	/**
	 * Block-catalog categories to filter gutenberg-list-blocks for this type: the
	 * type's own category (when it has one) plus the shared site-elements one.
	 *
	 * @param string $type Type id.
	 * @return array<int,string>
	 */
	public static function block_categories( $type ) {
		$categories = array();

		if ( isset( self::BLOCK_CATEGORIES[ $type ] ) ) {
			$categories[] = self::BLOCK_CATEGORIES[ $type ];
		}

		$categories[] = self::SHARED_BLOCK_CATEGORY;

		return $categories;
	}

	/**
	 * Predefined template directory names available for a type.
	 *
	 * @param string $type Type id.
	 * @return array<int,string>
	 */
	public static function predefined_for( $type ) {
		$dir = WOODMART_THEMEROOT . '/inc/modules/layouts/admin/predefined/' . $type;

		if ( ! is_dir( $dir ) ) {
			return array();
		}

		$names = array();

		foreach ( scandir( $dir ) as $entry ) {
			if ( '.' === $entry || '..' === $entry ) {
				continue;
			}

			if ( is_dir( $dir . '/' . $entry ) ) {
				$names[] = $entry;
			}
		}

		natsort( $names );

		return array_values( $names );
	}

	/**
	 * Published-content prerequisite ('product'|'post'|'portfolio') for a type, or null.
	 *
	 * @param string $type Type id.
	 * @return string|null
	 */
	public static function preview_prerequisite( $type ) {
		return isset( self::PREVIEW_PREREQUISITE[ $type ] ) ? self::PREVIEW_PREREQUISITE[ $type ] : null;
	}
}
