<?php
/**
 * MCP page template.
 *
 * @package woodmart-mcp
 */

$mcp               = \XTS\AI_Abilities\Admin\Main::get_instance();
$is_plugins_active = $mcp->check_mcp_plugins_is_active();
?>

<div class="xts-box xts-theme-style">
	<div class="xts-box-header">
		<h3>
			<?php esc_html_e( 'WoodMart MCP', 'woodmart' ); ?>
		</h3>
	</div>

	<div class="xts-box-content xts-mcp">
		<div class="xts-mcp-intro">
			<p>
				<?php
				printf(
					// translators: %1$s and %2$s are opening and closing <strong> tags.
					esc_html__( 'Let an AI agent — Claude, Codex, Cursor — manage this site directly instead of clicking through wp-admin. As with any AI tool, occasional errors are possible, so we recommend using this on a %1$sstaging%2$s environment rather than a live one, and reviewing changes before applying them broadly. Once connected, an AI agent can:', 'woodmart' ),
					'<strong>',
					'</strong>'
				);
				?>
			</p>

			<ul class="xts-mcp-intro-list">
				<li><?php esc_html_e( 'Create, edit and publish pages, posts, portfolio items and HTML blocks — full Gutenberg support.', 'woodmart' ); ?></li>
				<li><?php esc_html_e( 'Read and change theme settings — colors, typography, toggles.', 'woodmart' ); ?></li>
				<li><?php esc_html_e( 'Create and manage layout templates and their display conditions.', 'woodmart' ); ?></li>
			</ul>
		</div>

		<div class="xts-mcp-steps">
			<div class="xts-mcp-step">
				<div class="xts-mcp-step-head">
					<span class="xts-mcp-step-num">1</span>
					<h4>
						<?php esc_html_e( 'Install the required plugins', 'woodmart' ); ?>
					</h4>
				</div>

				<div class="xts-mcp-step-body">
					<ul class="xts-mcp-plugins-list">
						<?php foreach ( $mcp->get_mcp_plugins() as $mcp_plugin ) : ?>
							<li>
								<span>
									<strong><?php echo esc_html( $mcp_plugin['name'] ); ?></strong>
									&mdash;
									<?php echo ! empty( $mcp_plugin['description'] ) ? esc_html( $mcp_plugin['description'] ) : ''; ?>
								</span>

								<span class="xts-mcp-plugin-status<?php echo $mcp_plugin['is_active'] ? ' xts-active' : ''; ?>">
									<?php echo $mcp_plugin['is_active'] ? esc_html__( 'Active', 'woodmart' ) : esc_html__( 'Not active', 'woodmart' ); ?>
								</span>
							</li>
						<?php endforeach; ?>
					</ul>

					<button type="button" class="xts-btn xts-color-primary xts-mcp-btn-loader<?php echo $is_plugins_active ? ' xts-mcp-done' : ''; ?>" id="xts-mcp-enable-plugins" <?php echo $is_plugins_active ? 'disabled' : ''; ?>>
						<?php echo $is_plugins_active ? esc_html__( 'Plugins enabled', 'woodmart' ) : esc_html__( 'Enable MCP plugins', 'woodmart' ); ?>
					</button>

					<div id="xts-mcp-plugins-error" class="xts-notice xts-error" hidden></div>
				</div>
			</div>

			<div class="xts-mcp-step">
				<div class="xts-mcp-step-head">
					<span class="xts-mcp-step-num">2</span>
					<h4>
						<?php esc_html_e( 'Generate the configuration', 'woodmart' ); ?>
					</h4>
				</div>

				<div class="xts-mcp-step-body">
					<?php $app_pass_status = $mcp->get_app_pass_status(); ?>
					<?php if ( 'available' === $app_pass_status ) : ?>
						<p>
							<?php esc_html_e( 'Pick your agent, then click "Add Application Password" to create a password and add it to the configuration shown below.', 'woodmart' ); ?>
						</p>

						<?php $mcp->render_agent_select_html(); ?>

						<button type="button" class="xts-btn xts-color-primary xts-mcp-btn-loader" id="xts-mcp-add-app-password">
							<?php esc_html_e( 'Add Application Password', 'woodmart' ); ?>
						</button>

						<div id="xts-mcp-config-notice" class="xts-notice" hidden></div>

						<div id="xts-mcp-existing-password-notice" class="xts-notice xts-info" hidden>
							<p>
								<strong><?php esc_html_e( 'You already have an application password for the selected agent.', 'woodmart' ); ?></strong>
							</p>
							<p>
								<?php esc_html_e( 'If you forgot it, create a new one by clicking "Add Application Password". Remember to delete the previous password from', 'woodmart' ); ?>
								<a href="<?php echo esc_url( admin_url( 'profile.php#application-passwords-section' ) ); ?>" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'your profile', 'woodmart' ); ?></a>.
							</p>
						</div>

						<div id="xts-mcp-config">
							<p class="xts-mcp-config-notice">
								<?php esc_html_e( 'Config is incomplete until it has a password — click "Add Application Password" above, or enter a previously saved password manually.', 'woodmart' ); ?>
							</p>

							<div class="xts-mcp-config-hint-wrapper">
								<p class="xts-mcp-config-hint" data-agent="claude">
									<?php esc_html_e( 'Claude Desktop: Settings → Developer → Edit Config, paste, save, then fully restart the app.', 'woodmart' ); ?>
									<?php esc_html_e( 'If you encounter any difficulties, see the', 'woodmart' ); ?>
									<a href="https://modelcontextprotocol.io/docs/develop/connect-local-servers" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'documentation', 'woodmart' ); ?></a>.
								</p>

								<p class="xts-mcp-config-hint xts-hidden" data-agent="claude-code">
									<?php
										printf(
											// translators: %1$s and %2$s, %3$s and %4$s, %5$s and %6$s are opening and closing <code> tags.
											esc_html__( 'Easiest: save as %1$s.mcp.json%2$s in your project root, then restart Claude Code. Editing %3$s~/.claude.json%4$s instead? Nest it under %5$sprojects["/your/path"].mcpServers%6$s.', 'woodmart' ),
											'<code class="xts-mcp-code-inline">',
											'</code>',
											'<code class="xts-mcp-code-inline">',
											'</code>',
											'<code class="xts-mcp-code-inline">',
											'</code>'
										);
									?>
									<?php esc_html_e( 'If you encounter any difficulties, see the', 'woodmart' ); ?>
									<a href="https://code.claude.com/docs/en/mcp" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'documentation', 'woodmart' ); ?></a>.
								</p>

								<p class="xts-mcp-config-hint xts-hidden" data-agent="codex-app">
									<?php esc_html_e( 'Codex Desktop: Settings → Plugins → Add → Add MCP server. Fill in the fields below, save the server, then restart the app.', 'woodmart' ); ?>
									<?php esc_html_e( 'If you encounter any difficulties, see the', 'woodmart' ); ?>
									<a href="https://learn.chatgpt.com/docs/extend/mcp?surface=cli" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'documentation', 'woodmart' ); ?></a>.
								</p>

								<p class="xts-mcp-config-hint xts-hidden" data-agent="codex">
									<?php
										printf(
											// translators: %1$s and %2$s are opening and closing <code> tags.
											esc_html__( 'Paste it into %1$s~/.codex/config.toml%2$s.', 'woodmart' ),
											'<code class="xts-mcp-code-inline">',
											'</code>'
										);
									?>
									<?php esc_html_e( 'If you encounter any difficulties, see the', 'woodmart' ); ?>
									<a href="https://learn.chatgpt.com/docs/extend/mcp?surface=cli" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'documentation', 'woodmart' ); ?></a>.
								</p>

								<p class="xts-mcp-config-hint xts-hidden" data-agent="cursor">
									<?php
										printf(
											// translators: %1$s and %2$s are opening and closing <code> tags.
											esc_html__( 'Paste it into %1$s~/.cursor/mcp.json%2$s.', 'woodmart' ),
											'<code class="xts-mcp-code-inline">',
											'</code>'
										);
									?>
									<?php esc_html_e( 'If you encounter any difficulties, see the', 'woodmart' ); ?>
									<a href="https://cursor.com/docs/mcp" target="_blank" rel="noopener noreferrer"><?php esc_html_e( 'documentation', 'woodmart' ); ?></a>.
								</p>
							</div>

							<?php $mcp->render_agent_config_outputs_html(); ?>
						</div>
					<?php else : ?>
						<div id="xts-mcp-config-notice" class="xts-notice xts-info">
							<?php if ( 'unsupported_environment' === $app_pass_status ) : ?>
								<p>
									<strong><?php esc_html_e( 'Application passwords require HTTPS or a local environment.', 'woodmart' ); ?></strong>
								</p>
								<p>
									<?php
										printf(
											// translators: %1$s and %2$s are opening and closing <code> tags.
											esc_html__( 'Enable HTTPS or add %1$sdefine( \'WP_ENVIRONMENT_TYPE\', \'local\' );%2$s to wp-config.php, then reload this page.', 'woodmart' ),
											'<code>',
											'</code>'
										);
									?>
								</p>
							<?php elseif ( 'wordfence' === $app_pass_status ) : ?>
								<p>
									<strong><?php esc_html_e( 'Application passwords are disabled by Wordfence.', 'woodmart' ); ?></strong>
								</p>
								<p>
									<?php esc_html_e( 'Turn off “Disable WordPress application passwords” in Wordfence Brute Force Protection, then reload this page.', 'woodmart' ); ?>
								</p>
								<a class="xts-btn xts-color-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=WordfenceWAF&subpage=waf_options#wf-option-loginSec-disableApplicationPasswords-label' ) ); ?>">
									<?php esc_html_e( 'Open Wordfence settings', 'woodmart' ); ?>
								</a>
							<?php else : ?>
								<p>
									<strong><?php esc_html_e( 'Application passwords are disabled by a plugin or custom code.', 'woodmart' ); ?></strong>
								</p>
								<p>
									<?php
										printf(
											// translators: %1$s and %2$s are opening and closing <code> tags.
											esc_html__( 'Check security plugins and custom code that uses the %1$swp_is_application_passwords_available%2$s filter. Enable application passwords there, then reload this page.', 'woodmart' ),
											'<code>',
											'</code>'
										);
									?>
								</p>
							<?php endif; ?>
						</div>
					<?php endif; ?>
				</div>
			</div>

			<div class="xts-mcp-step">
				<div class="xts-mcp-step-head">
					<span class="xts-mcp-step-num">3</span>
					<h4>
						<?php esc_html_e( 'Add the skill', 'woodmart' ); ?>
					</h4>
				</div>

				<div class="xts-mcp-step-body">
					<p>
						<?php esc_html_e( 'Teaches the agent how to use these tools correctly.', 'woodmart' ); ?>
					</p>

					<div class="xts-mcp-skill-block" data-skill-for="claude">
						<p>
							<?php esc_html_e( 'Download, then Claude Desktop → Settings → Skills → Create skill → upload the zip.', 'woodmart' ); ?>
						</p>

						<a class="xts-btn xts-color-primary" href="<?php echo esc_url( $mcp->get_skill_download_url() ); ?>">
							<?php esc_html_e( 'Download skill', 'woodmart' ); ?>
						</a>
					</div>

					<div class="xts-mcp-skill-block xts-hidden" data-skill-for="cli">
						<p>
							<?php esc_html_e( 'Run this command (Node.js required) to install the skill via the CLI:', 'woodmart' ); ?>
						</p>

						<div class="xts-mcp-copy-item">
							<pre class="xts-mcp-code-block" id="xts-mcp-skill-command" data-mcp-copy-value></pre>

							<button type="button" class="xts-btn xts-mcp-copy">
								<?php esc_html_e( 'Copy command', 'woodmart' ); ?>
							</button>
						</div>
					</div>
				</div>
			</div>

			<div class="xts-mcp-step">
				<div class="xts-mcp-step-head">
					<span class="xts-mcp-step-num">4</span>
					<h4>
						<?php esc_html_e( 'Check the connection', 'woodmart' ); ?>
					</h4>
				</div>

				<div class="xts-mcp-step-body">
					<p>
						<?php esc_html_e( 'Confirm the "woodmart" MCP server shows as connected, with tools such as search-content, create-content, update-theme-setting.', 'woodmart' ); ?>
					</p>

					<div class="xts-mcp-check-hint-wrapper">
						<p class="xts-mcp-check-hint" data-agent="claude">
							<?php esc_html_e( 'Claude Desktop: Settings → Connectors → woodmart → tool list.', 'woodmart' ); ?>
						</p>

						<p class="xts-mcp-check-hint xts-hidden" data-agent="claude-code">
							<?php
							printf(
								// translators: %1$s and %2$s are opening and closing <code> tags.
								esc_html__( 'Run %1$s/mcp%2$s inside Claude Code to see the list of available MCP tools.', 'woodmart' ),
								'<code class="xts-mcp-code-inline">',
								'</code>'
							);
							?>
						</p>

						<p class="xts-mcp-check-hint xts-hidden" data-agent="codex-app">
							<?php
							printf(
								// translators: %1$s and %2$s are opening and closing <code> tags.
								esc_html__( 'Codex Desktop: Settings → MCP servers → woodmart should be enabled. You can also enter %1$s/mcp%2$s in the composer to view connected servers.', 'woodmart' ),
								'<code class="xts-mcp-code-inline">',
								'</code>'
							);
							?>
						</p>

						<p class="xts-mcp-check-hint xts-hidden" data-agent="codex">
							<?php
							printf(
								// translators: %1$s and %2$s are opening and closing <code> tags.
								esc_html__( 'Run %1$s/mcp%2$s inside Codex CLI to see the list of available MCP tools.', 'woodmart' ),
								'<code class="xts-mcp-code-inline">',
								'</code>'
							);
							?>
						</p>

						<p class="xts-mcp-check-hint xts-hidden" data-agent="cursor">
							<?php esc_html_e( 'Cursor: Settings → MCP — "woodmart" should be listed as active.', 'woodmart' ); ?>
						</p>
					</div>

					<p>
						<?php
						printf(
							// translators: %1$s and %2$s are opening and closing <code> tags.
							esc_html__( 'Then try: %1$sUsing the woodmart MCP tools, find the home page%2$s — a real list back means it works end to end.', 'woodmart' ),
							'<code class="xts-mcp-code-inline">',
							'</code>'
						);
						?>
					</p>
				</div>
			</div>
		</div>
	</div>
</div>
