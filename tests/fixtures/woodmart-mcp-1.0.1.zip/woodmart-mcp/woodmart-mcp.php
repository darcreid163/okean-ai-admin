<?php
/**
 * Plugin Name: WoodMart MCP
 * Description: AI abilities and MCP integration for the WoodMart theme.
 * Version: 1.0.1
 * Author: XTemos
 * Text Domain: woodmart-mcp
 * Requires PHP: 7.4
 *
 * @package woodmart-mcp
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use XTS\AI_Abilities\Plugin;

define( 'WOODMART_MCP_VERSION', '1.0.1' );
define( 'WOODMART_MCP_PATH', untrailingslashit( plugin_dir_path( __FILE__ ) ) );
define( 'WOODMART_MCP_URL', untrailingslashit( plugin_dir_url( __FILE__ ) ) );

require_once WOODMART_MCP_PATH . '/inc/class-plugin.php';

Plugin::boot( __FILE__ );
