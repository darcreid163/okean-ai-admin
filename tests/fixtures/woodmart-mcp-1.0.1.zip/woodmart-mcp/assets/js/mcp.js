
/* global xtsMcpSettigns */
(function($) {
	'use strict';

	function themeMcp() {
		var appPasswordsGenerated = {};

		function init() {
			initEnablePlugins();
			initAgentSwitcher();
			initAddAppPassword();
			initCopyButtons();
		}

		function initEnablePlugins() {
			var $btn   = $('#xts-mcp-enable-plugins');
			var $error = $('#xts-mcp-plugins-error');

			if (!$btn.length) {
				return;
			}

			$btn.on('click', function() {
				var initialText = $btn.text();

				$error.attr('hidden', true).text('');
				$btn.prop('disabled', true).addClass('xts-loading');

				$.ajax({
					url    : xtsMcpSettigns.ajaxUrl,
					method : 'POST',
					data   : {
						action  : 'woodmart_enable_mcp_plugins',
						_wpnonce: xtsMcpSettigns.enableMcpPluginsNonce
					},
					success: function(response) {
						$btn.removeClass('xts-loading');

						if (response && response.success) {
							$btn.prop('disabled', true).addClass('xts-mcp-done').text(xtsMcpSettigns.pluginsEnabledText);
							$('.xts-mcp-plugin-status').addClass('xts-active').text(xtsMcpSettigns.pluginActiveText);
							return;
						}

						var message = response && response.data && response.data.message ? response.data.message : xtsMcpSettigns.requestFailedText;

						$error.text(message).removeAttr('hidden');
						$btn.prop('disabled', false).text(initialText);
					},
					error  : function() {
						$btn.removeClass('xts-loading').prop('disabled', false).text(initialText);
						$error.text(xtsMcpSettigns.requestFailedText).removeAttr('hidden');
					}
				});
			});
		}

		function initAgentSwitcher() {
			var $buttons = $('.xts-mcp-agent-btn');

			if (!$buttons.length) {
				return;
			}

			$buttons.on('click', function() {
				var $btn = $(this);

				if ($btn.hasClass('xts-active')) {
					return;
				}

				selectAgent($btn);
			});

			selectAgent($buttons.filter('.xts-active').length ? $buttons.filter('.xts-active') : $buttons.first());
		}

		function selectAgent($btn) {
			var agent        = $btn.data('agent');
			var configOutput = $('.xts-mcp-config-output-wrapper [data-agent="' + agent + '"]');
			var configHint   = $('.xts-mcp-config-hint-wrapper [data-agent="' + agent + '"]');
			var checkHint    = $('.xts-mcp-check-hint-wrapper [data-agent="' + agent + '"]');
			var $notice      = $('#xts-mcp-config-notice');

			$('.xts-mcp-agent-btn').removeClass('xts-active');
			$btn.addClass('xts-active');

			$('#xts-mcp-config .xts-mcp-config-output').addClass('xts-hidden');
			configOutput.removeClass('xts-hidden');

			$('.xts-mcp-config-hint-wrapper .xts-mcp-config-hint').addClass('xts-hidden');
			configHint.removeClass('xts-hidden');

			$('.xts-mcp-check-hint-wrapper .xts-mcp-check-hint').addClass('xts-hidden');
			checkHint.removeClass('xts-hidden');

			$notice.attr('hidden', true).removeClass('xts-error xts-success').text('');

			updateAppPasswordButton(agent);
			updateExistingPasswordNotice(agent);
			updateSkillStep(agent);
		}

		function getSelectedAgent() {
			return $('.xts-mcp-agent-btn.xts-active').data('agent');
		}

		function updateAppPasswordButton(agent) {
			$('#xts-mcp-add-app-password').toggleClass('xts-hidden', Boolean(appPasswordsGenerated[agent]));
		}

		function updateExistingPasswordNotice(agent) {
			var isRegistered = xtsMcpSettigns.appPasswordRegistered && xtsMcpSettigns.appPasswordRegistered[agent];

			$('#xts-mcp-existing-password-notice').prop('hidden', !isRegistered || Boolean(appPasswordsGenerated[agent]));
		}

		function updateSkillStep(selectedAgent) {
			var isDesktop  = 'claude' === selectedAgent;
			var skillAgent = 'codex-app' === selectedAgent ? 'codex' : selectedAgent;

			$('[data-skill-for="claude"]').toggleClass('xts-hidden', !isDesktop);
			$('[data-skill-for="cli"]').toggleClass('xts-hidden', isDesktop);

			if (!isDesktop) {
				$('#xts-mcp-skill-command').text(
					'npx skills add ' + xtsMcpSettigns.skillSourceRepo + ' -s woodmart-mcp -a ' + skillAgent + ' -g -y'
				);
			}
		}

		function initAddAppPassword() {
			var $btn    = $('#xts-mcp-add-app-password');
			var $notice = $('#xts-mcp-config-notice');

			if (!$btn.length) {
				return;
			}

			$btn.on('click', function() {
				var selectedAgent   = getSelectedAgent();
				var appName         = 'WoodMart MCP - ' + selectedAgent;
				var appPasswordsUrl = xtsMcpSettigns.restUrl + 'wp/v2/users/me/application-passwords';

				$notice.attr('hidden', true).removeClass('xts-error xts-success').text('');
				$btn.prop('disabled', true).addClass('xts-loading');

				$.ajax({
					url       : appPasswordsUrl,
					method    : 'POST',
					dataType  : 'json',
					data      : {
						name: appName
					},
					beforeSend: function(xhr) {
						xhr.setRequestHeader('X-WP-Nonce', xtsMcpSettigns.restNonce);
					},
					success: function(response) {
						$btn.removeClass('xts-loading').prop('disabled', false);

						insertPasswordIntoConfig(selectedAgent, response.password);

						appPasswordsGenerated[selectedAgent] = true;
						xtsMcpSettigns.appPasswordRegistered[selectedAgent] = true;
						updateAppPasswordButton(selectedAgent);
						updateExistingPasswordNotice(selectedAgent);

						$notice.addClass('xts-success').text(xtsMcpSettigns.passwordCreatedText + ' ' + response.password).removeAttr('hidden');
					},
					error  : function(xhr) {
						$btn.removeClass('xts-loading').prop('disabled', false);

						var message = (xhr.responseJSON && xhr.responseJSON.message) || xtsMcpSettigns.requestFailedText;

						$notice.addClass('xts-error').text(message).removeAttr('hidden');
					}
				});
			});
		}

		function insertPasswordIntoConfig(agent, password) {
			var $highlight = $('.xts-mcp-config-output-wrapper [data-agent="' + agent + '"] .xts-mcp-highlight-line');

			if (!$highlight.length) {
				return;
			}

			var passwordString = password;

			if ($highlight.parents('.xts-mcp-code-block').length > 0) {
				passwordString = $highlight.text().replace('""', '"' + password + '"');
			}

			$highlight.text(passwordString);
			$highlight.removeClass('xts-mcp-highlight-line xts-mcp-config-value-empty').removeAttr('data-empty-label');

			if ($highlight.is('[data-mcp-copy-value]')) {
				$highlight.attr('title', xtsMcpSettigns.clickToCopyText);
			} else {
				$highlight.removeAttr('title');
			}
		}

		function copyToClipboard(text) {
			if (window.isSecureContext && navigator.clipboard) {
				return navigator.clipboard.writeText(text).catch(function() {
					return copyUsingTextarea(text);
				});
			}

			return copyUsingTextarea(text);
		}

		function copyUsingTextarea(text) {
			var textarea = document.createElement('textarea');

			textarea.value = text;
			textarea.style.position = 'fixed';
			textarea.style.opacity  = '0';

			document.body.appendChild(textarea);
			textarea.select();

			var isCopied = document.execCommand('copy');

			document.body.removeChild(textarea);

			return isCopied ? Promise.resolve() : Promise.reject();
		}

		function copyText($btn, text) {
			if (!text) {
				return;
			}

			copyToClipboard(text).then(function() {
				var timeoutId   = $btn.data('copy-feedback-timeout-id');
				var usesTooltip = $btn.is('[data-mcp-copy-value]');

				if (timeoutId) {
					clearTimeout(timeoutId);
				}

				if (usesTooltip) {
					$btn.attr('data-copy-feedback', xtsMcpSettigns.copiedText).addClass('xts-mcp-copy-done');
				} else {
					$btn.data('copy-initial-text', $btn.data('copy-initial-text') || $btn.text()).text(xtsMcpSettigns.copiedText);
				}

				timeoutId = setTimeout(function() {
					if (usesTooltip) {
						$btn.removeClass('xts-mcp-copy-done').removeAttr('data-copy-feedback');
					} else {
						$btn.text($btn.data('copy-initial-text')).removeData('copy-initial-text');
					}

					$btn.removeData('copy-feedback-timeout-id');
				}, 1500);

				$btn.data('copy-feedback-timeout-id', timeoutId);
			});
		}

		function initCopyButtons() {
			var $buttons = $('.xts-mcp-copy');

			if (!$buttons.length) {
				return;
			}

			$buttons.on('click', function() {
				var $btn   = $(this);
				var $value = $btn.is('[data-mcp-copy-value]') ? $btn : $btn.closest('.xts-mcp-copy-item').find('[data-mcp-copy-value]').first();

				copyText($btn, $value.text());
			});
		}

		init();
	}

	jQuery(document).ready(function() {
		themeMcp();
	});
})(jQuery);
