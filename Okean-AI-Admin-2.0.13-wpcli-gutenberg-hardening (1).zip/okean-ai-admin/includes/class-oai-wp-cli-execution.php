<?php
/** Авторские права Андриянов Н.Г. */
if (!defined('ABSPATH')) exit;
class OAI_WP_CLI_Execution {
 public static function execute($resolved){$h=$resolved['handler'];$a=$resolved['args'];$f=$resolved['flags'];switch($h){
  case 'core':return array('version'=>get_bloginfo('version'),'command'=>'core version');
  case 'plugin_list':require_once ABSPATH.'wp-admin/includes/plugin.php';$all=get_plugins();$rows=array();foreach($all as $file=>$data)$rows[]=array('plugin'=>$file,'name'=>$data['Name'],'version'=>$data['Version'],'active'=>is_plugin_active($file));return self::format($rows,$f);
  case 'theme_list':$rows=array();foreach(wp_get_themes() as $stylesheet=>$t)$rows[]=array('stylesheet'=>$stylesheet,'name'=>$t->get('Name'),'version'=>$t->get('Version'),'active'=>$stylesheet===get_option('stylesheet'));return self::format($rows,$f);
  case 'post_list':$args=array('post_type'=>$f['post_type']??'any','post_status'=>$f['post_status']??'any','posts_per_page'=>isset($f['per_page'])?max(1,min(100,$f['per_page'])):20,'paged'=>1);$ps=get_posts($args);$rows=array();foreach($ps as $p)$rows[]=array('id'=>$p->ID,'title'=>$p->post_title,'type'=>$p->post_type,'status'=>$p->post_status,'slug'=>$p->post_name);return self::format($rows,$f);
  case 'post_get':$p=get_post(absint($a[0]??0));if(!$p)return new WP_Error('oai_post_not_found','Post not found',array('status'=>404));return array('id'=>$p->ID,'title'=>$p->post_title,'content'=>$p->post_content,'excerpt'=>$p->post_excerpt,'type'=>$p->post_type,'status'=>$p->post_status,'meta'=>get_post_meta($p->ID));
  case 'option_get':$v=get_option((string)($a[0]??''),null);return array('name'=>$a[0]??'','value'=>$v);
  case 'user_list':$users=get_users(array('number'=>isset($f['number'])?max(1,min(100,$f['number'])):20));$rows=array();foreach($users as $u)$rows[]=array('id'=>$u->ID,'login'=>$u->user_login,'name'=>$u->display_name,'roles'=>$u->roles);return self::format($rows,$f);
  case 'user_get':$u=get_user_by('id',absint($a[0]??0));if(!$u)return new WP_Error('oai_user_not_found','User not found',array('status'=>404));return array('id'=>$u->ID,'login'=>$u->user_login,'name'=>$u->display_name,'email'=>$u->user_email,'roles'=>$u->roles);
  case 'term_list':$tax=sanitize_key((string)($a[0]??'category'));return array('taxonomy'=>$tax,'terms'=>get_terms(array('taxonomy'=>$tax,'hide_empty'=>false,'number'=>100,'fields'=>'all')));
  case 'menu_list':return array('menus'=>wp_get_nav_menus());
  case 'media_list':$ps=get_posts(array('post_type'=>'attachment','post_status'=>'inherit','posts_per_page'=>50));$rows=array();foreach($ps as $p)$rows[]=array('id'=>$p->ID,'title'=>$p->post_title,'mime'=>get_post_mime_type($p->ID),'url'=>wp_get_attachment_url($p->ID));return self::format($rows,$f);
  case 'cron_list':return array('events'=>wp_get_scheduled_events());
  case 'db_query':return self::db_query($a,$f);
  case 'cache_purge':if(function_exists('wp_cache_flush'))wp_cache_flush();if(function_exists('rocket_clean_domain'))rocket_clean_domain();return array('purged'=>true);
  default:return new WP_Error('oai_cli_not_implemented','Command is registered but its execution handler is not implemented',array('status'=>501,'handler'=>$h,'canonical'=>$resolved['canonical']??null));}}
 private static function db_query($a,$f){
  $sql=trim(implode(' ',array_map('strval',$a)));
  if($sql==='')return new WP_Error('oai_db_empty','SQL query is empty',array('status'=>400));
  if(!preg_match('/^select\b/i',$sql))return new WP_Error('oai_db_read_only','db query is read-only',array('status'=>403));
  if(strpos($sql,';')!==false)return new WP_Error('oai_db_multi_statement','Multiple SQL statements are not allowed',array('status'=>403));
  $upper=strtoupper($sql);
  foreach(array('SLEEP\s*\(','BENCHMARK\s*\(','LOAD_FILE\s*\(','INTO\s+OUTFILE','INTO\s+DUMPFILE','FOR\s+UPDATE','LOCK\s+IN\s+SHARE') as $rx){if(preg_match('/'.$rx.'/i',$sql))return new WP_Error('oai_db_unsafe','Unsafe SQL construct is not allowed',array('status'=>403));}
  $limit=isset($f['limit'])?max(1,min(100,(int)$f['limit'])):100;
  if(!preg_match('/\blimit\s+\d+(?:\s*,\s*\d+)?\s*$/i',$sql))$sql=rtrim($sql). ' LIMIT '.$limit;
  global $wpdb; $rows=$wpdb->get_results($sql,ARRAY_A);
  if($wpdb->last_error)return new WP_Error('oai_db_query','Database query failed',array('status'=>400,'db_error'=>$wpdb->last_error));
  return array('rows'=>$rows,'count'=>count($rows),'limited_to'=>$limit,'sql_hash'=>hash('sha256',$sql));
 }
 public static function readiness(){return array('handlers'=>OAI_Command_Registry::handler_audit(),'direct_write_execution'=>false,'db_query_read_only'=>true,'db_query_max_rows'=>100);}
 private static function format($rows,$f){if(isset($f['format'])&&$f['format']==='ids'){return array_values(array_map(function($x){return (int)$x['id'];},$rows));}if(isset($f['format'])&&$f['format']==='count')return count($rows);return $rows;}
 public static function plan($resolved){$perm=OAI_Permission_Resolver::resolve($resolved);return array('canonical'=>$resolved['canonical'],'handler'=>$resolved['handler'],'args'=>$resolved['args'],'flags'=>$resolved['flags'],'permission'=>$perm,'execution_model'=>empty($resolved['read'])?'sandbox_then_approval':'read_only');}
}
